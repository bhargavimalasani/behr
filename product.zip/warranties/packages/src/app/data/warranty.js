var _warranty = {
    "Interior Paint & Primer": {
        "name": "Interior Paint & Primer",
        "data": {
            "BEHR MARQUEE<sup>®</sup> Interior Paint & Primer": [{
                "paintName": "BEHR MARQUEE<sup>®</sup> Interior Matte",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-marquee-matte",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/marquee/150_1450_1gWEB.png"
            },
            {
                "paintName": "BEHR MARQUEE<sup>®</sup> Interior Eggshell Enamel",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-marquee-eggshell-enamel",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/marquee/150_2450_1gWEB.png"
            },
            {
                "paintName": "BEHR MARQUEE<sup>®</sup> Interior Satin Enamel",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-marquee-satin-enamel",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/marquee/150_7450_1gWEB.png"
            },
            {
                "paintName": "BEHR MARQUEE<sup>®</sup> Interior Semi-Gloss Enamel",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-marquee-semi-gloss-enamel",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/marquee/150_3450_1gWEB.png"
            },
            {
                "paintName": "BEHR MARQUEE<sup>®</sup> Interior Ceiling Flat",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-marquee-ceiling-flat",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/marquee/150_1458_1g.png"
            }],
            "PREMIUM PLUS ULTRA<sup>®</sup> Interior Paint & Primer": [{
                "paintName": "PREMIUM PLUS ULTRA<sup>®</sup> Interior Matte",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-premium-plus-ultra-matte",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/ppu/150_1750_1gWEB.png"
            },
            {
                "paintName": "PREMIUM PLUS ULTRA<sup>®</sup> Interior Eggshell Enamel",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-premium-plus-ultra-eggshell-enamel",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/ppu/150_2750_1gWEB.png"
            },
            {
                "paintName": "PREMIUM PLUS ULTRA<sup>®</sup> Interior Satin Enamel",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-premium-plus-ultra-satin-enamel",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/ppu/150_7750_1gWEB.png"
            },
            {
                "paintName": "PREMIUM PLUS ULTRA<sup>®</sup> Interior Semi-Gloss Enamel",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-premium-plus-ultra-semi-gloss-enamel",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/ppu/150_3750_1gWEB.png"
            },
            {
                "paintName": "PREMIUM PLUS ULTRA<sup>®</sup> Interior Hi-Gloss",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-premium-plus-ultra-semi-gloss-enamel",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/ppu/150_8750_US1g.png"
            }],
            "PREMIUM PLUS<sup>®</sup> Interior Paint": [{
                "paintName": "PREMIUM PLUS<sup>®</sup> Interior Flat",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-premium-plus-flat",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/pp/150_1050_US_1g.png"
            },
            {
                "paintName": "PREMIUM PLUS<sup>®</sup> Interior Eggshell Enamel",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-premium-plus-eggshell-enamel",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/pp/150_2050_US_1g.png"
            },
            {
                "paintName": "PREMIUM PLUS<sup>®</sup> Interior Satin Enamel",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-premium-plus-satin-enamel",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/pp/150_7050_US_1g.png"
            },
            {
                "paintName": "PREMIUM PLUS<sup>®</sup> Interior Semi-Gloss Enamel",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-premium-plus-semi-gloss-enamel",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/pp/150_3050_US_1g.png"
            },
            {
                "paintName": "PREMIUM PLUS<sup>®</sup> Interior/Exterior Hi-Gloss Enamel",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-premium-plus-hi-gloss-enamel",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/pp/150_8050_1gWEB.png"
            }],
            "Alkyd Paint": [{
                "paintName": "BEHR<sup>®</sup> Alkyd Semi-Gloss Enamel",
                "warrantyType": "genericLimited",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-alkyd-semi-gloss-enamel",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/alkyd/150_1g_3900.png"
            },
            {
                "paintName": "BEHR<sup>®</sup> Alkyd Satin Enamel",
                "warrantyType": "genericLimited",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-alkyd-satin-enamel",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/alkyd/150_1g_7900.png"
            }],
            "Oil-Base Paint": [{
                "paintName": "BEHR<sup>®</sup> Oil-Base Semi-Gloss Enamel",
                "warrantyType": "genericLimited",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-oil-base-semi-gloss-enamel",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/oil-based/150_1g_3800.png"
            }],
            "Interior Primers & Sealers": [{
                "paintName": "PREMIUM PLUS<sup>®</sup> All-In-One Primer & Sealer",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-premium-plus-all-in-one-primer-and-sealer",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/primers/150_75_US_1gWEB.png"
            },
            {
                "paintName": "PREMIUM PLUS<sup>®</sup> Drywall Primer & Sealer",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-premium-plus-drywall-primer-and-sealer",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/primers/150_73_1gWEB.png"
            }],
            "Interior Ceiling Paint": [{
                "paintName": "PREMIUM PLUS ULTRA<sup>®</sup> Stain-Blocking Ceiling Paint",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/premium-plus-ultra-stain-blocking-ceiling-paint",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/ceiling/150_Ceiling_1gWEB.png"
            },
            {
                "paintName": "PREMIUM PLUS<sup>®</sup> Interior Ceiling Paint",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-premium-plus-ceiling-paint",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/ceiling/150_558_1gWEB.png"
            }],
            "Basement Masonry Waterproofers": [{
                "paintName": "BEHR PREMIUM<sup>®</sup> Basement & Masonry Waterproofer",
                "warrantyType": "masonryWaterproofPaints",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-premium-basement-and-masonry-waterproofer",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/basement/150_875_1g.png"
            }],
            "Faux, Decorative and Textured Finishes": [{
                "paintName": "BEHR PREMIUM PLUS WITH STYLE<sup>®</sup> Faux Glaze",
                "warrantyType": "genericLimitedNonTransferable",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-premium-plus-with-style-faux-glaze",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/faux/150_1g748.png"
            },
            {
                "paintName": "BEHR PREMIUM PLUS WITH STYLE<sup>®</sup>Venetian Plaster™",
                "warrantyType": "genericLimitedNonTransferable",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-premium-plus-with-style-venetian-plaster",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/faux/150_1g770.png"
            },
            {
                "paintName": "BEHR PREMIUM PLUS WITH STYLE<sup>®</sup>Venetian Plaster™ Topcoat",
                "warrantyType": "genericLimitedNonTransferable",
                "url": "http://www.behr.com/consumer/products/interior-paint-and-primer/behr-premium-plus-with-style-venetian-plaster-topcoat",
                "imgPath": "images/warranty/ProductsResized/InteriorPaintPrimer/faux/150_1q775.png"
            }]
        }
    },
    "Exterior Paint & Primer": {
        "name": "Exterior Paint & Primer",
        "data": {
            "BEHR MARQUEE<sup>®</sup> Exterior Paint & Primer": [{
                "paintName": "BEHR MARQUEE<sup>®</sup> Exterior Flat",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/exterior-paint-and-primer/behr-marquee-flat",
                "imgPath": "images/warranty/ProductsResized/ExteriorPaintPrimer/marquee/150_4400-01_US1g.png"
            },
            {
                "paintName": "BEHR MARQUEE<sup>®</sup> Exterior Satin Enamel",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/exterior-paint-and-primer/behr-marquee-satin-enamel",
                "imgPath": "images/warranty/ProductsResized/ExteriorPaintPrimer/marquee/150_9400-01_US1g.png"
            },
            {
                "paintName": "BEHR MARQUEE<sup>®</sup> Exterior Semi-Gloss Enamel",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/exterior-paint-and-primer/behr-marquee-semi-gloss-enamel",
                "imgPath": "images/warranty/ProductsResized/ExteriorPaintPrimer/marquee/150_5400-01_US1g.png"
            }],
            "PREMIUM PLUS ULTRA<sup>®</sup> Exterior Paint & Primer": [{
                "paintName": "PREMIUM PLUS ULTRA<sup>®</sup>Exterior Flat",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/exterior-paint-and-primer/behr-premium-plus-ultra-flat",
                "imgPath": "images/warranty/ProductsResized/ExteriorPaintPrimer/ppu/150_4850_1gWEB.png"
            },
            {
                "paintName": "PREMIUM PLUS ULTRA<sup>®</sup> Exterior Satin Enamel",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/exterior-paint-and-primer/behr-premium-plus-ultra-satin-enamel",
                "imgPath": "images/warranty/ProductsResized/ExteriorPaintPrimer/ppu/150_9850_1gWEB.png"
            },
            {
                "paintName": "PREMIUM PLUS ULTRA<sup>®</sup> Exterior Semi-Gloss Enamel",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/exterior-paint-and-primer/behr-premium-plus-ultra-semi-gloss-enamel",
                "imgPath": "images/warranty/ProductsResized/ExteriorPaintPrimer/ppu/150_5850_1gWEB.png"
            }],
            "PREMIUM PLUS<sup>®</sup> Exterior Paint": [{
                "paintName": "PREMIUM PLUS<sup>®</sup> Exterior Flat",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/exterior-paint-and-primer/behr-premium-plus-flat",
                "imgPath": "images/warranty/ProductsResized/ExteriorPaintPrimer/pp/150_4050_1gWEB.png"
            },
            {
                "paintName": "PREMIUM PLUS<sup>®</sup> Exterior Satin Enamel",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/exterior-paint-and-primer/behr-premium-plus-satin-enamel",
                "imgPath": "images/warranty/ProductsResized/ExteriorPaintPrimer/pp/150_9050_1gWEB.png"
            },
            {
                "paintName": "PREMIUM PLUS<sup>®</sup> Exterior Semi-Gloss Enamel",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/exterior-paint-and-primer/behr-premium-plus-semi-gloss-enamel",
                "imgPath": "images/warranty/ProductsResized/ExteriorPaintPrimer/pp/150_5050_1gWEB.png"
            },
            {
                "paintName": "PREMIUM PLUS<sup>®</sup> Interior/Exterior Hi-Gloss Enamel",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/exterior-paint-and-primer/premium-plus-interior-exterior-hi-gloss-enamel",
                "imgPath": "images/warranty/ProductsResized/ExteriorPaintPrimer/pp/150_8050_1gWEB.png"
            }],
            "Masonry, Stucco & Brick Paint": [{
                "paintName": "BEHR<sup>®</sup> Masonry, Stucco & Brick Paint - Flat",
                "warrantyType": "limitedMasonryStuccoBrick",
                "url": "http://www.behr.com/consumer/products/exterior-paint-and-primer/behr-masonry-stucco-and-brick-paint-flat",
                "imgPath": "images/warranty/ProductsResized/ExteriorPaintPrimer/masonry/150_270_1g.png"
            },
            {
                "paintName": "BEHR<sup>®</sup> Masonry, Stucco & Brick Paint - Satin",
                "warrantyType": "limitedMasonryStuccoBrick",
                "url": "http://www.behr.com/consumer/products/exterior-paint-and-primer/behr-masonry-stucco-and-brick-paint-satin",
                "imgPath": "images/warranty/ProductsResized/ExteriorPaintPrimer/masonry/150_280_1g.png"
            },
            {
                "paintName": "BEHR PREMIUM<sup>®</sup> Elastomeric Masonry, Stucco & Brick Paint",
                "warrantyType": "lifetimeLimited",
                "url": "http://www.behr.com/consumer/products/exterior-paint-and-primer/behr-premium-elastomeric-masonry-stucco-and-brick-paint",
                "imgPath": "images/warranty/ProductsResized/ExteriorPaintPrimer/masonry/150_68_1g.png"
            }],
            "Exterior Primers & Sealers": [{
                "paintName": "PREMIUM PLUS<sup>®</sup> Interior/Exterior Multi-Surface Primer & Sealer",
                "warrantyType": "limitedLifetime",
                "url": "http://www.behr.com/consumer/products/exterior-paint-and-primer/behr-premium-plus-multi-surface-primer-and-sealer",
                "imgPath": "images/warranty/ProductsResized/ExteriorPaintPrimer/primersealers/150_436_1gWEB.png"
            }],
            "Barn & Fence Paint": [{
                "paintName": "BEHR<sup>®</sup> Barn & Fence Paint",
                "warrantyType": "genericLimited",
                "url": "http://www.behr.com/consumer/products/exterior-paint-and-primer/behr-barn-and-fence-paint",
                "imgPath": "images/warranty/ProductsResized/ExteriorPaintPrimer/barn/150_25_1g.png"
            }],
            "Roof Paint": [{
                "paintName": "BEHR<sup>®</sup> Multi-Surface Roof Paint",
                "warrantyType": "genericLimitedNonTransferable",
                "url": "http://www.behr.com/consumer/products/exterior-paint-and-primer/behr-multi-surface-roof-paint",
                "imgPath": "images/warranty/ProductsResized/ExteriorPaintPrimer/roof/150_65_1g.png"
            }],
            "Alkyd Paint": [{
                "paintName": "BEHR<sup>®</sup> Alkyd Semi-Gloss Enamel",
                "warrantyType": "genericLimited",
                "url": "http://www.behr.com/consumer/products/exterior-paint-and-primer/behr-alkyd-semi-gloss-enamel",
                "imgPath": "images/warranty/ProductsResized/ExteriorPaintPrimer/alkyd/150_1g_3900.png"
            },
            {
                "paintName": "BEHR<sup>®</sup> Alkyd Satin Enamel",
                "warrantyType": "genericLimited",
                "url": "http://www.behr.com/consumer/products/exterior-paint-and-primer/behr-alkyd-satin-enamel",
                "imgPath": "images/warranty/ProductsResized/ExteriorPaintPrimer/alkyd/150_1g_7900.png"
            }],
            "Oil-Base Paint": [{
                "paintName": "BEHR<sup>®</sup> Oil-Base Semi-Gloss Enamel",
                "warrantyType": "genericLimited",
                "url": "http://www.behr.com/consumer/products/exterior-paint-and-primer/behr-oil-base-semi-gloss-enamel",
                "imgPath": "images/warranty/ProductsResized/ExteriorPaintPrimer/oil-base/150_1g_3800.png"
            }],
            "Concrete & Masonry Waterproofers": [{
                "paintName": "BEHR PREMIUM<sup>®</sup> Basement & Masonry Waterproofer",
                "warrantyType": "masonryWaterproofPaints",
                "url": "http://www.behr.com/consumer/products/exterior-paint-and-primer/behr-premium-concrete-and-masonry-waterproofer",
                "imgPath": "images/warranty/ProductsResized/ExteriorPaintPrimer/concretemasonry/150_875_1g.png"
            }],
        }
    },
    "Wood Stains, Finishes, Strippers & Cleaners": {
        "name": "Wood Stains, Finishes, Strippers & Cleaners",
        "data": {
            "DeckOver<sup>®</sup>": [{
                "paintName": "BEHR PREMIUM DECKOVER<sup>®</sup>",
                "warrantyType": "limitedStainsCoatings",
                "url": "http://www.behr.com/consumer/products/wood-stains-finishes-cleaners-and-strippers/behr-premium-deckover",
                "imgPath": "images/warranty/ProductsResized/WoodStainsFinishes/deckover/150_5000-N-01R_US_1g.png"
            },
            {
                "paintName": "BEHR PREMIUM Textured DECKOVER<sup>®</sup>",
                "warrantyType": "limitedStainsCoatings",
                "url": "http://www.behr.com/consumer/products/wood-stains-finishes-cleaners-and-strippers/behr-premium-textured-deckover",
                "imgPath": "images/warranty/ProductsResized/WoodStainsFinishes/deckover/150_5005-01R_US_1g.png"
            },
            {
                "paintName": "BEHR PREMIUM Extra Textured DECKOVER<sup>®</sup>",
                "warrantyType": "limitedStainsCoatings",
                "url": "http://www.behr.com/consumer/products/wood-stains-finishes-cleaners-and-strippers/behr-premium-extra-textured-deckover",
                "imgPath": "images/warranty/ProductsResized/WoodStainsFinishes/deckover/150_5015-01R_US_1g.png"
            }],
            "Wood Stains": [{
                "paintName": "BEHR<sup>®</sup> Solid Color House & Fence Wood Stain",
                "warrantyType": "houseFenceStain",
                "url": "http://www.behr.com/consumer/products/wood-stains-finishes-cleaners-and-strippers/behr-solid-color-house-and-fence-wood-stain",
                "imgPath": "images/warranty/ProductsResized/WoodStainsFinishes/woodstains/150_11-05R_US_1g.png"
            },
            {
                "paintName": "BEHR PREMIUM<sup>®</sup> Solid Color Waterproofing Stain & Sealer",
                "warrantyType": "premiumSolidColorWaterproofing",
                "url": "http://www.behr.com/consumer/products/wood-stains-finishes-cleaners-and-strippers/behr-premium-solid-color-waterproofing-stain-and-sealer",
                "imgPath": "images/warranty/ProductsResized/WoodStainsFinishes/woodstains/150_5011-01R_US_1g.png"
            },
            {
                "paintName": "BEHR PREMIUM<sup>®</sup> Semi-Transparent Waterproofing Stain & Sealer",
                "warrantyType": "premiumSemiTransparentWaterproofing",
                "url": "http://www.behr.com/consumer/products/wood-stains-finishes-cleaners-and-strippers/behr-premium-semi-transparent-waterproofing-stain-and-sealer",
                "imgPath": "images/warranty/ProductsResized/WoodStainsFinishes/woodstains/150_5077-01R_US_1g.png"
            },
            {
                "paintName": "BEHR<sup>®</sup> DECKplus™ Solid Color Waterproofing Wood Stain",
                "warrantyType": "deckplusSolidColorWaterproofing",
                "url": "http://www.behr.com/consumer/products/wood-stains-finishes-cleaners-and-strippers/behr-deckplus-solid-color-waterproofing-wood-stain",
                "imgPath": "images/warranty/ProductsResized/WoodStainsFinishes/woodstains/150_211-01R_US_1g.png"
            },
            {
                "paintName": "BEHR<sup>®</sup> DECKplus™ Semi-Transparent Waterproofing Wood Stain",
                "warrantyType": "deckplusSemiTransparentWaterproofing",
                "url": "http://www.behr.com/consumer/products/wood-stains-finishes-cleaners-and-strippers/behr-deckplus-semi-transparent-waterproofing-wood-stain",
                "imgPath": "images/warranty/ProductsResized/WoodStainsFinishes/woodstains/150_3077-01R_US_1g.png"
            },
            {
                "paintName": "BEHR<sup>®</sup> Oil-Latex Redwood Stain",
                "warrantyType": "limitedStainsCoatings",
                "url": "http://www.behr.com/consumer/products/wood-stains-finishes-cleaners-and-strippers/behr-oil-latex-redwood-stain",
                "imgPath": "images/warranty/ProductsResized/WoodStainsFinishes/woodstains/150_9_1g.png"
            }],
            "Wood Finishes": [{
                "paintName": "BEHR PREMIUM<sup>®</sup> Transparent Waterproofing Wood Finish",
                "warrantyType": "premiumTransparentWaterproofing",
                "url": "http://www.behr.com/consumer/products/wood-stains-finishes-cleaners-and-strippers/behr-premium-transparent-waterproofing-wood-finish",
                "imgPath": "images/warranty/ProductsResized/WoodStainsFinishes/woodfinishes/150_500-N-01R_US_1g.png"
            },
            {
                "paintName": "BEHR PREMIUM<sup>®</sup> Transparent Log Home Gloss Finish",
                "warrantyType": "limitedStainsCoatings",
                "url": "http://www.behr.com/consumer/products/wood-stains-finishes-cleaners-and-strippers/behr-premium-transparent-log-home-gloss-finish",
                "imgPath": "images/warranty/ProductsResized/WoodStainsFinishes/woodfinishes/150_15_1g.png"
            },
            {
                "paintName": "BEHR<sup>®</sup> DECKplus™ Transparent Waterproofing Wood Finish",
                "warrantyType": "deckplusTransparentWaterproofing",
                "url": "http://www.behr.com/consumer/products/wood-stains-finishes-cleaners-and-strippers/behr-deckplus-transparent-waterproofing-wood-finish",
                "imgPath": "images/warranty/ProductsResized/WoodStainsFinishes/woodfinishes/150_400-01R_US_1g.png"
            },
            {
                "paintName": "BEHR PREMIUM<sup>®</sup> Transparent Penetrating Oil Wood Finish",
                "warrantyType": "limitedStainsCoatings",
                "url": "http://www.behr.com/consumer/products/wood-stains-finishes-cleaners-and-strippers/behr-premium-transparent-penetrating-oil-wood-finish",
                "imgPath": "images/warranty/ProductsResized/WoodStainsFinishes/woodfinishes/150_4000-01R_US_1g.png"
            }],
            "Wood Cleaners & Strippers": [{
                "paintName": "BEHR PREMIUM<sup>®</sup> All-In-One Wood Cleaner",
                "warrantyType": "woodCleanerAndStripper",
                "url": "http://www.behr.com/consumer/products/wood-stains-finishes-cleaners-and-strippers/behr-premium-all-in-one-wood-cleaner",
                "imgPath": "images/warranty/ProductsResized/WoodStainsFinishes/woodcleaners/150_63.png"
            },
            {
                "paintName": "BEHR PREMIUM<sup>®</sup> Wood Stain & Finish Stripper",
                "warrantyType": "woodCleanerAndStripper",
                "url": "http://www.behr.com/consumer/products/wood-stains-finishes-cleaners-and-strippers/behr-premium-wood-stain-and-finish-stripper",
                "imgPath": "images/warranty/ProductsResized/WoodStainsFinishes/woodcleaners/150_64render.png"
            }]
        }
    },
    "Floor Coatings, Sealers & Prep": {
        "name": "Floor Coatings, Sealers & Prep",
        "data": {
            "Concrete Floor Paints & Coatings": [{
                "paintName": "BEHR PREMIUM<sup>®</sup> Porch & Patio Floor Paint - Low-Lustre Enamel",
                "warrantyType": "limitedStainsCoatings",
                "url": "http://www.behr.com/consumer/products/floor-coatings-sealers-and-prep/behr-premium-porch-and-patio-floor-paint-low-lustre",
                "imgPath": "images/warranty/ProductsResized/FloorCoatingsSealersPrep/concretefloorpaints/150_6050_1g.png"
            },
            {
                "paintName": "BEHR PREMIUM<sup>®</sup> Porch & Patio Floor Paint - Gloss Enamel",
                "warrantyType": "limitedStainsCoatings",
                "url": "http://www.behr.com/consumer/products/floor-coatings-sealers-and-prep/behr-premium-porch-and-patio-floor-paint-gloss",
                "imgPath": "images/warranty/ProductsResized/FloorCoatingsSealersPrep/concretefloorpaints/150_6795_1g.png"
            }],
            "Driveway & Garage Floor Coatings": [{
                "paintName": "BEHR PREMIUM<sup>®</sup> Granite Grip™",
                "warrantyType": "limitedStainsCoatings",
                "url": "http://www.behr.com/consumer/products/floor-coatings-sealers-and-prep/behr-premium-granite-grip",
                "imgPath": "images/warranty/ProductsResized/FloorCoatingsSealersPrep/drivewaygaragefloor/150_6501gWEB.png"
            },
            {
                "paintName": "BEHR PREMIUM<sup>®</sup> 1-Part Epoxy Concrete & Garage Floor Paint",
                "warrantyType": "limitedStainsCoatings",
                "url": "http://www.behr.com/consumer/products/floor-coatings-sealers-and-prep/behr-premium-one-part-epoxy-concrete-and-garage-floor-paint",
                "imgPath": "images/warranty/ProductsResized/FloorCoatingsSealersPrep/drivewaygaragefloor/150_902_1g.png"
            }],
            "Decorative Concrete Finishes": [{
                "paintName": "BEHR PREMIUM<sup>®</sup> Decorative Concrete Dye",
                "warrantyType": "limitedStainsCoatings",
                "url": "http://www.behr.com/consumer/products/floor-coatings-sealers-and-prep/behr-premium-decorative-concrete-dye",
                "imgPath": "images/warranty/ProductsResized/FloorCoatingsSealersPrep/decorativeconcrete/150_1g863WEB.png"
            }],
            "Concrete Stains": [{
                "paintName": "BEHR PREMIUM<sup>®</sup> Solid Color Concrete Stain",
                "warrantyType": "limitedStainsCoatings",
                "url": "http://www.behr.com/consumer/products/floor-coatings-sealers-and-prep/behr-premium-solid-color-concrete-stain",
                "imgPath": "images/warranty/ProductsResized/FloorCoatingsSealersPrep/concretestains/150_800_1g.png"
            },
            {
                "paintName": "BEHR PREMIUM<sup>®</sup> Semi-Transparent Concrete Stain",
                "warrantyType": "limitedStainsCoatings",
                "url": "http://www.behr.com/consumer/products/floor-coatings-sealers-and-prep/behr-premium-semi-transparent-concrete-stain",
                "imgPath": "images/warranty/ProductsResized/FloorCoatingsSealersPrep/concretestains/150_850_1g.png"
            }],
            "Concrete Floor Sealers": [{
                "paintName": "BEHR PREMIUM<sup>®</sup> Wet-Look Sealer",
                "warrantyType": "limitedStainsCoatings",
                "url": "http://www.behr.com/consumer/products/floor-coatings-sealers-and-prep/behr-premium-wet-look-sealer-985",
                "imgPath": "images/warranty/ProductsResized/FloorCoatingsSealersPrep/concretefloorsealers/150_985.png"
            },
            {
                "paintName": "BEHR PREMIUM<sup>®</sup> Low-Lustre Sealer",
                "warrantyType": "limitedStainsCoatings",
                "url": "http://www.behr.com/consumer/products/floor-coatings-sealers-and-prep/behr-premium-low-lustre-sealer-986",
                "imgPath": "images/warranty/ProductsResized/FloorCoatingsSealersPrep/concretefloorsealers/150_986.png"
            },
            {
                "paintName": "BEHR PREMIUM<sup>®</sup> Protector & Waterproofer",
                "warrantyType": "protectorWaterproofer",
                "url": "http://www.behr.com/consumer/products/floor-coatings-sealers-and-prep/concrete-and-masonry-protector-and-waterproofer",
                "imgPath": "images/warranty/ProductsResized/FloorCoatingsSealersPrep/concretefloorsealers/150_980.png"
            }],
            "Floor Enhancements & Additive": [{
                "paintName": "BEHR PREMIUM<sup>®</sup> Non-Skid Floor Finish Additive",
                "warrantyType": "limitedStainsCoatings",
                "url": "http://www.behr.com/consumer/products/floor-coatings-sealers-and-prep/behr-premium-non-skid-floor-finish-additive-970",
                "imgPath": "images/warranty/ProductsResized/FloorCoatingsSealersPrep/floorenhancements/150_flooradditive.png"
            },
            {
                "paintName": "BEHR PREMIUM<sup>®</sup> Decorative Flakes",
                "warrantyType": "limitedStainsCoatings",
                "url": "http://www.behr.com/consumer/products/floor-coatings-sealers-and-prep/behr-premium-decorative-flakes",
                "imgPath": "images/warranty/ProductsResized/FloorCoatingsSealersPrep/floorenhancements/150_decorativeflakes.png"
            }],
            "Concrete Primer": [{
                "paintName": "BEHR PREMIUM<sup>®</sup> Concrete & Masonry Bonding Primer",
                "warrantyType": "limitedStainsCoatings",
                "url": "http://www.behr.com/consumer/products/floor-coatings-sealers-and-prep/behr-premium-concrete-and-masonry-bonding-primer",
                "imgPath": "images/warranty/ProductsResized/FloorCoatingsSealersPrep/concreteprimer/150_880_1g.png"
            }]
        }
    },
    "Specialty Paint": {
        "name": "Specialty Paint",
        "data": {
            "Concrete Basement & Masonry Waterproofers": [{
                "paintName": "BEHR PREMIUM<sup>®</sup> Basement & Masonry Waterproofer",
                "warrantyType": "masonryWaterproofPaints",
                "url": "http://www.behr.com/consumer/products/specialty-paint/behr-premium-basement-and-masonry-waterproofer",
                "imgPath": "images/warranty/ProductsResized/Specialty/ConcreteBasement/150_875_1g.png"
            }],
            "Masonry, Stucco & Brick Paint": [{
                "paintName": "BEHR<sup>®</sup> Masonry, Stucco & Brick Paint - Flat",
                "warrantyType": "limitedMasonryStuccoBrick",
                "url": "http://www.behr.com/consumer/products/specialty-paint/behr-masonry-stucco-and-brick-paint-flat",
                "imgPath": "images/warranty/ProductsResized/Specialty/MasonryStuccoBrick/150_270_1g.png"
            },
            {
                "paintName": "BEHR<sup>®</sup> Masonry, Stucco & Brick Paint - Satin",
                "warrantyType": "limitedMasonryStuccoBrick",
                "url": "http://www.behr.com/consumer/products/specialty-paint/behr-masonry-stucco-and-brick-paint-satin",
                "imgPath": "images/warranty/ProductsResized/Specialty/MasonryStuccoBrick/150_280_1g.png"
            },
            {
                "paintName": "BEHR PREMIUM<sup>®</sup> Elastomeric Masonry, Stucco & Brick Paint",
                "warrantyType": "lifetimeLimited",
                "url": "http://www.behr.com/consumer/products/specialty-paint/behr-premium-elastomeric-masonry-stucco-and-brick-paint",
                "imgPath": "images/warranty/ProductsResized/Specialty/MasonryStuccoBrick/150_68_1g.png"
            }],
            "Alkyd Paint": [{
                "paintName": "BEHR<sup>®</sup> Alkyd Satin Enamel",
                "warrantyType": "genericLimited",
                "url": "http://www.behr.com/consumer/products/specialty-paint/behr-alkyd-satin-enamel",
                "imgPath": "images/warranty/ProductsResized/Specialty/Alkyd/150_1g_7900.png"
            },
            {
                "paintName": "BEHR<sup>®</sup> Alkyd Semi-Gloss Enamel",
                "warrantyType": "genericLimited",
                "url": "http://www.behr.com/consumer/products/specialty-paint/behr-alkyd-semi-gloss-enamel",
                "imgPath": "images/warranty/ProductsResized/Specialty/Alkyd/150_1g_3900.png"
            }],
            "Oil-Base Paint": [{
                "paintName": "BEHR<sup>®</sup> Oil-Base Semi-Gloss Enamel",
                "warrantyType": "genericLimited",
                "url": "http://www.behr.com/consumer/products/specialty-paint/behr-oil-base-semi-gloss-enamel",
                "imgPath": "images/warranty/ProductsResized/Specialty/Oil-Base/150_1g_3800.png"
            }],
            "Barn & Fence Paint": [{
                "paintName": "BEHR<sup>®</sup> Barn & Fence Paint",
                "warrantyType": "genericLimited",
                "url": "http://www.behr.com/consumer/products/specialty-paint/behr-barn-and-fence-paint",
                "imgPath": "images/warranty/ProductsResized/Specialty/BarnFence/150_25_1g.png"
            }],
            "Roof Paint": [{
                "paintName": "BEHR<sup>®</sup> Multi-Surface Roof Paint",
                "warrantyType": "genericLimitedNonTransferable",
                "url": "http://www.behr.com/consumer/products/specialty-paint/behr-multi-surface-roof-paint",
                "imgPath": "images/warranty/ProductsResized/Specialty/Roof/150_65_1g.png"
            }]
        }
    }
}
