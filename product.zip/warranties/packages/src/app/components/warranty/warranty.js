"use strict";

(function () {
  var app = angular.module('kiosk-colorsmart')

  app.component('warranty', {
    controller: WarrantyController,
    require: {
      parent: '^^warrantyBrowser'
    },
    bindings: {
      paintgroup: '<',
      paintsection: '<'
    },
    templateUrl: '/packages/src/app/components/warranty/warranty.html'
  })

  function WarrantyController($window, $scope, $compile, $element, ProductWarrantyService) {
    var $ctrl = this;

    $ctrl.ProductWarrantyService = ProductWarrantyService;
    $ctrl.currentPaint = null;
    $ctrl.currentWarranty = null;
    $ctrl.imgPath = null;

    $ctrl.isActive = function (paint) {
      return paint == $ctrl.currentPaint;
    }

    $ctrl.showWarrantyInfo = function (warrantyType, paintName, imgPath) {
      $ctrl.currentPaint = paintName;
      $ctrl.currentWarranty = warrantyType;
     
      $ctrl.imgPath = imgPath;

      var warrantyBody = $element.find('.warranty-body');

      warrantyBody.html("");

      // display correct warranty for current paint
      var html = "";
      var newScope = $scope.$new();
      try {
     
        html = $compile('<' + kebab_case(warrantyType) + '></' + kebab_case(warrantyType) + '>')(newScope);
       
      } catch (e) {
        html = $compile('<warranty-not-found></warranty-not-found>')(newScope);
    
      }

      warrantyBody.append(html);
    }

    $ctrl.$onChanges = function (changes) {
      if (changes.paintsection) {
        if ($ctrl.paintsection != null) {
          $ctrl.showWarrantyInfo($ctrl.ProductWarrantyService.warrantyData[$ctrl.paintgroup].data[$ctrl.paintsection][0].warrantyType, $ctrl.ProductWarrantyService.warrantyData[$ctrl.paintgroup].data[$ctrl.paintsection][0].paintName, $ctrl.ProductWarrantyService.warrantyData[$ctrl.paintgroup].data[$ctrl.paintsection][0].imgPath)
        }
      }
    }

    $ctrl.backToProducts = function () {
      $ctrl.parent.shownProduct = null;
      $ctrl.currentPaint = null;
      $ctrl.currentWarranty = null;
    }

  }

  function kebab_case(name, separator) {
    var KEBAB_CASE_REGEXP = /[A-Z]/g;

    separator = separator || '-';
    return name.replace(KEBAB_CASE_REGEXP, function (letter, pos) {
      return (pos ? separator : '') + letter.toLowerCase();
    });
  }

  app.component('deckplusSemiTransparentWaterproofing', {
    templateUrl: '/packages/src/app/components/warranty/templates/deckplus-semi-transparent-waterproofing.html'
  });
  app.component('deckplusSolidColorWaterproofing', {
    templateUrl: '/packages/src/app/components/warranty/templates/deckplus-solid-color-waterproofing.html'
  });
  app.component('deckplusTransparentWaterproofing', {
    templateUrl: '/packages/src/app//components/warranty/templates/deckplus-transparent-waterproofing.html'
  });
  app.component('genericLimited', {
    templateUrl: '/packages/src/app/components/warranty/templates/generic-limited.html'
  });
  app.component('genericLimitedNonTransferable', {
    templateUrl: '/packages/src/app/components/warranty/templates/generic-limited-non-transferable.html'
  });
  app.component('houseFenceStain', {
    templateUrl: '/packages/src/app/components/warranty/templates/house-fence-stain.html'
  });
  app.component('lifetimeLimited', {
    templateUrl: '/packages/src/app/components/warranty/templates/lifetime-limited.html'
  });
  app.component('limitedLifetime', {
    templateUrl: '/packages/src/app/components/warranty/templates/limited-lifetime.html'
  });
  app.component('limitedMasonryStuccoBrick', {
    templateUrl: '/packages/src/app/components/warranty/templates/limited-masonry-stucco-brick.html'
  });
  app.component('limitedStainsCoatings', {
    templateUrl: '/packages/src/app/components/warranty/templates/limited-stains-coatings.html'
  });
  app.component('masonryWaterproofPaints', {
    templateUrl: '/packages/src/app/components/warranty/templates/masonry-waterproof-paints.html'
  });
  app.component('premiumSemiTransparentWaterproofing', {
    templateUrl: '/packages/src/app/components/warranty/templates/premium-semi-transparent-waterproofing.html'
  });
  app.component('premiumSolidColorWaterproofing', {
    templateUrl: '/packages/src/app/components/warranty/templates/premium-solid-color-waterproofing.html'
  });
  app.component('premiumTransparentWaterproofing', {
    templateUrl: '/packages/src/app/components/warranty/templates/premium-transparent-waterproofing.html'
  });
  app.component('protectorWaterproofer', {
    templateUrl: '/packages/src/app/components/warranty/templates/protector-waterproofer.html'
  });
  app.component('woodCleanerAndStripper', {
    templateUrl: '/packages/src/app/components/warranty/templates/wood-cleaner-and-stripper.html'
  });

})();
