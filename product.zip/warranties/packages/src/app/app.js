

"use strict";

// test function
function showWarrantyBrowser() {
  angular.element(document.body).scope().$root.$emit('showWarrantyBrowser', {})
  angular.element(document.body).scope().$root.$apply()
}
(function() {
var app = angular.module('kiosk-colorsmart',['ngAnimate'])
app.controller('KioskController', function($rootScope, $window, Translation,ModalService,ProductWarrantyService) {
  var $ctrl = this;
  $ctrl.checkDeadLinkStarted = false;

  $ctrl.btnWarranty = function () {
      console.log("btn click");
    if (ModalService.modal) {
        ModalService.setModal(null);
    }
    else {
        ModalService.setModal('WarrantyBrowser');
    }
  };
  $rootScope.translate = Translation.translate;
  $ctrl.currentComponent = null;
  $ctrl.isCurrentComponent = function(componentName) {
    return $ctrl.currentComponent == componentName;
  }
  /* caluculator code*/
    $ctrl.getCalculatorLink = function () {
      switch ($ctrl.product.surface) {
        case 'interior':
          return localeService.getLocale() === 'us' ? '/consumer/paint-and-stain-calculator/interior/imperial' : '/consumer/paint-and-stain-calculator/interior/metric';

        case 'exterior':
          return localeService.getLocale() === 'us' ? '/consumer/paint-and-stain-calculator/exterior/imperial' : '/consumer/paint-and-stain-calculator/exterior/metric';

        default:
          return localeService.getLocale() === 'us' ? '/consumer/paint-and-stain-calculator/imperial' : '/consumer/paint-and-stain-calculator/metric';
      }
    };
      /* caluculator code*/

      /* product warranty code*/
     
      $ctrl.btnStartOver = function () {
        $window.btnStartOver();
      };
      $ctrl.btnLanguage = function () {
        $window.visualizer.display.find(".btnLanguage").trigger("mouseup");
      };
      $ctrl.languageOptions = function (country) {
        if ($window.locationCountry === country) {
            return true;
        }
        if (country) return false;
        return true; // if country is undefined, we'll drop through to here.
      }
       /* product warranty code*/
  $rootScope.$on('showCarpetVisualizer', function(scopeEvent, data) {
    CarpetService.useBarcode(data.barcode); // @legacy
    VisualizerService.currentRoom = VisualizerService.createRoomTemplate(CarpetRoomService.rooms.Bedroom);
    $ctrl.currentComponent = 'carpetVisualizer';
    $ctrl.shownHelp = 'firstPaint';
    checkLinkAvailability();
    if ($ctrl.checkDeadLinkStarted === false) {
      $ctrl.checkDeadLinkStarted = setInterval(checkDeadLink, 3000);
    }
  });
  $rootScope.goToMarquee = function() {
    visualizer.display.find(".btnOneCoat").trigger("mouseup");
    $rootScope.$emit('hideCarpetVisualizer', {});
  }
  $rootScope.$on('hideCarpetVisualizer', function(scopeEvent) {
    VisualizerService.currentRoom = VisualizerService.createRoomTemplate(CarpetRoomService.rooms.Bedroom);
    $ctrl.currentComponent = null;
    $ctrl.shownHelp = null;
    checkLinkAvailability();
    if ($ctrl.checkDeadLinkStarted !== false) {
      clearInterval($ctrl.checkDeadLinkStarted, 3000);
      $ctrl.checkDeadLinkStarted = false;
    }
  });
  $ctrl.hideHelp = function() {
    $ctrl.shownHelp = false;
  }
  $rootScope.$on('KioskNgHelp.setHelp', function(scopeEvent, data) {
    $ctrl.shownHelp = data;
  });
});

app.factory('Translation', function($window, $rootScope, $sce) {
  var terms = $window.angular_translation;
  $rootScope.$on('translationText', function(data) {
    terms = data;
  });
  var translation = {
    translate: function(key) {
      if (terms.hasOwnProperty(key)) {
        return $sce.trustAsHtml(terms[key]);
      }
      else {
        return $sce.trustAsHtml(key);
      }
      
    }
  }
  translation._ = translation.translate;
  return translation;
})
.filter('trustHtml', function($sce) {
  return function(str) {
    if (!str) return $sce.trustAsHtml("");
    return $sce.trustAsHtml(str);
  }
})
.filter('removeBRtags', function($sce) {
  return function(str) {
    if (!str) return false;
    return $sce.trustAsHtml(str.$$unwrapTrustedValue().replace(new RegExp('<br/>', 'g'),' '));
  }
})
.filter('translate', function(Translation) {
  return function(input) {
    return Translation.translate(input);
  };
})
.filter('newlines', function ($sce) {
    return function(text) {
      if (text.$$unwrapTrustedValue) {
        return $sce.trustAsHtml(text.$$unwrapTrustedValue().replace(/\n/g, '<br/>'));
      }
      else {
        return text.replace(/\n/g, '<br/>');
      }
    }
})

})();