

(function () {
    // width 1080
    var app = angular.module('kiosk-colorsmart')
    app.factory('ModalService', function($rootScope) {
        var modalService = {
            modal: false,
            setModal: function(modal) {
                modalService.modal = modal;
            }
        };
        $rootScope.$on('modal', function (scopeEvent, data) {
            modalService.setModal(data);
        });
        return modalService;
    })
    app.controller('KioskModalController', function (ModalService, $scope, $element) {
        var $ctrl = this;
        $ctrl.ModalService = ModalService;
        $ctrl.height = $("#colorsmart").height();
        $ctrl.width = $("#colorsmart").width();
        $ctrl.getClass = function() {
            var ret = {};
            if (!$ctrl.ModalService.modal) return ret;
            ret[$ctrl.ModalService.modal] = true;
            return ret;
        }
        $ctrl.position = function () {
            if ($ctrl.ModalService.modal) return "absolute";
            else return "static";
        }
        $ctrl.onClose = function () {
            if($ctrl.ModalService.modal == "WarrantyBrowser") $(".btnWarranty .nav-arrow").toggleClass("arrow-down arrow-up");
            $ctrl.ModalService.setModal(null);
        }
        $ctrl.curtainStyle = function () {
            if ($ctrl.ModalService.modal) {
                var heightReduction = 0;
                if ($ctrl.ModalService.modal == "WarrantyBrowser") {
                    heightReduction = 69;
                }
                return {
                    opacity: 0.7,
                    display: 'block',
                    width: $ctrl.width,
                    height: $ctrl.height - heightReduction
                };
            }
            return {
                opacity: 0,
                display: 'none'
            };
        }
        $scope.$watch('$ctrl.ModalService.modal', function (scopeEvent, data) {
            $ctrl.height = $("#colorsmart").height();
            $ctrl.width = $("#colorsmart").width();
        })
    })
    app.component('kioskNgModal', {
        controller: function () {
            var $ctrl = this;
            $ctrl.close = function () {
                $ctrl.onClose();
            }
            $ctrl.centerX = function ($element) {
                $element.children()[0].style.left = (($ctrl.width - $element.children()[0].offsetWidth) / 2) + 'px';
            }
            $ctrl.centerY = function ($element) {
                $element.children()[0].style.top = (($ctrl.height - $element.children()[0].offsetHeight) / 2) + 'px';
            }
        },
        bindings: {
            width: '<',
            height: '<',
            modal: '<',
            onClose: '&',
        },
        template: '<kiosk-change-room ng-if="$ctrl.modal==\'ChangeRoom\'"></kiosk-change-room><kiosk-carpet-email ng-if="$ctrl.modal==\'CarpetEmail\'"></kiosk-carpet-email><kiosk-carpet-phone ng-if="$ctrl.modal==\'CarpetPhone\'"></kiosk-carpet-phone><warranty-browser ng-if="$ctrl.modal==\'WarrantyBrowser\'"></warranty-browser>'
    })
    app.component('kioskChangeRoom', {
        require: {
            'parent': '^kioskNgModal'
        },
        controller: function (VisualizerService, CarpetRoomService, $rootScope, $element, $scope, $window) {
            var $ctrl = this;
            $ctrl.$onInit = function () {
                $ctrl.close = $ctrl.parent.close;
                $ctrl.rooms = CarpetRoomService.rooms;
                $ctrl.parent.centerX($element);
                $ctrl.parent.centerY($element);
            }
            $ctrl.selectRoom = function (room) {
                VisualizerService.currentRoom = VisualizerService.createRoomTemplate(room);
                $ctrl.close();
            }
        },
        templateUrl: '/KioskServices/app/components/modals/change-room-modal.html'
    })
    app.component('warrantyBrowser', {
        require: {
            'parent': '^kioskNgModal'
        },
        controller: function (ProductWarrantyService) {
            var $ctrl = this;
            
            $ctrl.ProductWarrantyService = ProductWarrantyService;

            $ctrl.shownCategory = null;
            $ctrl.shownProduct = null;
          
            $ctrl.iconList = ["interior-paint", "exterior-paint", "wood-stains", "floor-coatings", "specialty-paint"];

            $ctrl.setCategory = function (categoryName) {
                if($ctrl.shownCategory == categoryName){
                    $ctrl.shownCategory = null;
                }else{
                    $ctrl.shownCategory = categoryName;
                }
            }

            $ctrl.setProduct = function (productName) {
                if($ctrl.shownProduct == productName){
                    $ctrl.shownProduct = null;
                }else{
                    $ctrl.shownProduct = productName;
                } 
            }
            
            $ctrl.getIcon = function (category) {
              switch (category) {
                case "":
                  return 
                  break;
                case "":
                  
                  break;
              }
            }
            
            $ctrl.isActive = function(category){
              return category == $ctrl.shownCategory;
            }
        },
        templateUrl: '/packages/src/app/components/modals/warranty-browser-modal.html'
    })
    app.factory('setImgUrl', function (VisualizerService, PaletteService, CarpetService) {
        return function setImgUrl() {
            var imgUrl = "render?roomId=" + VisualizerService.currentRoom.id;
            var maxBindings = Math.max(10, VisualizerService.currentRoom.bindings.length);
            for (var i = 0; i < maxBindings; i++) {
                if (VisualizerService.currentRoom.bindings[i] >= 0 && PaletteService.palette.colors[VisualizerService.currentRoom.bindings[i]] != undefined) {
                    imgUrl += "&surfaceId" + (i + 1) + "=" + VisualizerService.currentRoom.surfaces[i].surfaceId + "&color" + (i + 1) + "=" + PaletteService.palette.colors[VisualizerService.currentRoom.bindings[i]].id;
                } else {
                    imgUrl += "&surfaceId" + (i + 1) + "=&color" + (i + 1) + "=";
                }
            }
            imgUrl += "&surfaceId11=11&color11=" + CarpetService.carpet.barcode;
            return imgUrl;
        }
    })
    app.component('kioskCarpetEmail', {
        require: {
            'parent': '^kioskNgModal'
        },
        controller: function ($rootScope, $element, $scope, PaletteService, VisualizerService, CarpetService, $window, setImgUrl) {
            var $ctrl = this;
            $ctrl.target = null;
            $ctrl.targetSelectionStart = 0;
            $ctrl.targetSelectionEnd = 0;
            $ctrl.emailRegEx = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            $ctrl.emailForm = {
                to: "",
                from: "colorsmart@behr.com",
                country: "US",
                zip: "",
                subject: "What do you think of this, Honey?",
                optIn: "N",
                html: {
                    parameters: {
                        senderName: this.name,
                        storeName: "My Local Home Depot",
                        city: "Birmingham, Alabama"
                    }
                },
                objects: {
                    StoreVO: {
                        storeNumber: ($window.storeId.substr(0, 2) == "hd") ? $window.storeId.substr(2, 4) : $window.storeId
                    },
                    ColorVO: {}
                },
                image1: {
                    restURI: setImgUrl()
                },
                name: "",
                email: "",
                additionalEmails: "",
            }

            function setColorCode(color) {
                if (color)
                    return color.id;
                else
                    return ""
            }

            $ctrl.$onInit = function () {
                $ctrl.target = $element.find('input[name=name]')[0];
                $ctrl.target.focus();
                $ctrl.showPrivacyPolicy = false;
                $ctrl.close = $ctrl.parent.close;
                $ctrl.parent.centerX($element);
                $ctrl.parent.centerY($element);
            }

            function omitKeys(obj, keys) {
                var dup = {};
                for (var key in obj) {
                    if (keys.indexOf(key) == -1) {
                        dup[key] = obj[key];
                    }
                }
                return dup;
            }

            function formatEmailData(email) {
                email.objects.ColorVO = {};
                PaletteService.palette.colors.forEach(function (color, index) {
                    if (!color) return;
                    email.objects.ColorVO["colorCode" + (index + 1)] = color.id;
                })
                var to = email.email;
                var emails = email.additionalEmails ? email.additionalEmails.replace(/(\r\n|\n|\r)/gm, "").split(",") : null;
                if (emails) {
                    to += ";"
                    for (var i = 0; i < emails.length; i++) {
                        to += emails[i] + ";";
                    }
                }
                to.replace(" ", "");
                email.to = to;
                email.html.parameters.senderName = email.name;
                var languageType = ($window.language.substr(0, 2) == "es" ? "Es_" : $window.language.substr(0, 2) == "fr" ? "Fr_" : ($window.language.substr(0, 2) == "en" && $window.language.substr(3, 2) == "CA") ? "Ca_" : "");
                return '{"' + languageType + 'KioskProjectEmailBravoCarpet" :' + JSON.stringify(omitKeys(email, ['name', 'email', 'additionalEmails'])) + "}";
            }
            $ctrl.sendEmail = function () {
                var dString = formatEmailData($ctrl.emailForm);
                if ($ctrl.emailForm.name.length > 0 && $ctrl.emailForm.from.length > 0 && $ctrl.emailForm.to.length > 0) {
                    $.ajax({
                        type: "POST",
                        contentType: "text/plain",
                        dataType: "text",
                        //url: userSession._serviceUrl + "/email/send",
                        url: "http://" + serverName + "/emailnx/send",
                        async: true,
                        data: dString,
                        success: function (data) {
                            $scope.$apply(function () {
                                $ctrl.close();
                            });
                            showModal(sendEmailConfirmation);
                        },
                        error: function (xhr, textStatus, errorThrown) {
                            $scope.$apply(function () {
                                $ctrl.close();
                            });
                            showModal(networkError);
                        }
                    });
                }

                //Share using Email Button Sent/Submitted
                dataLayer.push({
                    'carpetName': '',
                    'carpetCode': '',
                    'event': 'CarpetSendProjectByEmailSubmitted'
                });

            }
            $ctrl.onFocus = function (e) {
                $ctrl.target = e.target;
            }
            $ctrl.onMouseUp = function (e) {
                $ctrl.targetSelectionStart = e.target.selectionStart;
                $ctrl.targetSelectionEnd = e.target.selectionEnd;
            }
            $ctrl.onKeyPress = function (key) {
                $ctrl.target.focus();
                $ctrl.target.value = $ctrl.target.value.slice(0, $ctrl.targetSelectionStart) + key + $ctrl.target.value.slice($ctrl.targetSelectionEnd);
                angular.element($ctrl.target).triggerHandler('input');
                setCaretPosition($ctrl.target, $ctrl.targetSelectionStart + 1);
            }
            $ctrl.backspace = function () {
                $ctrl.target.focus();
                var val = $ctrl.target.value;
                $ctrl.target.value = $ctrl.target.value.slice(0, Math.max(0, $ctrl.targetSelectionStart - 1)) + $ctrl.target.value.slice($ctrl.targetSelectionEnd);
                $ctrl.targetSelectionStart = Math.max(0, $ctrl.targetSelectionStart - 1);
                $ctrl.targetSelectionEnd = $ctrl.targetSelectionStart;
                setCaretPosition($ctrl.target, $ctrl.targetSelectionStart);
                angular.element($ctrl.target).triggerHandler('input');
            }
            $ctrl.return = function () {
                $ctrl.target.focus();
                if ($ctrl.target.name === "additionalEmails") $ctrl.target.value += ",\n";
                setCaretPosition($ctrl.target, $ctrl.target.value.length);
                angular.element($ctrl.target).triggerHandler('input');
            }

            function setCaretPosition(elem, caretPos) {
                $ctrl.targetSelectionStart = caretPos;
                $ctrl.targetSelectionEnd = Math.max($ctrl.targetSelectionStart, $ctrl.targetSelectionEnd);
                if (elem == null) return;
                if (elem.createTextRange) {
                    var range = elem.createTextRange();
                    range.move('character', caretPos);
                    range.select();
                } else {
                    if (elem.selectionStart) {
                        elem.setSelectionRange(caretPos, caretPos);
                    }
                }
            }
        },
        templateUrl: '/KioskServices/app/components/modals/carpet-email-modal.html'
    })
    app.component('kioskCarpetPhone', {
        require: {
            'parent': '^kioskNgModal'
        },
        controller: function ($rootScope, $element, setImgUrl, $window, PaletteService, $scope, $interval) {
            var $ctrl = this;
            $ctrl.dots = ".";
            $ctrl.code = false;
            $ctrl.number = false;
            $ctrl.emailForm = {
                sendMobile: "Y",
                from: "jmiraglia@banddigital.com",
                subject: "What do you think of this, Honey?",
                optIn: "N",
                html: {
                    parameters: {
                        senderName: "Jason Miraglia",
                        storeName: "My Local Home Depot",
                        city: "Birmingham, Alabama"
                    }
                },
                objects: {
                    StoreVO: {
                        storeNumber: ($window.storeId.substr(0, 2) == "hd") ? $window.storeId.substr(2, 4) : $window.storeId
                    },
                    ColorVO: {}
                },
                image1: {
                    restURI: setImgUrl()
                }
            };
            $ctrl.getCode = function () {
                if (!$ctrl.code) return $ctrl.dots;
                return $ctrl.code;
            }
            $ctrl.getNumber = function () {
                if (!$ctrl.number) return $ctrl.dots;
                return $ctrl.number;
            }
            $ctrl.$onInit = function () {
                $ctrl.showPrivacyPolicy = false;
                $ctrl.close = $ctrl.parent.close;
                $ctrl.parent.centerX($element);
                $ctrl.parent.centerY($element);
                $ctrl.sendPhone();
                $ctrl.dotsInterval = $interval(function () {
                    $ctrl.dots += ".";
                    if ($ctrl.dots.length >= 5) {
                        $ctrl.dots = ".";
                    }
                }, 1000);
            }
            $ctrl.$onDestroy = function () {
                $interval.cancel($ctrl.dotsInterval);
            }
            $ctrl.sendEmail = function () {
                $ctrl.close();
                $rootScope.$emit('modal', 'CarpetEmail');
            }

            function formatPhoneData(data) {
                data.objects.ColorVO = {};
                PaletteService.palette.colors.forEach(function (color, index) {
                    if (!color) return;
                    data.objects.ColorVO["colorCode" + (index + 1)] = color.id;
                })
                var languageType = ($window.language.substr(0, 2) == "es" ? "Es_" : $window.language.substr(0, 2) == "fr" ? "Fr_" : ($window.language.substr(0, 2) == "en" && $window.language.substr(3, 2) == "CA") ? "Ca_" : "");
                return '{"' + languageType + 'KioskProjectEmailBravoCarpet" :' + JSON.stringify(data) + "}";
            }
            $ctrl.sendPhone = function () {
                dataLayer.push({
                    'carpetName': '',
                    'carpetCode': '',
                    'event': 'CarpetSendProjectByPhoneSubmitted'
                });
                var dString = formatPhoneData($ctrl.emailForm);
                $.ajax({
                    type: "POST",
                    contentType: "text/plain",
                    dataType: "text",
                    url: "http://" + serverName + "/emailnx/send",
                    async: true,
                    data: dString,
                    success: function (data) {
                        $scope.$apply(function () {
                            var vars = data.split(";");
                            for (var i = 0; i < (vars.length - 1); i++) {
                                vars[i] = vars[i].split(":")[1];
                                console.info("variable value: " + vars[i]);
                            }
                            $ctrl.code = vars[0];
                            $ctrl.number = vars[1];
                        });
                        dataLayer.push({
                            'carpetName': '',
                            'carpetCode': '',
                            'event': 'CarpetSendProjectByPhoneSubmitted'
                        });
                    },
                    error: function (xhr, textStatus, errorThrown) {
                        $scope.$apply(function () {
                            $ctrl.close();
                        });
                        showModal(networkError);
                    }
                });
            }
        },
        templateUrl: '/KioskServices/app/components/modals/carpet-phone-modal.html'
    })
    app.factory('ProductWarrantyService', function ($rootScope, $window) {
      
        this.currentWarranty = {};
        this.warrantyData = $window._warranty;
        
        this.setWarranty = function(warranty, paintName) {
          this.currentWarranty.type = warranty;
          this.currentWarranty.paint = paintName;
        }
        
        return this;
      });
})();
