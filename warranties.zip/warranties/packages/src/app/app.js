"use strict";

// test function
// function showWarrantyBrowser() {
//   angular.element(document.body).scope().$root.$emit('showWarrantyBrowser', {})
//   angular.element(document.body).scope().$root.$apply()
// }
(function() {
var app = angular.module('kiosk-colorsmart',['ngAnimate'])
app.controller('KioskController', function($rootScope, $window) {
  var $ctrl = this;
  
  console.log("angular set up");
});

app.factory('Translation', function($window, $rootScope, $sce) {
  var terms = $window.angular_translation;
  $rootScope.$on('translationText', function(data) {
    terms = data;
  });
  var translation = {
    translate: function(key) {
      if (terms.hasOwnProperty(key)) {
        return $sce.trustAsHtml(terms[key]);
      }
      else {
        return $sce.trustAsHtml(key);
      }
      
    }
  }
  translation._ = translation.translate;
  return translation;
})
.filter('trustHtml', function($sce) {
  return function(str) {
    if (!str) return $sce.trustAsHtml("");
    return $sce.trustAsHtml(str);
  }
})
.filter('removeBRtags', function($sce) {
  return function(str) {
    if (!str) return false;
    return $sce.trustAsHtml(str.$$unwrapTrustedValue().replace(new RegExp('<br/>', 'g'),' '));
  }
})
.filter('translate', function(Translation) {
  return function(input) {
    return Translation.translate(input);
  };
})
.filter('newlines', function ($sce) {
    return function(text) {
      if (text.$$unwrapTrustedValue) {
        return $sce.trustAsHtml(text.$$unwrapTrustedValue().replace(/\n/g, '<br/>'));
      }
      else {
        return text.replace(/\n/g, '<br/>');
      }
    }
})

})();