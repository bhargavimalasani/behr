(function() {
  "use strict";
  var app = angular.module('behrCore');
  var host = location.host;
  app.factory('$serviceURL', function() {
    return '';
  })
}());