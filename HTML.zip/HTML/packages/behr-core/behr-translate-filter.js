(function() {
  "use strict";
  var app = angular.module('behrCore');
  
  app.factory('behrTranslate', function($filter) {
    return $filter('translate');
  });
}());
