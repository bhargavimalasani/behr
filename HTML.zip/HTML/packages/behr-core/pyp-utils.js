(function() {
  "use strict";
  var app = angular.module('behrCore');

  app.factory('pypUtils', function(paletteService, $q) {
    var W = 706;
    var H = 508;
    var pypUtils = {
      W: W,
      H: H,
      maskingLine: {
        drawing: false,
        startX: 0,
        startY: 0,
        endX: 0,
        endY: 0
      },
      maskingPoly: {
        drawing: false,
        startX: 0,
        startY: 0,
        mouseX: 0,
        mouseY: 0,
        coords: [],
      },
      maskingPolyMagnetRadius: 10,
      hexToRgba(hex) {
        var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? {
          r: parseInt(result[1], 16),
          g: parseInt(result[2], 16),
          b: parseInt(result[3], 16),
          a: 255
        } : null;
      },
      drawImageToCanvas(src, canvas) {
        var deferred = $q.defer();
        var img = new Image();
        img.onload = function() {
          canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
          deferred.resolve();
        }
        img.src = src;
        return deferred.promise;
      },
      createEdgeAndCanny(pypCanvasDB, doBilateralSmoothing, preserveDrawing) {
        doBilateralSmoothing = doBilateralSmoothing || false;
        // Remake edge and canny canvases, and main edge image
        var preImage = pypCanvasDB.predrawing.getContext("2d").getImageData(0, 0, pypCanvasDB.predrawing.width, pypCanvasDB.predrawing.height);

        var smoothedImage;
        if (doBilateralSmoothing) {
          smoothedImage = bilateral_smoothing(pypCanvasDB.drawingContext, preImage, 3, 3, 2, 15, 2);
        } else {
          smoothedImage = preImage;
        }
        if (!preserveDrawing) pypCanvasDB.drawingContext.putImageData(smoothedImage, 0, 0);

        var smoothCanvas = pypCanvasDB.smooth.getContext("2d");
        var grayscaleCanvas = pypCanvasDB.grayscale.getContext("2d");
        var sobelCanvas = pypCanvasDB.sobel.getContext("2d");
        var cannyCanvas = pypCanvasDB.canny.getContext("2d");
        var dilatationCanvas = pypCanvasDB.dilatation.getContext("2d");
        var erosionCanvas = pypCanvasDB.erosion.getContext("2d");

        smoothCanvas.putImageData(smoothedImage, 0, 0);

        var grayscaleImage = image_desaturate(preImage);
        grayscaleCanvas.putImageData(grayscaleImage, 0, 0);

        var sobelImage = image_sobel(pypCanvasDB.smooth, grayscaleImage);
        sobelCanvas.putImageData(sobelImage, 0, 0);

        var cannyImage = image_canny(pypCanvasDB.canny, grayscaleImage, 0, 1, 0.5);
        cannyCanvas.putImageData(cannyImage, 0, 0);

        var dilatatedImage = pypUtils.dilatation(pypCanvasDB.drawingContext, sobelImage);
        dilatationCanvas.putImageData(dilatatedImage, 0, 0);

        var erosionImage = pypUtils.erosion(pypCanvasDB.drawingContext, dilatatedImage);
        erosionCanvas.putImageData(erosionImage, 0, 0);

        pypCanvasDB.bucketEdge.getContext("2d").putImageData(erosionImage, 0, 0);
        pypCanvasDB.originalEdge.getContext("2d").putImageData(erosionImage, 0, 0);

        // @todo should we move this somewhere else?
        // Redraw masking lines on edge canvas here
        pypUtils.drawLines(pypCanvasDB.maskingLines, pypCanvasDB.maskingTop);
      },
      removeAllMasking(pypCanvasDB) {
        // Store undo state
        pypCanvasDB.undo.save();

        // Clear masking on edge canvas
        pypCanvasDB.bucketEdge.getContext("2d").drawImage(pypCanvasDB.originalEdge, 0, 0);

        // Clear masking canvas user sees
        // Get rid of masking lines
        // reset masking tools
        pypUtils.resetMasking(pypCanvasDB);
        pypUtils.resetMaskingTool();

        // Reset hide/show masking
        pypCanvasDB.saveSessionState();
      },
      resetMasking(pypCanvasDB) {
        var canvasMaskingTopContext = pypCanvasDB.maskingTop.getContext("2d");
        canvasMaskingTopContext.clearRect(0, 0, pypCanvasDB.maskingTop.width, pypCanvasDB.maskingTop.height);
        pypCanvasDB.maskingLines = [];
      },
      resetMaskingTool() {
        pypUtils.maskingLine = {
          drawing: false,
          startX: 0,
          startY: 0,
          endX: 0,
          endY: 0
        };
        pypUtils.maskingPoly = {
          drawing: false,
          startX: 0,
          startY: 0,
          mouseX: 0,
          mouseY: 0,
          coords: [],
        };
      },
      drawLine(line, lineContext, lineColor) {
        lineContext.strokeStyle = lineColor;
        lineContext.fillStyle = lineColor;
        lineContext.lineWidth = 1.5;
        lineContext.beginPath();
        lineContext.moveTo(line.x1, line.y1);
        lineContext.lineTo(line.x2, line.y2);
        lineContext.stroke();
      },
      drawLines(maskingLines, maskingTop) {
        var maskingTopContext = maskingTop.getContext("2d");
        maskingTopContext.clearRect(0, 0, W, H);
        // redraw all previous lines
        for (var i = 0; i < maskingLines.length; i++) {
          pypUtils.drawLine(maskingLines[i], maskingTopContext, '#ffffff');
        }

        // draw the current line
        if (pypUtils.maskingLine.drawing) {
          pypUtils.drawLine({
            x1: pypUtils.maskingLine.startX,
            y1: pypUtils.maskingLine.startY,
            x2: pypUtils.maskingLine.endX,
            y2: pypUtils.maskingLine.endY
          }, maskingTopContext, '#ffffff');
        }

        // draw the in progress polygon
        if (pypUtils.maskingPoly.drawing) {
          pypUtils.maskingPoly.coords.forEach((point, index) => {
            if (index === 0) return;
            pypUtils.drawLine({
              x1: pypUtils.maskingPoly.coords[index - 1].x,
              y1: pypUtils.maskingPoly.coords[index - 1].y,
              x2: point.x,
              y2: point.y
            }, maskingTopContext, '#ffffff');
          });
          pypUtils.drawMaskingPolyCircle(pypUtils.maskingPoly.startX,
            pypUtils.maskingPoly.startY,
            pypUtils.maskingPolyMagnetRadius,
            maskingTop);
          if (pypUtils.maskingPoly.mouseX !== 0 && pypUtils.maskingPoly.mouseY !== 0) {
            pypUtils.drawLine({
              x1: pypUtils.maskingPoly.coords[pypUtils.maskingPoly.coords.length - 1].x,
              y1: pypUtils.maskingPoly.coords[pypUtils.maskingPoly.coords.length - 1].y,
              x2: pypUtils.maskingPoly.mouseX,
              y2: pypUtils.maskingPoly.mouseY
            }, maskingTopContext, '#ffffff');
          }
        }
      },
      drawMaskingPolyCircle(x, y, r, maskingTop) {
        var canvasMaskTopContext = maskingTop.getContext('2d');
        canvasMaskTopContext.strokeStyle = '#ffffff';
        canvasMaskTopContext.lineWidth = 1.5;
        canvasMaskTopContext.beginPath();
        canvasMaskTopContext.arc(x, y, r, 0, Math.PI * 2, true);
        canvasMaskTopContext.closePath();
        canvasMaskTopContext.stroke();
      },
      // drawingContext is only used to createImageData(), recievedImageDataObj is the actual imagedata which is operated upon
      erosion(drawingContext, recievedImageDataObj) {
        var tempErosionDataObj = drawingContext.createImageData(recievedImageDataObj.width, recievedImageDataObj.height);
        var x, y;
        var size = 3;

        //var se = new Array[3, 3] { { 1, 1, 1 }, { 1, 1, 1 }, { 1, 1, 1 } };
        var se = new Array(3);
        for (x = 0; x < se.length; x++) {
          se[x] = new Array(3);
        }
        for (x = 0; x < se.length; x++) {
          for (var z = 0; z < se.length; z++) {
            se[x][z] = 1;
          }
        }

        var r = size >> 1;
        var superI = 0; // iterator through pixel array of image
        var superX;
        var p1;
        var p2;
        var p3;

        for (y = 0; y < recievedImageDataObj.height; y++) {
          var minR, minG, minB, v;

          var foundSomething = false;

          // loop and array indexes
          var t, ir, jr, i, j;

          for (x = 0; x < recievedImageDataObj.width; x++) {
            superI = (y * (recievedImageDataObj.width * 4)) + (x * 4);

            minR = 255;
            minG = 255;
            minB = 255;

            foundSomething = false;

            // for each structuring element's row
            for (i = 0; i < size; i++) {
              ir = i - r;
              t = y + ir;

              // skip row
              if (t < 0)
                continue;
              // break
              if (t >= recievedImageDataObj.height)
                break;

              // for each structuring element's column
              for (j = 0; j < size; j++) {
                jr = j - r;
                t = x + jr;

                // skip column
                if (t < 0)
                  continue;
                if (t < recievedImageDataObj.width) {
                  if (se[i][j] == 1) {
                    foundSomething = true;
                    // get new MIN values

                    superX = superI + (ir * recievedImageDataObj.width * 4) + (jr * 4);
                    p1 = recievedImageDataObj.data[superX];
                    p2 = recievedImageDataObj.data[superX + 1];
                    p3 = recievedImageDataObj.data[superX + 2];

                    // red
                    v = p1;
                    if (v < minR)
                      minR = v;

                    // green
                    v = p2;
                    if (v < minG)
                      minG = v;

                    // blue
                    v = p3;
                    if (v < minB)
                      minB = v;
                  }
                }
              }
            }
            // result pixel
            if (foundSomething) {
              tempErosionDataObj.data[superI] = minR;
              tempErosionDataObj.data[superI + 1] = minG;
              tempErosionDataObj.data[superI + 2] = minB;
              tempErosionDataObj.data[superI + 3] = 255;
            } else {
              tempErosionDataObj.data[superI] = recievedImageDataObj.data[superI];
              tempErosionDataObj.data[superI + 1] = recievedImageDataObj.data[superI + 1];
              tempErosionDataObj.data[superI + 2] = recievedImageDataObj.data[superI + 2];
              tempErosionDataObj.data[superI + 3] = 255;
            }
          }
        }

        return tempErosionDataObj;
      },
      // drawingContext is only used to createImageData(), recievedImageDataObj is the actual imagedata which is operated upon
      dilatation(drawingContext, recievedImageDataObj) {
        var tempDilatationDataObj = drawingContext.createImageData(recievedImageDataObj.width, recievedImageDataObj.height);
        var x;
        var size = 3;
        var se = new Array(3);

        for (x = 0; x < se.length; x++) {
          se[x] = new Array(3);
        }
        for (x = 0; x < se.length; x++) {
          for (var z = 0; z < se.length; z++) {
            se[x][z] = 1;
          }
        }

        var r = size >> 1;
        var superI = 0; // iterator through pixel array of image
        var superX;
        var p1;
        var p2;
        var p3;

        for (var y = 0; y < recievedImageDataObj.height; y++) {
          var maxR, maxG, maxB, v;

          var foundSomething = false;

          // loop and array indexes
          var t, ir, jr, i, j;

          for (x = 0; x < recievedImageDataObj.width; x++) {
            superI = (y * (recievedImageDataObj.width * 4)) + (x * 4);

            maxR = 0;
            maxG = 0;
            maxB = 0;

            foundSomething = false;

            // for each structuring element's row
            for (i = 0; i < size; i++) {
              ir = i - r;
              t = y + ir;

              // skip row
              if (t < 0)
                continue;
              // break
              if (t >= recievedImageDataObj.height)
                break;

              // for each structuring element's column
              for (j = 0; j < size; j++) {
                jr = j - r;
                t = x + jr;

                // skip column
                if (t < 0)
                  continue;
                if (t < recievedImageDataObj.width) {
                  if (se[i][j] == 1) {
                    foundSomething = true;
                    // get new MAX values

                    superX = superI + (ir * recievedImageDataObj.width * 4) + (jr * 4);
                    p1 = recievedImageDataObj.data[superX];
                    p2 = recievedImageDataObj.data[superX + 1];
                    p3 = recievedImageDataObj.data[superX + 2];

                    // red
                    v = p1;
                    if (v > maxR)
                      maxR = v;

                    // green
                    v = p2;
                    if (v > maxG)
                      maxG = v;

                    // blue
                    v = p3;
                    if (v > maxB)
                      maxB = v;
                  }
                }
              }
            }
            // result pixel
            if (foundSomething) {
              tempDilatationDataObj.data[superI] = maxR;
              tempDilatationDataObj.data[superI + 1] = maxG;
              tempDilatationDataObj.data[superI + 2] = maxB;
              tempDilatationDataObj.data[superI + 3] = 255;
            } else {
              tempDilatationDataObj.data[superI] = recievedImageDataObj.data[superI];
              tempDilatationDataObj.data[superI + 1] = recievedImageDataObj.data[superI + 1];
              tempDilatationDataObj.data[superI + 2] = recievedImageDataObj.data[superI + 2];
              tempDilatationDataObj.data[superI + 3] = 255;
            }

            if (tempDilatationDataObj.data[superI] === 0 && tempDilatationDataObj.data[superI + 1] === 0 && tempDilatationDataObj.data[superI + 2] === 0) {
              tempDilatationDataObj.data[superI + 3] = 0;
            }
          }
        }

        return tempDilatationDataObj;
      },
      isNearbyPixel(colorData, r, g, b, tolerance, x, y, cannyData) {
        //@TODO implement canny edge detection and have this also account for canny edges to straighten out the edges.
        var maxX = x + tolerance;
        if (maxX > W) maxX = W - 1;
        var minX = x - tolerance;
        if (minX < 0) minX = 0;

        var maxY = y + tolerance;
        if (maxY > H) maxY = H - 1;
        var minY = y - tolerance;
        if (minY < 0) minY = 0;

        var isNearby = false;
        var curi = ((y * (W * 4)) + (x * 4));
        var actuali = ((y * (W * 4)) + (x * 4));
        for (var curX = minX; curX <= maxX; curX++) {
          for (var curY = minY; curY <= maxY; curY++) {
            var i = ((curY * (W * 4)) + (curX * 4));
            if ((colorData[i] == r && colorData[i + 1] == g && colorData[i + 2] == b) || (cannyData[i] > 125)) {
              if (curX < maxX && curY < maxY && cannyData[curi] < 125) {
                if (cannyData[i] < 125) return 2;
                else return 1;
              }
              return true;
            }
          }

        }

        return false;
      }
    };

    function bilateral_smoothing(drawingContext, srcData, kernelRadius, spatialFactor, spatialPower, colorFactor, colorPower) {
      var dstData = drawingContext.createImageData(W, H);

      var colorsCount = 256;
      var kernelSize = kernelRadius * 2;

      var spatialMatrix; // spatialMatrix[][];
      var colorMatrix; // colorMatrix[][];

      // Build spatial matrix
      spatialMatrix = new Array(kernelSize);
      for (var a = 0; a < spatialMatrix.length; a++) {
        spatialMatrix[a] = new Array(kernelSize);
      }

      for (var b = 0; b < kernelSize; b++) {
        var tb = b - kernelRadius;
        var tb2 = tb * tb;

        for (var c = 0; c < kernelSize; c++) {
          var tc = c - kernelRadius;
          var tc2 = tc * tc;

          spatialMatrix[b][c] = Math.exp(-0.5 * Math.pow(Math.sqrt((tb2 + tc2) / spatialFactor), spatialPower));
        }
      }

      // Build color matrix
      colorMatrix = new Array(colorsCount);
      for (var d = 0; d < colorMatrix.length; d++) {
        colorMatrix[d] = new Array(colorsCount);
      }

      for (var e = 0; e < colorsCount; e++) {
        for (var f = 0; f < colorsCount; f++) {
          colorMatrix[e][f] = Math.exp(-0.5 * (Math.pow(Math.abs(e - f) / colorFactor, colorPower)));
        }
      }

      // Process Image
      var startX = 0;
      var startY = 0;
      var stopX = W;
      var stopY = H;

      var pixelSize = 4; // representing r g b a
      var kernelHalf = kernelSize / 2;

      var imageWidth = W;
      var imageHeight = H;

      var iMin = 0; // bounds of array
      var iMax = imageWidth * imageHeight * pixelSize; // bounds of array

      var tx, ty;
      var imageIX, imageIY;
      var superX, superY;

      var imageI = 0; // set to beginning of image data array

      var rFromImageAtKernel, rFromImageAtI, gFromImageAtKernel, gFromImageAtI, bFromImageAtKernel, bFromImageAtI;
      var sCoefR, sCoefG, sCoefB, sMembR, sMembG, sMembB, coefR, coefG, coefB;

      for (var y = startY; y < stopY; y++) {
        for (var x = startX; x < stopX; x++) {
          sCoefR = 0;
          sCoefG = 0;
          sCoefB = 0;
          sMembR = 0;
          sMembG = 0;
          sMembB = 0;

          rFromImageAtI = srcData.data[imageI];
          gFromImageAtI = srcData.data[imageI + 1];
          bFromImageAtI = srcData.data[imageI + 2];

          // move from lower right to upper left corner of kernel
          ty = kernelSize;
          imageIY = kernelRadius;

          while (ty != 0) {
            ty--;
            imageIY--
            superY = y + imageIY;

            if (superY >= startY && superY < stopY) {
              tx = kernelSize;
              imageIX = kernelRadius;

              while (tx != 0) {
                tx--;
                imageIX--;
                superX = x + imageIX;

                if (superX >= startX && superX < stopX) {
                  var imageSuperI = 4 * ((superY) * imageWidth + (superX));

                  rFromImageAtKernel = srcData.data[imageSuperI + 0];
                  gFromImageAtKernel = srcData.data[imageSuperI + 1];
                  bFromImageAtKernel = srcData.data[imageSuperI + 2];

                  coefR = spatialMatrix[tx][ty] * colorMatrix[rFromImageAtKernel][rFromImageAtI];
                  coefG = spatialMatrix[tx][ty] * colorMatrix[gFromImageAtKernel][gFromImageAtI];
                  coefB = spatialMatrix[tx][ty] * colorMatrix[bFromImageAtKernel][bFromImageAtI];

                  sCoefR += coefR;
                  sCoefG += coefG;
                  sCoefB += coefB;

                  sMembR += coefR * rFromImageAtKernel;
                  sMembG += coefG * gFromImageAtKernel;
                  sMembB += coefB * bFromImageAtKernel;
                }
              }
            }
          }

          dstData.data[imageI] = sMembR / sCoefR;
          dstData.data[imageI + 1] = sMembG / sCoefG;
          dstData.data[imageI + 2] = sMembB / sCoefB;
          dstData.data[imageI + 3] = 255;

          imageI += 4;
        }
      }

      return dstData;
    }

    function image_canny(canvasToUse, srcImage, lowThreshold, highThreshold, blurSigma) {
      canvasToUse = canvasToUse.getContext("2d");
      var rectLeft = 0;
      var rectTop = 0;
      var rectWidth = srcImage.width;
      var rectHeight = srcImage.height;

      // processing start and stop X,Y positions
      var startX = rectLeft + 1;
      var startY = rectTop + 1;
      var stopX = rectWidth - 1;
      var stopY = rectHeight - 1;

      var sourceWidth = W;
      var sourceHeight = H;

      var imgStride = sourceWidth * 4;

      // blackout canvas
      canvasToUse.fillStyle = "#000000";
      canvasToUse.fillRect(0, 0, sourceWidth, sourceHeight);
      var dstImage = canvasToUse.getImageData(0, 0, sourceWidth, sourceHeight);

      var superI = 0;
      var x, y;
      // pixel's value and gradients
      var gx, gy;
      //
      var orientation = 180 / Math.PI;
      var toAngle = 180 / Math.PI;
      var leftPixel = 0;
      var rightPixel = 0;

      // STEP 1 - blur image
      srcImage = gaussian_blur(srcImage, blurSigma);

      // orientation array
      var orients = new Array(sourceWidth * sourceHeight);

      // gradients array
      var gradients = new Array(sourceWidth);
      for (x = 0; x < gradients.length; x++) {
        gradients[x] = new Array(sourceHeight);
      }

      var maxGradient = 0;

      // STEP 2 - calculate magnitude and edge orientation

      superI = imgStride * startY + (startX * 4); // Move to start for calculations
      var p = 0;

      // for each line
      for (y = startY; y < stopY; y++) {
        // for each pixel
        for (x = startX; x < stopX; x++) {
          gx = 1.0 * srcImage.data[superI + 4 - imgStride] - 1.0 * srcImage.data[superI - 4 - imgStride] +
            2.0 * srcImage.data[superI + 4] - 2.0 * srcImage.data[superI - 4] +
            1.0 * srcImage.data[superI + 4 + imgStride] - 1.0 * srcImage.data[superI - 4 + imgStride];

          gy = 1.0 * srcImage.data[superI - 4 - imgStride] - 1.0 * srcImage.data[superI - 4 + imgStride] +
            2.0 * srcImage.data[superI - imgStride] - 2.0 * srcImage.data[superI + imgStride] +
            1.0 * srcImage.data[superI + 4 - imgStride] - 1.0 * srcImage.data[superI + 4 + imgStride];

          // get gradient value
          gradients[x][y] = Math.sqrt(gx * gx + gy * gy);
          if (gradients[x][y] > maxGradient) {
            maxGradient = gradients[x][y];
          }

          // --- get orientation
          if (gx === 0) {
            // can not divide by zero
            orientation = (gy === 0) ? 0 : 90;
          } else {
            var div = gy / gx;

            if (div < 0) {
              // handle angles of the 2nd and 4th quads
              orientation = 180 - Math.atan(div * -1) * toAngle;
            } else {
              // handle angles of the 1st and 3rd quads
              orientation = Math.atan(div) * toAngle;
            }

            // get closest angle from 0, 45, 90, 135 set
            if (orientation < 22.5) {
              orientation = 0;
            } else if (orientation < 67.5) {
              orientation = 45;
            } else if (orientation < 112.5) {
              orientation = 90;
            } else if (orientation < 157.5) {
              orientation = 135;
            } else {
              orientation = 0;
            }
          }

          // save orientation
          orients[p] = orientation;

          superI += 4;
          p++;
        }
      }

      // STEP 3 - suppres non maximums

      superI = imgStride * startY + (startX * 4); // Move to start for calculations
      p = 0;

      // for each line
      for (y = startY; y < stopY; y++) {
        // for each pixel
        for (x = startX; x < stopX; x++) {
          // get two adjacent pixels
          switch (orients[p]) {
            case 0:
              leftPixel = gradients[x - 1][y];
              rightPixel = gradients[x + 1][y];
              break;
            case 45:
              leftPixel = gradients[x - 1][y + 1];
              rightPixel = gradients[x + 1][y - 1];
              break;
            case 90:
              leftPixel = gradients[x][y + 1];
              rightPixel = gradients[x][y - 1];
              break;
            case 135:
              leftPixel = gradients[x + 1][y + 1];
              rightPixel = gradients[x - 1][y - 1];
              break;
          }
          // compare current pixels value with adjacent pixels
          if ((gradients[x][y] < leftPixel) || (gradients[x][y] < rightPixel)) {
            dstImage.data[superI + 0] = 0;
            dstImage.data[superI + 1] = 0;
            dstImage.data[superI + 2] = 0;
          } else {
            dstImage.data[superI + 0] = gradients[x][y] / maxGradient * 255;
            dstImage.data[superI + 1] = gradients[x][y] / maxGradient * 255;
            dstImage.data[superI + 2] = gradients[x][y] / maxGradient * 255;
          }

          superI += 4;
          p++;
        }
      }


      // STEP 4 - hysteresis
      superI = imgStride * startY + (startX * 4); // Move to start for calculations

      /*
      // for each line
      for(var y = startY; y < stopY; y++) {
          // for each pixel
          for(var x = startX; x < stopX; x++) {
              if (dstImage.data[superI] < highThreshold) {
                  if (dstImage.data[superI] < lowThreshold) {
                      // non edge
                      dstImage.data[superI + 0] = 0;
            dstImage.data[superI + 1] = 0;
            dstImage.data[superI + 2] = 0;
                  } else {
                      // check 8 neighboring pixels
                      if((dstImage.data[superI - 4] < highThreshold) && (dstImage.data[superI + 4] < highThreshold) &&
              (dstImage.data[superI - imgStride - 4] < highThreshold) && (dstImage.data[superI - imgStride] < highThreshold) &&
              (dstImage.data[superI - imgStride + 4] < highThreshold) && (dstImage.data[superI + imgStride - 4] < highThreshold) &&
              (dstImage.data[superI + imgStride] < highThreshold) && (dstImage.data[superI + imgStride + 4] < highThreshold)) {
              	
                dstImage.data[superI + 0] = 0;
                dstImage.data[superI + 1] = 0;
                dstImage.data[superI + 2] = 0;
                      }
                  }
              }
          	
        superI+=4; 
          }
      }*/

      return dstImage;
    }

    function image_desaturate(imgData) {
      var i = 0;
      for (var y = 0; y < imgData.height; y++) {
        for (var x = 0; x < imgData.width; x++) {
          var out = 0.5 * imgData.data[i] + 0.419 * imgData.data[i + 1] + 0.081 * imgData.data[i + 2];

          imgData.data[i] = out;
          imgData.data[i + 1] = out;
          imgData.data[i + 2] = out;

          i += 4;
        }
      }

      return imgData;
    }

    function image_sobel(smoothCanvas, srcData) {
      var canvasToUse = smoothCanvas.getContext("2d");
      var dstData = canvasToUse.createImageData(srcData.width, srcData.height);

      var g;
      var gx;
      var gy;
      var x;
      var y;
      var max = 0;
      var i = 0;

      // for each row and column
      for (y = 0; y < dstData.height; y++) {
        for (x = 0; x < dstData.width; x++) {
          gx = 1.0 * get_pixel_from_image_int(srcData, x + 1, y - 1, 0) - 1.0 * get_pixel_from_image_int(srcData, x - 1, y - 1, 0) +
            2.0 * get_pixel_from_image_int(srcData, x + 1, y, 0) - 2.0 * get_pixel_from_image_int(srcData, x - 1, y, 0) +
            1.0 * get_pixel_from_image_int(srcData, x + 1, y + 1, 0) - 1.0 * get_pixel_from_image_int(srcData, x - 1, y + 1, 0);

          gy = 1.0 * get_pixel_from_image_int(srcData, x - 1, y - 1, 0) - 1.0 * get_pixel_from_image_int(srcData, x - 1, y + 1, 0) +
            2.0 * get_pixel_from_image_int(srcData, x, y - 1, 0) - 2.0 * get_pixel_from_image_int(srcData, x, y + 1, 0) +
            1.0 * get_pixel_from_image_int(srcData, x + 1, y - 1, 0) - 1.0 * get_pixel_from_image_int(srcData, x + 1, y + 1, 0);

          g = Math.min(255, Math.abs(gx) + Math.abs(gy));

          if (g > max)
            max = g;

          dstData.data[i] = g;
          dstData.data[i + 1] = g;
          dstData.data[i + 2] = g;
          dstData.data[i + 3] = 255;

          i += 4;
        }
      }

      // scaling
      if (max != 255) {
        // make the second pass for intensity scaling
        var factor = 255 / max;
        i = 0;

        for (y = 0; y < dstData.height; y++) {
          for (x = 0; x < dstData.width; x++) {
            dstData.data[i] = factor * dstData.data[i];
            dstData.data[i + 1] = factor * dstData.data[i + 1];
            dstData.data[i + 2] = factor * dstData.data[i + 2];

            i += 4;
          }
        }
      }

      return dstData;
    }
    // retrieve a particular R, G, or B value in integer form
    function get_pixel_from_image_int(theImage, x, y, channel) {
      if (x < 0 || x >= theImage.width || y < 0 || y >= theImage.height) {
        return 0;
      } else {
        var i = ((y * (theImage.width * 4)) + (x * 4));
        return theImage.data[i + channel];
      }
    }

    function gaussian_blur(imgData, sigma) {
      return gaussian_blur_with_layer(imgData, sigma);
    }

    function gaussian_blur_with_layer(imgData, sigma, layerData) {
      //var sigma = 10; // radius
      var kernel, kernelSize, kernelSum;
      var r, g, b, a;

      // build kernel
      var ss = sigma * sigma;
      var factor = 2 * Math.PI * ss;
      kernel = [];
      kernel.push([]);
      var i = 0,
        j;
      for (i = 0; i < 7; i++) {
        g = Math.exp(-(i * i) / (2 * ss)) / factor;
        if (g < 1e-3)
          break;
        kernel[0].push(g);
      }

      kernelSize = i;

      for (j = 1; j < kernelSize; ++j) {
        kernel.push([]);
        for (i = 0; i < kernelSize; ++i) {
          g = Math.exp(-(i * i + j * j) / (2 * ss)) / factor;
          kernel[j].push(g);
        }
      }
      kernelSum = 0;

      for (j = 1 - kernelSize; j < kernelSize; ++j) {
        for (i = 1 - kernelSize; i < kernelSize; ++i) {
          kernelSum += kernel[Math.abs(j)][Math.abs(i)];
        }
      }

      // do blur on image
      var width = W;
      var height = H;
      var superI;

      for (var y = 0; y < height; ++y) {
        for (var x = 0; x < width; ++x) {
          r = 0;
          g = 0;
          b = 0;
          a = 0;

          for (j = 1 - kernelSize; j < kernelSize; ++j) {
            if (y + j < 0 || y + j >= height)
              continue;

            for (i = 1 - kernelSize; i < kernelSize; ++i) {
              if (x + i < 0 || x + i >= width)
                continue;

              superI = 4 * ((y + j) * width + (x + i));
              if (typeof layerData !== "undefined" && imgData.data[superI + 3] < 255) {
                r += layerData.data[superI + 0] * kernel[Math.abs(j)][Math.abs(i)];
                g += layerData.data[superI + 1] * kernel[Math.abs(j)][Math.abs(i)];
                b += layerData.data[superI + 2] * kernel[Math.abs(j)][Math.abs(i)];
                a += imgData.data[superI + 3] * kernel[Math.abs(j)][Math.abs(i)];
              } else {
                r += imgData.data[superI + 0] * kernel[Math.abs(j)][Math.abs(i)];
                g += imgData.data[superI + 1] * kernel[Math.abs(j)][Math.abs(i)];
                b += imgData.data[superI + 2] * kernel[Math.abs(j)][Math.abs(i)];
                a += imgData.data[superI + 3] * kernel[Math.abs(j)][Math.abs(i)];
              }
            }
          }

          imgData.data[4 * (y * width + x) + 0] = r / kernelSum;
          imgData.data[4 * (y * width + x) + 1] = g / kernelSum;
          imgData.data[4 * (y * width + x) + 2] = b / kernelSum;
          imgData.data[4 * (y * width + x) + 3] = a / kernelSum;
        }
      }

      return imgData;
    }
    return pypUtils;
  });
}());