(function () {
  'use strict';

  // The store locator service is used to retrieve Home Depot stores
  // using the Behr store locator APIs. Stores can be saved to the sessionStorage.
  // This service also allows the saving and retrieval of a "selected" store's information.

  // Store objects used throughout this service adhere to the following structure:
  /*
  {
    address1: "2397 RICHMOND RD"
    address2: "859-2694774"
    areaCode: "859"
    city: "LEXINGTON"
    country: "US"
    distChannel: "10"
    distributionCenter: "1003"
    divisionCode: "10"
    homeDepotURL: "http://www.homedepot.com/l/Lexington/KY/Lexington/40502/2303"
    httpHeaderUrl: "https://www.behr.com/storelocatorrestwebservice/getstoresbyzipcode/40507/5"
    latitude: "38.015539"
    longName: "HOME DEPOT #2303/LEXINGTON"
    longitude: "-84.458728"
    miles: "2"
    numProducts: "3"
    phone: "269-4774"
    products: {
      element: ["P", "S", "V"]
    },
    repCellPhoneNumber: "5023778049"
    repEmailAddress: "AMBOISSINOT@BEHRPAINT.COM"
    repName: "Amy Boissinot"
    retailerTypeId: "0"
    state: "KY"
    storeName: "HOME DEPOT"
    storeNumber: "2303"
    zip: "40502"
  }
  */

  const app = angular.module('behrCore');

  app.factory('StoreLocatorService', StoreLocatorService);

  function StoreLocatorService($http, $q) {
    const _ = this;

    const parser = new X2JS();

    const BASE_ENDPOINT = '/storelocatorrestwebservice/';

    const DEFAULT_RETURN_COUNT = 5;

    const STORAGE_KEYS = {
      STORES: 'bcs_stores',
      SELECTED_STORE: 'bcs_selected_store'
    };

    const ERRORS = {
      MISSING_ARGS: 'missing arguments',
      INVALID_ARGS: 'invalid arguments'
    };

    // ------------------------
    // Service API
    // ------------------------

    // Properties
    _.stores = JSON.parse(window.sessionStorage.getItem(STORAGE_KEYS.STORES)) || [];
    _.selectedStore = getSelectedStore();

    // Methods
    _.getStores = getStores;
    _.setStores = setStores;
    _.setSelectedStore = setSelectedStore;
    _.deleteStores = deleteStores;
    _.deleteSelectedStore = deleteSelectedStore;

    return _;


    // @function: getStores
    // @params: options[Object]
    /*
      options: {
        zipCode: {String}, (required if no city and no state)
        city: {String}, (required if no postal code)
        state: {String}, (require if no postal code)
        returnCount: {Int} (optional)
      }
    */
    // @return Promise
      // resolves with:
      /*
        {
          numReturned: {String}, // Int representing count
          msg: {String}, // error message if request has errors
          stores: [Array] // returned stores if successful
        }
      */
    function getStores(options) {
      if (!options || typeof options !== 'object') return $q.reject(new Error(ERRORS.MISSING_ARGS));
      if (!options.zipCode && !(options.city && options.state)) return $q.reject(new Error(ERRORS.INVALID_ARGS));

      let returnCount = options.returnCount || null;

      if (options.zipCode) {
        return getStoresByZip(options.zipCode, returnCount);
      }

      return getStoresByCity(options.city, options.state, returnCount);
    }

    // @function: setStores
    // @params: stores[Array]
    // @return: Promise
      // resolves with input array
    function setStores(stores) {
      if (!stores) return $q.reject(new Error(ERRORS.MISSING_ARGS));

      try {
        window.sessionStorage.setItem(STORAGE_KEYS.STORES, JSON.stringify(stores));
      } catch (err) {
        $q.reject(err);
      }

      return $q.resolve(stores);
    }

    // @function: requestStores
    // @params: endpoint[URL string]
    // @return: Promise
      // resolves with:
      /*
        {
          numReturned: {String}, // Int representing count
          msg: {String}, // error message if request has errors
          stores: [Array] // returned stores if successful
        }
      */
    function requestStores(endpoint) {
      if (!endpoint) return $q.reject(ERRORS.MISSING_ARGS);

      return $http.get(endpoint).then(function (response) {
        let json = parser.xml_str2json(response.data);

        let result = {
          numReturned: json.StoresList.numReturned || 0,
          stores: json.StoresList.stores.store || [],
          msg: json.StoresList.msg || null
        };

        _.stores = result.stores;

        return $q.resolve(result);
      });
    }

    // @function: getStoresByZip
    // @params: zipCode[String], returnCount[Int](optional)
    // @return: Promise
      // resolves with:
      /*
        {
          numReturned: {String}, // Int representing count
          msg: {String}, // error message if request has errors
          stores: [Array] // returned stores if successful
        }
      */
    function getStoresByZip(zipCode, returnCount) {
      if (!zipCode) return $q.reject(new Error(ERORRS.MISSING_ARGS));

      let count = returnCount || DEFAULT_RETURN_COUNT;

      let endpoint = BASE_ENDPOINT + 'getstoresbyzipcode/' + encodeURIComponent(zipCode) + '/' + count;

      return requestStores(endpoint);
    }

    // @function: getStoresByCity
    // @params: city[String], state[String], returnCount[Int](optional)
    // @return: Promise
      // resolves with:
      /*
        {
          numReturned: {String}, // Int representing count
          msg: {String}, // error message if request has errors
          stores: [Array] // returned stores if successful
        }
      */
    function getStoresByCity(city, state, returnCount) {
      if (!city || !state) return $q.reject(new Error(ERRORS.MISSING_ARGS));

      let count = returnCount || DEFAULT_RETURN_COUNT;

      let endpoint = BASE_ENDPOINT + 'getstoresbycity/' + encodeURIComponent(city) + '/' + encodeURIComponent(state) + '/' + count;

      return requestStores(endpoint);
    }

    // @function: getSelectedStore
    // @return: store[Object]
    function getSelectedStore() {
      if (_.selectedStore) return _.selectedStore;
      if (window.sessionStorage[STORAGE_KEYS.SELECTED_STORE]) return JSON.parse(window.sessionStorage.getItem(STORAGE_KEYS.SELECTED_STORE));
      if (_.stores.length) return _.stores[0];
      return {};
    }

    // @function: setSelectedStore
    // @return: Promise
      // resolves with: store[Object]
    function setSelectedStore(store) {
      if (!store) return $q.reject(ERRORS.MISSING_ARGS);
      if (typeof store !== 'object') $q.reject(ERRORS.INVALID_ARGS);

      try {
        _.selectedStore = store;
        window.sessionStorage[STORAGE_KEYS.SELECTED_STORE] = JSON.stringify(store);
      } catch (err) {
        $q.reject(err);
      }

      return $q.resolve(store);
    }

    // @function: deleteSelectedStore
    // @return: VOID
    function deleteSelectedStore() {
      _.selectedStore = {};
      window.sessionStorage.removeItem(STORAGE_KEYS.SELECTED_STORE);
    }

    // @function: deleteStores
    // @return: VOID
    function deleteStores() {
      _.stores = [];
      window.sessionStorage.removeItem(STORAGE_KEYS.STORES);
    }
  }
})();
