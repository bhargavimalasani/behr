(function () {
  'use strict';

  const app = angular.module('behrCore');

  app.filter('capitalize', CapitalizeFilter);

  function CapitalizeFilter() {
    const REGEX_ALL = /([^\W_]+[^\s-]*) */g;
    const REGEX_FIRST = /([^\W_]+[^\s-]*)/;

    return (input, all) => {
      if (!input) return '';
      const regex = (all) ? REGEX_ALL : REGEX_FIRST;
      return input.replace(regex, (txt) =>
        txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase());
    };
  }
})();
