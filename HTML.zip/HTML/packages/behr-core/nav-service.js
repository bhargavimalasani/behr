(function () {
  "use strict";
  var app = angular.module('behrCore');
  app.factory('navService', function ($window, $http, $serviceURL, $q, $assets, $interpolate, $sce, $state) {
    var navService = {
      routeIs(routes) {
        if (routes.constructor != Array) routes = [routes];
        let currentRoute = $state.$current.self.name.split('.')[0];
        for (let i in routes) {
          if (routes[i] == currentRoute) return true;
        }
        return false;
      },
      routeMappedTo(routes) {
        if (routes.constructor != Array) routes = [routes];
        let checkRoutes = [];
        for (let i in routes) {
          if (navService.routeList.hasOwnProperty(routes[i])) {
            checkRoutes.push.apply(checkRoutes, navService.routeList[routes[i]]);
          }
        }

        return this.routeIs(checkRoutes);
      },
    };

    navService.routeList = {
      'explore': ['index', 'color', 'ui-lib', 'paletteDetails', 'colorDetails', 'paletteList', 'search'],
      'paint': ['paint', 'roomPicker', 'pypUpload', 'pypUpload2', 'compareColors'],
      'cart': ['cart']
    };

    return navService;
  })
}());
