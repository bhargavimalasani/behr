(function () {
  "use strict";
  var app = angular.module('behrCore');

  app.provider('localeService', function LocaleServiceProvider($windowProvider) {

    var $window = $windowProvider.$get();

    /* Available locales:  us, cl, mx */
    function getLocale(){
      var localeStr = 'us';
	  if($window.location.hostname.indexOf('behr.cl') > -1) {
        localeStr = 'cl';
      } else if ($window.location.hostname.indexOf('behrpaint.com.mx') > -1) {
        localeStr = 'mx';
      } else if ($window.location.hostname.indexOf('behrchina.com') > -1 || $window.location.pathname.indexOf('/m-cn/') > -1) {
        localeStr = 'cn';
      } else if ($window.location.pathname.indexOf('/consumer_ca/') > -1 || $window.location.pathname.indexOf('/fr-ca/') > -1) {
        localeStr = 'ca';
      }
      return localeStr;
    }
	
	function getFullLocale() {
	  var localeStr = 'en_US';
	  if($window.location.hostname.indexOf('behr.cl') > -1) {
        localeStr = 'es_CL';
      } else if ($window.location.hostname.indexOf('behrpaint.com.mx') > -1) {
        localeStr = 'es_MX';
      } else if ($window.location.hostname.indexOf('behrchina.com') > -1 || $window.location.pathname.indexOf('/m-cn/') > -1) {
        localeStr = 'zh_CN';
      } else if ($window.location.hostname.indexOf('fr.behr.com') > -1 || $window.location.pathname.indexOf('/fr-ca/') > -1) {
        localeStr = 'fr_CA';
      } else if($window.location.pathname.indexOf('/consumer_ca/') > -1) {
		localeStr = 'en_CA'
	  } 
      return localeStr;
	}
    function getDomain(){
      if($window.location.hostname.indexOf('local') > -1) {
        return 'www.behr.com';
      }
      return $window.location.hostname;
    }
    this.getLocale = getLocale;
    this.getDomain = getDomain;
	this.getFullLocale = getFullLocale;

    this.$get = function localeServiceFactory() {
      return {
        getDomain: getDomain,
        getLocale: getLocale,
		getFullLocale: getFullLocale
      };
    }

  });
}());
