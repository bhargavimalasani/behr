(function() {
  "use strict";
  var app = angular.module('behrCore');
  // Create an AngularJS service called debounce
  app.factory('$stateHistory', function($window, $state) {
    var history = [];
    var ignoreNextTransition = true;
    return {
      push(state, params) {
        if (ignoreNextTransition) {
          ignoreNextTransition = false;
          return;
        }
        history.push({ state: state, params: params });
      },
      hasHistory(pattern) {
        if (typeof pattern === "undefined") return history.length > 0;
        return this.getHistory(pattern) !== null;
      },
      getHistory(pattern) {
        for (var i = history.length-1; i >=0; i--) {
          if (history[i].state.search(pattern) > -1) return history[i];
        }
        return null;
      },
      goBack() {
        if (history.length >= 1) {
          var last = history.pop();
          $state.go(last.state, last.params);
        }
        else {
          $window.history.go(-1);
        }
      }
    };
  });
} ());
