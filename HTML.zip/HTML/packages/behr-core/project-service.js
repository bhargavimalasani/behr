(function() {
  "use strict";
  var app = angular.module('behrCore');
  app.factory('projectService', function(
    $window,
    $q,
    $state,
    paletteService,
    pypCanvasDB,
    colorService,
    visualizerService,
    $uibModal,
    $http,
    $serviceURL,
    loginService,
    behrTranslate
  ) {
    var cookies = $window.Cookies.withConverter({
      read: function(value, name) {
        return value;
      },
      write: function(value, name) {
        return value;
      }
    });

    function initializeProjects(projects) {
      projectService.projects = projects.map(function (project) {
        project.jsonData = JSON.parse(project.jsonData);
        return project;
      });
    }

    function loadProjectPalette(project) {
      var palette = project.jsonData.NextGenProjectVO.palette;

      paletteService.reset();

      for (var i = 0; i < palette.length - 1; i++) {
        if (palette[i] !== null) paletteService.palette.add(colorService.getColor(palette[i]));
      }

      paletteService.palette.selected = project.jsonData.NextGenProjectVO.paletteIndex;
    }

    function loadPypProject(project) {
      var modalInstance = $uibModal.open({
        controller: 'DefaultModalCtrl',
        controllerAs: '$ctrl',
        templateUrl: '/app/components/modals/pyp-images-loading-modal.html',
        backdropClass: 'backdrop-white',
        backdrop: 'static',
        appendTo: angular.element(document.getElementById("cs-mobile-app"))
      });

      // Use project data to set up paletteService and visualizerService
      loadProjectPalette(project);

      pypCanvasDB.loadProjectData(project)
        .then(function () {
          modalInstance.close();
          visualizerService.pypMode = true;
          $state.go('paint');
        }).catch(function (error) {
          modalInstance.close();
          modalInstance = $uibModal.open({
            controller: 'DataModalCtrl',
            controllerAs: '$ctrl',
            templateUrl: '/app/components/modals/error-modal.html',
            backdropClass: 'backdrop-white',
            appendTo: angular.element(document.getElementById("cs-mobile-app")),
            resolve: {
              data: function () {
                return {
                  error: behrTranslate("Sorry, there was a problem loading this project.")
                };
              }
            }
          });
        });
    }

    function loadVizProject(project) {
      // Use project data to set up paletteService and visualizerService
      loadProjectPalette(project);
      visualizerService.pypMode = false;

      var roomObj = visualizerService.roomLookup(project.jsonData.NextGenProjectVO.currentRoomId);
      var savedRoom = visualizerService.rooms[roomObj.roomKey].visualizerRooms[roomObj.index];

      visualizerService.currentScene = visualizerService.createScene(savedRoom);

      if (project.jsonData.NextGenProjectVO.rooms.length > 0) {
        visualizerService.currentScene.bindings = project.jsonData.NextGenProjectVO.rooms[0].bindings;
      }

      $state.go('paint');
    }

    var projectService = {
      projects: [],
      loadProject: function (project) {
        projectService.currentProjectId = project.projectId;
        projectService.currentProjectName = project.name;

        if (project.projectAppType && project.projectAppType.toLowerCase() === 'pyp') {
          loadPypProject(project);
        } else {
          loadVizProject(project);
        }
      },
      resetProject: function () {
        paletteService.reset();
        projectService.currentProjectId = null;
        projectService.currentProjectName = null;
      },
      loadProjectById: function (id) {
        return projectService.getProject(id).then(function (data) {
          data.jsonData = JSON.parse(data.jsonData); //must initialize
          projectService.loadProject(data);
        });
      },
      getProjectShareUrl: function (projectId) {
        return projectService.getProject(projectId)
          .then(function (data) {
            const projectData = JSON.parse(data.jsonData).NextGenProjectVO;

            function surfaceValue(index) {
              if (projectData.projectAppType.toLowerCase() == 'pyp') return '';

              if (projectData.rooms && projectData.rooms.length) {
                if (index < projectData.rooms[0].bindings.length && projectData.rooms[0].bindings[index] > -1) {
                  return index + 1;
                }
              }

              return '';
            }

            function colorValue(index) {
              if (projectData.projectAppType.toLowerCase() == 'pyp') return '';

              if (projectData.rooms && projectData.rooms.length) {
                if (index < projectData.rooms[0].bindings.length && projectData.rooms[0].bindings[index] > -1) {
                  return projectData.palette[projectData.rooms[0].bindings[index]];
                }
              }

              return '';
            }

            function getColorVO() {
              return projectData.palette.reduce(function (colorVO, current, index) {
                if (current) colorVO['colorCode' + (index+1)] = current;
                else colorVO['colorCode' + (index+1)] = 'null';
                return colorVO;
              }, {});
            }

            const restURI = 'render?roomId=' + projectData.currentRoomId + '&surfaceId1=' +
              surfaceValue(0) + '&color1=' + colorValue(0) + '&surfaceId2=' +
              surfaceValue(1) + '&color2=' + colorValue(1) + '&surfaceId3=' +
              surfaceValue(2) + '&color3=' + colorValue(2) + '&surfaceId4=' +
              surfaceValue(3) + '&color4=' + colorValue(3) + '&surfaceId5=' +
              surfaceValue(4) + '&color5=' + colorValue(4) + '&surfaceId6=' +
              surfaceValue(5) + '&color6=' + colorValue(5) + '&surfaceId7=' +
              surfaceValue(6) + '&color7=' + colorValue(6) + '&surfaceId8=' +
              surfaceValue(7) + '&color8=' + colorValue(7) + '&surfaceId9=' +
              surfaceValue(8) + '&color9=' + colorValue(8) + '&surfaceId10=' +
              surfaceValue(9) + '&color10=' + colorValue(9);

            let requestData = {
              webVisualizerShare: {
                to: 'schung@behr.com',
                subject: 'NextGen Visualizer Project Share',
                optIn: 'N',
                html: {
                  parameters: {
                    duplprojid: ''+ projectId,
                    paletteQuad: ''+projectData.paletteQuad,
                    projectType: projectData.projectAppType,
                    projectname: projectData.projectName
                  }
                },
                image1: {
                  restURI: restURI
                },
                objects: {
                  ColorVO: getColorVO(),
                  StoreVO: {
                    storyNumber: "WEB"
                  }
                }
              }
            };

            return $http.post($serviceURL + '/emailnx/save', requestData)
              .then(function (response) {
                return response.data;
              });
          });
      },
      getProject: function (projectId) {
        return $http({
          method: 'GET',
          url: $serviceURL + '/project/nextgen/getproject?projectid=' + projectId
        }).then(function successCallback(response) {
            return response.data.NextGenProjectVO;
          }, function errorCallback(response) {
            // called asynchronously if an error occurs
            // or server returns response with an error status.
            var deferred = $q.defer();
            deferred.reject(behrTranslate("There was a problem retrieving your projects"));
            return deferred.promise;
          });
      },
      getProjects: function (userId) {
        return $http({
          method: 'GET',
          url: $serviceURL + "/project/nextgen/getallprojects?userid=" + userId
        }).then(function successCallback(response) {
            var projects = response.data.list["com.behr.colorsmart4.project.service.NextGenProjectVO"];

            if (!Array.isArray(projects)) {
              projects = [projects];
            }

            initializeProjects(projects);
          }, function errorCallback(response) {
            // called asynchronously if an error occurs
            // or server returns response with an error status.
            var deferred = $q.defer();
            deferred.reject("There was a problem retrieving your projects");
            return deferred.promise;
          });
      },
      currentProjectId: null, // store ID when project is loaded
      currentProjectName: null,
      saveProject: function (projectName, anonymous) {
        let deferred = $q.defer();
        if (!projectName) deferred.reject(new Error('unnamed project'));

        function createProjectData() {
          var jsonData = {
            "NextGenProjectVO": {
              "userId": "" + loginService.getUser().userId,
              "projectId": projectService.currentProjectId,
              "projectName": projectName,
              "projectType": "interior",
              "projectAppType": (visualizerService.pypMode) ? "pyp" : "vis",
              "palette": paletteService.palette.getLegacyColors(),
              "paletteIndex": Math.max(0,paletteService.palette.selected),
              "paletteQuad": paletteService.palette.coordinated,
              "currentRoomId": visualizerService.currentScene ? "" + visualizerService.currentScene.id : "",
              "rooms": visualizerService.currentScene ? [{
                id: visualizerService.currentScene.id,
                bindings: visualizerService.currentScene.bindings
              }] : []
            }
          };

          if (visualizerService.pypMode) {
            jsonData.NextGenProjectVO.mainImage = pypCanvasDB.predrawing.toDataURL();
            jsonData.NextGenProjectVO.drawingCanvas = pypCanvasDB.drawing.toDataURL();
            jsonData.NextGenProjectVO.colorCanvas = pypCanvasDB.bucketColor.toDataURL();
            jsonData.NextGenProjectVO.segmentCanvas = pypCanvasDB.segment.toDataURL();
            jsonData.NextGenProjectVO.thumbnail = pypCanvasDB.getLegacyThumbnail().toDataURL();
            jsonData.NextGenProjectVO.foundColors = JSON.stringify(pypCanvasDB.foundColors);
            jsonData.NextGenProjectVO.foundLumins = JSON.stringify(pypCanvasDB.foundLumins);
            jsonData.NextGenProjectVO.maskingLines = JSON.stringify(pypCanvasDB.maskingLines);
            jsonData.NextGenProjectVO.rooms = [];
          }

          return jsonData;
        }

        function _save() {
          // update url http://www.behr.com/project/nextgen/updateproject
          // new url http://www.behr.com/project/nextgen/saveproject
          // social share url http://www.behr.com/project/nextgen/anonymousproject
          var requestData;
          var requestURL;
          var requestMethod;

          if (anonymous) {
            requestURL = $serviceURL + "/project/nextgen/anonymousproject";
            requestMethod = 'post';
            requestData = createProjectData();
            requestData.userId = loginService.getUser().userId || null;
          } else if (projectService.currentProjectId) {
            requestURL = $serviceURL + "/project/nextgen/updateproject";
            requestMethod = 'put';
            requestData = {
              "NextGenProjectVO": {
                "created": "",
                "jsonData": createProjectData(),
                "modified": "",
                "projectId": projectService.currentProjectId,
                "userId": "" + loginService.getUser().userId
              }
            };
          } else {
            requestURL = $serviceURL + "/project/nextgen/saveproject";
            requestMethod = 'post';
            requestData = createProjectData();
          }

          return $http[requestMethod](requestURL, requestData, {
            headers: {
              'Content-Type': 'text/plain'
            }
          }).then(function (response) {
            deferred.resolve(response);
          }).catch(function (error) {
            deferred.reject(error);
          });
        }

        if (loginService.loggedIn || anonymous) {
          _save();
        } else {
          let modalInstance = $uibModal.open({
            controller: 'DataModalCtrl',
            controllerAs: '$ctrl',
            templateUrl: '/app/components/modals/login-modal.html',
            backdropClass: 'backdrop-white',
            backdrop: true,
            appendTo: angular.element('#cs-mobile-app'),
            resolve: {
              data: {
                action: 'saveProject'
              }
            }
          });

          modalInstance.result.then(function (result) {
            _save();
          }).catch(function (err) {
            deferred.reject(err);
          });
        }
        return deferred.promise;
      },
      sendToShoppingCart: function (colorArrayInput, productType) {
        let colorArray = colorArrayInput || [];
        colorService.saveBrowserState();

        $state.go('cart', {
          colors: colorArray,
          productType: productType
        });
      }
    };

    return projectService;
  });
})();
