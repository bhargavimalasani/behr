(function() {
  "use strict";
  var app = angular.module('behrCore');
  app.controller('CoordinatedPaletteBase', CoordinatedPaletteBase);
  function CoordinatedPaletteBase(behrTranslate) {
    var $ctrl = this;
    var palettesPerIteration = 8; // number of palettes that gets spit out per color.
    var palettesPerGroupPerIteration = 2; // number of palettes per group that is spit out per iteration
    function numberInRange(number, range) {
      return number >= range[0] && number < range[1];
    }
    var warmTones = {
      name: behrTranslate('Warm Tones'),
      range: [0, 2]
    }
    var coolTones = {
      name: behrTranslate('Cool Tones'),
      range: [2, 4]
    }
    var complimentary = {
      name: behrTranslate('Complimentary'),
      range: [4, 6]
    }
    var subtleBlends = {
      name: behrTranslate('Subtle Blends'),
      range: [6, 8]
    }
    $ctrl.groupDefinitions = {
      warmTones: warmTones,
      coolTones: coolTones,
      complimentary: complimentary,
      subtleBlends: subtleBlends
    };
    $ctrl.getColorsForDefinition = function(colors, groupDefinition) {
      var ret = [];
      ret = ret.concat(colors.slice(groupDefinition.range[0], groupDefinition.range[1]))
      if (colors.length > groupDefinition.range[0] + palettesPerIteration) ret = ret.concat(colors.slice(groupDefinition.range[0] + palettesPerIteration, groupDefinition.range[1] + palettesPerIteration))
      return ret;
    }
    $ctrl.getGroupIndex = function(paletteIndex) {
      var modulatedGroupIndex = (paletteIndex % palettesPerIteration) % palettesPerGroupPerIteration;
      var groupIncrement = Math.floor(paletteIndex / palettesPerIteration) * palettesPerGroupPerIteration;
      return modulatedGroupIndex + groupIncrement;
    }
    $ctrl.getPaletteIndexFromGroupIndex = function(groupIndex, groupDefinition) {
      var addIteration = Math.floor(groupIndex / palettesPerGroupPerIteration);
      return ((groupIndex % palettesPerGroupPerIteration) + groupDefinition.range[0]) + (addIteration * palettesPerIteration);
    }
    $ctrl.getGroupDefinition = function(paletteIndex) {
      var modulatedIndex = (paletteIndex % palettesPerIteration);
      if (numberInRange(modulatedIndex, warmTones.range)) return warmTones;
      if (numberInRange(modulatedIndex, coolTones.range)) return coolTones;
      if (numberInRange(modulatedIndex, complimentary.range)) return complimentary;
      if (numberInRange(modulatedIndex, subtleBlends.range)) return subtleBlends;
      throw new Error('Index out of range somehow');
    }
    function getGroupLength(totalPaletteLength, groupDefinition) {
      if (totalPaletteLength <= groupDefinition.range[0]) return 0;
      if (totalPaletteLength <= groupDefinition.range[1] - 1) return 1;
      if (totalPaletteLength <= groupDefinition.range[0] + palettesPerIteration) return 2;
      if (totalPaletteLength <= groupDefinition.range[1] + palettesPerIteration - 1) return 3;
      return 4;
    }
    $ctrl.getPaletteIndexFromChangingGroupIndex = function(totalPaletteLength, paletteIndex, amount) {
      var groupIndex = $ctrl.getGroupIndex(paletteIndex);
      var groupDefinition = $ctrl.getGroupDefinition(paletteIndex);
      var groupLength = getGroupLength(totalPaletteLength, groupDefinition);
      var newGroupIndex = groupIndex + amount;
      if (newGroupIndex < 0) newGroupIndex = groupLength - 1;
      if (newGroupIndex >= groupLength) newGroupIndex = 0;
      return $ctrl.getPaletteIndexFromGroupIndex(newGroupIndex, groupDefinition);
    }
  }
} ());
