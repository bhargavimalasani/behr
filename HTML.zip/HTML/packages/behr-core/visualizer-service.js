(function () {
  "use strict";

  var app = angular.module('behrCore');

  app.factory('visualizerService', function (
    $rootScope,
    $window,
    pypCanvasDB
  ) {
    var visualizerService = {
      rooms: $window._rooms,
      createScene(room) {
        return new Scene(room);
      },
      getSceneLocation(scene) {
        return visualizerService._sceneLookup[scene.id];
      },
      roomLookup(roomId) {
        return visualizerService._sceneLookup[roomId];
      }
    };

    Object.defineProperty(visualizerService, 'pypMode', {
      get: () => {
        return ($window.sessionStorage.pypMode == 'true');
      },
      set: (val) => {
        $window.sessionStorage.pypMode = val;
      }
    });

    if (visualizerService.pypMode) {
      try {
        pypCanvasDB.loadSessionState();
      } catch(e) {
        console.log(e);
        visualizerService.pypMode = false;
      }
    }

    visualizerService._sceneLookup = createReverseSceneDictionary(visualizerService.rooms);
    // visualizerService.currentScene = visualizerService.createScene(visualizerService.rooms.Bedroom.visualizerRooms[0]);
    visualizerService.currentScene = null;

    return visualizerService;
  });

  function createReverseSceneDictionary(rooms) {
    var reverseDictionary = {};

    Object.keys(rooms).forEach((roomKey) => {
      rooms[roomKey].visualizerRooms.forEach((room, index) => {
        reverseDictionary[room.roomId] = {
          roomKey: roomKey,
          index: index
        };
      });
    });

    return reverseDictionary;
  }

  function Scene(room) {
    this.id = room.roomId;
    this.category = null;
    this.isExterior = false;
    this.thumb = room.thumbNail;
    this.overlay = room.shadowMap;
    this.base = room.baseImg;

    this.compareBase = room.compareBase;
    this.compareShadow = room.compareShadow;
    this.comparePaintable = room.comparePaintable;
    this.shadowX = room.shadowX;
    this.shadowY = room.shadowY;

    this.bindings = [];
    this.surfaces = room.visualizerSurfaces;

    room.visualizerSurfaces.forEach((surface, i) => {
      this.bindings[i] = -1;
    });

    this.undoBindingsList = [];
    this.redoBindingsList = [];
    this.roomData = null;
  }

  Scene.prototype.removeColor = function (bindingIndex) {
    this.bindings.forEach((val, i) => {
      if (val == bindingIndex) this.bindings[i] = -1;
    });
  };

  Scene.prototype.hasUndo = function () {
    return this.undoBindingsList.length > 0;
  };

  Scene.prototype.undo = function () {
    if (!this.hasUndo()) return;

    this.redoBindingsList.push(angular.copy(this.bindings));

    this.bindings = this.undoBindingsList.pop();
  };

  Scene.prototype.hasRedo = function () {
    return this.redoBindingsList.length > 0;
  };

  Scene.prototype.redo = function () {
    if (!this.hasRedo()) return;

    this.undoBindingsList.push(angular.copy(this.bindings));

    this.bindings = this.redoBindingsList.pop();
  };

  Scene.prototype.hasPaintedSurface = function () {
    for (let i=0; i<this.bindings.length; i++) {
      if (this.bindings[i] > -1) {
        return true;
      }
    }

    return false;
  };

  Scene.prototype.unpaint = function () {
    if (this.hasPaintedSurface()) {
      this.undoBindingsList.push(angular.copy(this.bindings));
    }

    for (let i=0; i<this.bindings.length; i++) {
      this.bindings[i] = -1;
    }
  };
})();
