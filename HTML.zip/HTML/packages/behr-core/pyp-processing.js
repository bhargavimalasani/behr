(function() {
  "use strict";
  var app = angular.module('behrCore');

  app.factory('pypProcessing', function($q, $interval, $timeout, pypCanvasDB, paletteService, colorService, pypUtils) {
    var ALPHA = 255; // @todo what does this do?
    var pypProcessing = {
      doBilateralSmoothing: true,
      readImage(event) {
        var deferred = $q.defer();

        var fileToUploadName = event.target.files[0].name;
        var reader = new FileReader();

        reader.onload = function(onloadEvent) {
          var uploadedFileUrl = onloadEvent.target.result.split('/');
          var uploadedFileType = uploadedFileUrl[0].split(':')[1];

          if (uploadedFileType != 'image') {
            deferred.reject('upload_error_file-type');
            return;
          } else {
            var photo = new Image()
            photo.src = onloadEvent.target.result;

            photo.onload = function() {
              var uploadedPhotoWidth = photo.width;
              var uploadedPhotoHeight = photo.height;

              if (uploadedPhotoWidth < 200 || uploadedPhotoHeight < 200) {
                deferred.reject('upload_error_file-dimensions');
                return;
              } else {
                deferred.resolve(photo);
              }
            }
          }
        }

        reader.onprogress = function(e) {
          if (e.lengthComputable) {
            var percentLoaded = Math.round((e.loaded / e.total) * 100);
            deferred.notify(percentLoaded);
          }
        }

        reader.readAsDataURL(event.target.files[0]);
        return deferred.promise;
      },
      doImageProcessing(imageObj, actualPhotoPositionOffsetX, actualPhotoPositionOffsetY, actualPhotoPositionOffsetXEnd, actualPhotoPositionOffsetYEnd) {
        var deferred = $q.defer();
        pypCanvasDB.clearAllCanvases();
        pypUtils.resetMasking(pypCanvasDB);
        pypUtils.resetMaskingTool();
        // reset overlay
        var processingPercent = 0;
        deferred.notify(processingPercent);

        var imageProcessingTimeout = $timeout(() => {
          // im not sure we need to support iOS 6 devices
          /*
          if ((navigator.userAgent.match(/iPhone/i)) || (navigator.userAgent.match(/iPad/i)) || (navigator.userAgent.match(/iPod/i))) {
            drawImageIOSFix(preDrawingContext, imageObj, actualPhotoPositionOffsetX, actualPhotoPositionOffsetY, actualPhotoPositionOffsetXEnd, actualPhotoPositionOffsetYEnd, 0, 0, drawing.width, drawing.height);
          } else {
            preDrawingContext.drawImage(imageObj, actualPhotoPositionOffsetX, actualPhotoPositionOffsetY, actualPhotoPositionOffsetXEnd, actualPhotoPositionOffsetYEnd, 0, 0, drawing.width, drawing.height);
          }
          */
          // @todo the canvas sizes need to be adapted based on the device? or something
          pypCanvasDB.predrawingContext.drawImage(imageObj, actualPhotoPositionOffsetX, actualPhotoPositionOffsetY, actualPhotoPositionOffsetXEnd, actualPhotoPositionOffsetYEnd, 0, 0, pypUtils.W, pypUtils.H);

          pypUtils.createEdgeAndCanny(pypCanvasDB, pypProcessing.doBilateralSmoothing);

          // build lumin map
          pypCanvasDB.lumin.build(pypUtils.W, pypUtils.H);

          processingPercent = 5;
          deferred.notify(processingPercent);

          // Reset storage for colors and luminosity
          pypCanvasDB.foundColors = [];
          pypCanvasDB.foundLumins = [];
          pypCanvasDB.computedLumins = 0;
          // create the segment canvas
          pypProcessing.paintEntireImage(pypUtils.W, pypUtils.H)
            .then(() => {
                pypCanvasDB.saveSessionState();
                pypCanvasDB.saveImageToStorage();
                deferred.resolve();
              },
              undefined,
              (progress) => {
                var processingPixels = Math.floor(5 + (95 * progress / 100)); //@todo this is probably inaccurate
                deferred.notify(processingPixels);
              });

        }, 1);

        return deferred.promise;
      },
      paintEntireImage(width, height) {
        var deferred = $q.defer();
        var processingPercent = 0;

        var imageProcessingTimeout = $timeout(function() {
          var canMaskData = pypCanvasDB.bucketEdgeContext.getImageData(0, 0, width, height).data;
          var paintEntireImageData = pypCanvasDB.segmentContext.getImageData(0, 0, width, height).data;
          var imageDataObject = {};
          imageDataObject.cannyData = pypCanvasDB.canny.getContext("2d").getImageData(0, 0, pypUtils.W, pypUtils.H).data;
          imageDataObject.paintedData = pypCanvasDB.bucketColorContext.getImageData(0, 0, pypUtils.W, pypUtils.H).data
          imageDataObject.maskLineData = pypCanvasDB.maskingTopContext.getImageData(0, 0, pypUtils.W, pypUtils.H).data;

          var tolerance = 27;
          var cursorX = 0;
          var cursorY = 0;
          var offset = 0;
          var W4 = width * 4;
          // roughly speaking, we will create the segment canvas by sampling at points on a grid
          // with the magic wand tool, and finding the average color across that surface
          var paintEntireImageInterval = $interval(function() {
            if (cursorX >= width) {
              try {
                // Painting is done
                processingPercent = 100;
                deferred.notify(processingPercent);

                $interval.cancel(paintEntireImageInterval);

                var segmentData = pypCanvasDB.segmentContext.getImageData(0, 0, width, height);
                segmentData.data.set(paintEntireImageData);
                segmentData = pypUtils.dilatation(pypCanvasDB.drawingContext, segmentData);
                pypCanvasDB.lumin.buildSuper(segmentData, width, height);
                pypCanvasDB.segmentContext.putImageData(segmentData, 0, 0);
                deferred.resolve();
              } catch (err) {
                //alert(err.message);
                console.log(err);
              }
            } else {
              if (cursorY >= height) {
                // Continue to go horizontally
                processingPercent = Math.floor(cursorX / width * 100);
                if (cursorX % 2 === 0) {
                  deferred.notify(processingPercent);
                }
                // @todo this doesn't work, reverting
                // cursorX += Math.floor(height / 35);
                cursorX += 20;
                cursorY = 0;
              } else {
                // Continue to go vertically
                offset = ((cursorY * (width * 4)) + (cursorX * 4));

                if (canMaskData[offset] < tolerance && paintEntireImageData[offset] === 0) {
                  tool_magic_wand_custom(paintEntireImageData, pypCanvasDB.drawingContext, width, height, cursorX, cursorY, 3, pypCanvasDB.bucketEdgeContext, false, tolerance, imageDataObject);
                }
                // @todo this doesn't work, reverting
                // cursorY += Math.floor(width / 42);
                cursorY += 12;
              }
            }
          }, 1);
        }, 1);
        return deferred.promise;
      }
    };

    function tool_magic_wand_custom(paintEntireImageData, context, W, H, x, y, sensitivity, maskContext, isBrushRepaint, tol, imageDataObject) {
      var imgData = context.getImageData(0, 0, W, H).data; //@todo-getImageData
      var topRow;
      var rowLength;
      var cx;
      var tempBoundingRectangleY;
      var tempBoundingRectangleX;

      var selectionDataBoundingRectMinX = pypUtils.W+1;
      var selectionDataBoundingRectMaxX = 0;
      var selectionDataBoundingRectMinY = pypUtils.H+1;
      var selectionDataBoundingRectMaxY = 0;
      var cannyData = imageDataObject.cannyData;
      var paintedData = imageDataObject.paintedData;
      var maskLineData = imageDataObject.maskLineData;

      pypCanvasDB.selectionData[tol] = context.createImageData(W, H);

      var maskData = maskContext.getImageData(0, 0, W, H).data;
      var tolerance;
      var i;
      var W4 = W * 4;

      var k = ((y * (W * 4)) + (x * 4));
      var dx = [0, -1, +1, 0];
      var dy = [-1, 0, 0, +1];
      var color_to = pypUtils.hexToRgba((paletteService.palette.selectedColor || colorService.nullColor).rgb);
      var color_from = {
        r: maskData[k + 0],
        g: maskData[k + 1],
        b: maskData[k + 2],
        a: maskData[k + 3],
      }


      var isPainted = false;
      var paintedRGB = Array();
      if (paintedData[k + 3] > 0) {
        isPainted = true;
        paintedRGB[0] = paintedData[k + 0]
        paintedRGB[1] = paintedData[k + 1]
        paintedRGB[2] = paintedData[k + 2]
      }

      var drawimgData = pypCanvasDB.drawingContext.getImageData(0, 0, W, H).data; //@todo-getImageData

      var orginalLAB = ColorUtilities.convertRGBToLAB(drawimgData[k + 0], drawimgData[k + 1], drawimgData[k + 2]);

      if (color_from.r == color_to.r &&
        color_from.g == color_to.g &&
        color_from.b == color_to.b &&
        color_from.a == color_to.a)
        return false;
      //if (ALPHA < 255 && color_from.a == ALPHA) return false;

      var marked = [];
      var newImage = context.getImageData(0, 0, W, H).data;
      var iLumins = 0;
      var iCount = 0;


      var colorCombo = color_from.r + color_from.b + color_from.g;
      colorCombo = colorCombo / 3;


      var stack = [];
      stack.push(x);
      stack.push(y);


      var usedStack = [];
      var usedImage = context.getImageData(0, 0, W, H).data;

      var totalR = 0;
      var totalG = 0;
      var totalB = 0;

      while (stack.length > 0) {
        var curPointY = stack.pop();
        var curPointX = stack.pop();


        for (i = 0; i < 4; i++) {
          var nextPointX = curPointX + dx[i];
          var nextPointY = curPointY + dy[i];
          if (nextPointX < 0 || nextPointY < 0 || nextPointX >= W || nextPointY >= H)
            continue;
          k = (nextPointY * W + nextPointX) * 4;


          if (usedImage[k] != 1) {
            usedImage[k] = 1;
            //check
            if (newImage[k] == 255) {
              stack.push(nextPointX);
              stack.push(nextPointY);

              continue;
            }


            var currentLAB = ColorUtilities.convertRGBToLAB(imgData[k + 0], imgData[k + 1], imgData[k + 2]);
            //debugger;



            if (isPainted === false && paintedData[k] !== 0) continue;


            if ((((isPainted === false && Math.abs(maskData[k + 0] - colorCombo) < tol) || (isPainted === true && paintedRGB[0] == paintedData[k])) && maskLineData[k + 0] === 0)) {
              //fill pixel
              tolerance = Math.abs(maskData[k + 0] - colorCombo);
              if (ALPHA == 255) {

                if (tol < 30) {
                  iLumins += pypCanvasDB.lumin.map.data[k];
                  totalR += imgData[k];
                  totalG += imgData[k + 1];
                  totalB += imgData[k + 2];
                  //debugger;
                  iCount++;
                }

                pypCanvasDB.selectionData[tol].data[k + 0] = 255; //r
                pypCanvasDB.selectionData[tol].data[k + 3] = 255; //r
                newImage[k] = 255;

                tempBoundingRectangleY = Math.floor(k / (W * 4));
                tempBoundingRectangleX = (k - (tempBoundingRectangleY * (W * 4))) / 4;

                if (tempBoundingRectangleY < selectionDataBoundingRectMinY) {
                  selectionDataBoundingRectMinY = tempBoundingRectangleY;
                } else if (tempBoundingRectangleY > selectionDataBoundingRectMaxY) {
                  selectionDataBoundingRectMaxY = tempBoundingRectangleY;
                }
                if (tempBoundingRectangleX < selectionDataBoundingRectMinX) {
                  selectionDataBoundingRectMinX = tempBoundingRectangleX;
                } else if (tempBoundingRectangleX > selectionDataBoundingRectMaxX) {
                  selectionDataBoundingRectMaxX = tempBoundingRectangleX;
                }

              } else
                imgData[k + 3] = ALPHA; //a



              stack.push(nextPointX);
              stack.push(nextPointY);
            } else {
              var nearby = pypUtils.isNearbyPixel(paintedData, color_to.r, color_to.g, color_to.b, 6, nextPointX, nextPointY, cannyData);
              if (isPainted === false && (Math.abs(maskData[k + 0] - color_from.r) < (tol + 155) || nearby > 0)) {
                //debugger;

                tolerance = Math.abs(maskData[k + 0] - color_from.r);
                if (ALPHA == 255) {

                  if (tol < 30) {
                    iLumins += pypCanvasDB.lumin.map.data[k];
                    //debugger;
                    iCount++;
                  }

                  pypCanvasDB.selectionData[tol].data[k + 0] = 255; //r
                  pypCanvasDB.selectionData[tol].data[k + 3] = 255; //r
                  if (nearby == 2) {
                    newImage[k] = 255;
                  }

                  tempBoundingRectangleY = Math.floor(k / (W * 4));
                  tempBoundingRectangleX = (k - (tempBoundingRectangleY * (W * 4))) / 4;

                  if (tempBoundingRectangleY < selectionDataBoundingRectMinY) {
                    selectionDataBoundingRectMinY = tempBoundingRectangleY;
                  } else if (tempBoundingRectangleY > selectionDataBoundingRectMaxY) {
                    selectionDataBoundingRectMaxY = tempBoundingRectangleY;
                  }
                  if (tempBoundingRectangleX < selectionDataBoundingRectMinX) {
                    selectionDataBoundingRectMinX = tempBoundingRectangleX;
                  } else if (tempBoundingRectangleX > selectionDataBoundingRectMaxX) {
                    selectionDataBoundingRectMaxX = tempBoundingRectangleX;
                  }
                } else
                  imgData[k + 3] = ALPHA; //a
              }
            }
          }
        }
      }

      pypCanvasDB.computedLumins = iLumins / iCount;
      totalR = totalR / iCount;
      totalG = totalG / iCount;
      totalB = totalB / iCount;
      color_to = {
        r: Math.floor(totalR),
        g: Math.floor(totalG),
        b: Math.floor(totalB),
        a: 255
      }

      var comboRgb = ColorUtilities.combineRGB(color_to.r, color_to.g, color_to.b);

      var lowestDeltaFC = 0;
      var lowestDelta = -1;
      var lowestLuminosity = 0;
      var lowestDeltaFCLumin = 0;

      var toLab = ColorUtilities.convertRGBToLAB(color_to.r, color_to.g, color_to.b);
      if (pypCanvasDB.foundColors.length === 0) {
        lowestLuminosity = toLab[0];
      }

      var colorCount = [];
      pypCanvasDB.colorWeights = [];

      var colorWeight = (iCount / 800);
      if (colorWeight > 15) colorWeight = 15;


      for (var fc = 0; fc < pypCanvasDB.foundColors.length; fc++) {
        var foundLab = ColorUtilities.convertRGBToLAB(pypCanvasDB.foundColors[fc].r, pypCanvasDB.foundColors[fc].g, pypCanvasDB.foundColors[fc].b);
        var comboFoundRgb = ColorUtilities.combineRGB(pypCanvasDB.foundColors[fc].r, pypCanvasDB.foundColors[fc].g, pypCanvasDB.foundColors[fc].b);
        var deltaE = ColorUtilities.colorCompareDE1994(foundLab[0], foundLab[1], foundLab[2], toLab[0], toLab[1], toLab[2]);
        if (lowestDelta == -1) {
          lowestDeltaFC = fc;
          lowestDelta = deltaE - pypCanvasDB.colorWeights[comboFoundRgb];
          lowestLuminosity = toLab[0];
          lowestDeltaFCLumin = foundLab[0];
        } else if (deltaE < lowestDelta) {
          lowestDelta = deltaE;
          lowestDeltaFC = fc;
          lowestLuminosity = toLab[0];
          lowestDeltaFCLumin = foundLab[0];
        }
      }

      if (lowestDelta < 5 && lowestDelta != -1) {
        color_to = pypCanvasDB.foundColors[lowestDeltaFC];
        if (lowestDeltaFCLumin !== 0) {
          pypCanvasDB.foundColors.push(color_to);
          lowestDeltaFCLumin = ((lowestDeltaFCLumin * colorCount[comboRgb]) + lowestLuminosity) / colorCount[comboRgb] + 1;
          colorCount[comboRgb]++;
          if (pypCanvasDB.colorWeights[comboRgb] < colorWeight) pypCanvasDB.colorWeights[comboRgb] = colorWeight;
          pypCanvasDB.foundLumins.push(lowestDeltaFCLumin);
        } else {

          pypCanvasDB.foundColors.push(color_to);
          colorCount[comboRgb] = 1;
          pypCanvasDB.colorWeights[comboRgb] = colorWeight;
          pypCanvasDB.foundLumins.push(lowestLuminosity);
        }

      } else {
        pypCanvasDB.foundColors.push(color_to);
        pypCanvasDB.foundLumins.push(lowestLuminosity);
      }

      i = 0;
      topRow = selectionDataBoundingRectMinY * W * 4;
      rowLength = W * 4;

      cx = tol;

      for (var ix = selectionDataBoundingRectMinX; ix < selectionDataBoundingRectMaxX; ix++) {

        i = topRow + (ix * 4);

        for (var iy = selectionDataBoundingRectMinY; iy < selectionDataBoundingRectMaxY; iy++) {
          if (pypCanvasDB.selectionData[cx].data[i] > 10) {
            paintEntireImageData[i] = color_to.r;
            paintEntireImageData[i + 1] = color_to.g;
            paintEntireImageData[i + 2] = color_to.b;
            paintEntireImageData[i + 3] = 255;
          }

          i += rowLength;
        }
      }
    }
    return pypProcessing;
  });

}());