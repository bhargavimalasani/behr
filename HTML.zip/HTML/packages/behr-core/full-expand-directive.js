(function() {
  "use strict";
  var app = angular.module('behrCore');
  app.directive('watchSize',function ($rootScope, $window, $timeout, $animate) {
    return {
      restrict: 'AC',
      link: function($scope, $element, $attrs) {
        function calculateSize() {
          var viewportHeight = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
          if (viewportHeight == 525) console.log($element);
          var viewportWidth = Math.max(document.documentElement.clientWidth, window.clientWidth || 0);
          $element.height(viewportHeight - $element.offset().top);
          $element.width(viewportWidth)
        }
        angular.element($window).bind('orientationchange', function () {
          $element.height(0);
          $element.width(0);
          calculateSize();
        });
        angular.element($window).bind('resize', function () {
          $element.height(0);
          $element.width(0);
          calculateSize();
        });
        $element.height(0);
        $element.width(0);
        calculateSize();
      }
    }
  });
  app.directive('fullExpand',function ($rootScope, $window, $interval, $animate) {
    return {
      restrict: 'AC',
      link: function($scope, $element, $attrs) {
        function calculateHeight() {
          var viewportHeight = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
          $element.height($element.parent().height() - $element.position().top);
        }
        angular.element($window).bind('orientationchange', function () {
          $element.height(0);
          calculateHeight();
        });
        var destroyInterval = $interval(() => {
          if ($element.hasClass('ng-animate')) return;
          calculateHeight();
        },1000);
        $scope.$on('destroy', () => {
          destroyInterval();
        });
      }
    }
  });
})();
