(function() {
  "use strict";
  var app = angular.module('behrCore');
  app.factory('pypTools', function(pypCanvasDB, paletteService, pypUtils, debounce, $timeout, $q) {
    var ALPHA = 255; // @todo what does this do?
    var repaintIsTurnedOn = true;
    var selectionDataBoundingRectMinX = pypUtils.W+1;
    var selectionDataBoundingRectMaxX = 0;
    var selectionDataBoundingRectMinY = pypUtils.H+1;
    var selectionDataBoundingRectMaxY = 0;
    var debouncedSaveSessionState = debounce(pypCanvasDB.saveSessionState, 100);

    function mergeImageDataOntoCanvas() {
      if (pypCanvasDB.drawingContext) {
        pypCanvasDB.drawingContext.drawImage(pypCanvasDB.newImage, 0, 0);
        pypCanvasDB.newImageContext.clearRect(0, 0, pypUtils.W, pypUtils.H);
        if (pypCanvasDB.newColorImage) {
          pypCanvasDB.bucketColorContext.drawImage(pypCanvasDB.newColor, 0, 0);
          pypCanvasDB.newColorContext.clearRect(0, 0, pypUtils.W, pypUtils.H);
        }
        return debouncedSaveSessionState();
      }
      return $q.when(undefined);
    }
    var pypTools = {
      _selectedTool: 'bucket',
      eraserRadius: 8,
      brushRadius: 8,
      brushDrawing: false,
      eraserDrawing: false,
      maskingShown: true,
      busy: false,
      handleMousedown(mouseX, mouseY) {
        mouseX = Math.floor(mouseX);
        mouseY = Math.floor(mouseY);
        if (pypTools.selectedTool == "maskingLine") {
          pypCanvasDB.undo.save();
          pypUtils.resetMaskingTool();
          pypUtils.maskingLine.drawing = true;
          pypUtils.maskingLine.startX = mouseX;
          pypUtils.maskingLine.startY = mouseY;
        } else if (pypTools.selectedTool == 'brush') {
          pypCanvasDB.undo.save();
          pypTools.brushDrawing = true;
          pypTools.doPaintBrush(mouseX - pypTools.brushRadius, mouseY - pypTools.brushRadius);
        } else if (pypTools.selectedTool == 'eraser') {
          pypCanvasDB.undo.save();
          pypTools.eraserDrawing = true;
          pypTools.doEraser(mouseX - pypTools.eraserRadius, mouseY - pypTools.eraserRadius);
        }
      },
      handleMousemove(mouseX, mouseY) {
        mouseX = Math.floor(mouseX);
        mouseY = Math.floor(mouseY);
        if (pypTools.selectedTool == "maskingPoly" && pypUtils.maskingPoly.drawing) {
          pypUtils.maskingPoly.mouseX = mouseX;
          pypUtils.maskingPoly.mouseY = mouseY;
          pypUtils.drawLines(pypCanvasDB.maskingLines, pypCanvasDB.maskingTop);
        } else if (pypTools.selectedTool == 'brush' && pypTools.brushDrawing) {
          pypCanvasDB.undo.save();
          pypTools.doPaintBrush(mouseX - pypTools.brushRadius, mouseY - pypTools.brushRadius);
        } else if (pypTools.selectedTool == "eraser" && pypTools.eraserDrawing) {
          pypCanvasDB.undo.save();
          pypTools.doEraser(mouseX - pypTools.eraserRadius, mouseY - pypTools.eraserRadius);
        } else if (pypTools.selectedTool == "maskingLine") {
          pypUtils.maskingLine.endX = mouseX;
          pypUtils.maskingLine.endY = mouseY;
          pypUtils.drawLines(pypCanvasDB.maskingLines, pypCanvasDB.maskingTop);
        }
      },
      handleMouseup(mouseX, mouseY) {
        mouseX = Math.floor(mouseX);
        mouseY = Math.floor(mouseY);
        mergeImageDataOntoCanvas();
        if (pypTools.selectedTool == "bucket") {
          pypCanvasDB.undo.save();
          pypTools.busy = true;
          $timeout(function() {
            $timeout(function()  {
              pypTools.tool_magic_wand(pypCanvasDB.drawingContext, pypUtils.W, pypUtils.H, mouseX, mouseY, 5, pypCanvasDB.bucketEdgeContext, false);
              pypTools.bucketToleranceStarted = true;
              pypTools.bucketToleranceShowing = false;
            });
          })
        } if (pypTools.selectedTool == "maskingLine") {
          pypTools.doMaskingLineEnd(mouseX, mouseY);
        } else if (pypTools.selectedTool == "maskingPoly") {
          pypTools.doMaskingPolyMouseup(mouseX, mouseY);
        } else if (pypTools.selectedTool == 'brush' && pypTools.brushDrawing) {
          pypTools.brushDrawing = false;
          pypCanvasDB.undo.save();
          pypTools.doPaintBrushEnd();
        } else if (pypTools.selectedTool == 'eraser' && pypTools.eraserDrawing) {
          pypTools.eraserDrawing = false;
          pypCanvasDB.undo.save();
        }
      },
      _checkBucketEnd() {
        if (pypTools.bucketToleranceStarted) {
          pypTools.bucketToleranceDone();
          mergeImageDataOntoCanvas();
        }
      },
      doUndo() {
        if (pypTools.busy) return;
        pypTools.busy = true;
        pypTools._checkBucketEnd();
        pypCanvasDB.undo.undo();
        pypTools.busy = false;
      },
      doMaskingRemove() {
        pypUtils.removeAllMasking(pypCanvasDB);
      },
      doUnpaintImage() {
        pypTools._checkBucketEnd();
        // Store undo state
        pypCanvasDB.undo.save();

        // reset the drawing canvas
        pypCanvasDB.drawingContext.drawImage(pypCanvasDB.predrawing, 0, 0);

        var colorCanvasContext = pypCanvasDB.bucketColor.getContext("2d");
        colorCanvasContext.clearRect(0, 0, pypUtils.W, pypUtils.H);
        pypCanvasDB.lumin.imageData = pypCanvasDB.drawingContext.createImageData(pypUtils.W, pypUtils.H).data;


        // Clear helper canvases
        pypCanvasDB.newImage.getContext("2d").clearRect(0, 0, pypUtils.W, pypUtils.H);
        pypCanvasDB.newColor.getContext("2d").clearRect(0, 0, pypUtils.W, pypUtils.H);

        mergeImageDataOntoCanvas();

        pypCanvasDB.saveSessionState();
      },
      doMaskingPolyMouseup(mouseX, mouseY) {
        if (pypUtils.maskingPoly.drawing) {
          if (mouseX >= pypUtils.maskingPoly.startX - pypUtils.maskingPolyMagnetRadius &&
            mouseX <= pypUtils.maskingPoly.startX + pypUtils.maskingPolyMagnetRadius &&
            mouseY >= pypUtils.maskingPoly.startY - pypUtils.maskingPolyMagnetRadius &&
            mouseY <= pypUtils.maskingPoly.startY + pypUtils.maskingPolyMagnetRadius) {
            // We're ending the polygon. Either we have a single point or a real polygon
            if (pypUtils.maskingPoly.coords.length <= 1) {
              pypUtils.resetMaskingTool();
              return;
            }
            // we have a real polygon if we get to here
            pypTools.doMaskingPolyEnd(mouseX, mouseY);
          } else {
            // we are continuing the polygon here, the click was not within range of the start point
            pypUtils.maskingPoly.coords.push({
              x: mouseX,
              y: mouseY
            });
          }
        } else { // Start a polygon
          pypCanvasDB.undo.save();
          pypUtils.resetMaskingTool();
          pypUtils.maskingPoly.drawing = true;
          pypUtils.maskingPoly.startX = mouseX;
          pypUtils.maskingPoly.startY = mouseY;
          pypUtils.maskingPoly.coords.push({
            x: mouseX,
            y: mouseY
          });
        }
        pypUtils.drawLines(pypCanvasDB.maskingLines, pypCanvasDB.maskingTop);
      },
      doMaskingPolyEnd(mouseX, mouseY) {
        pypUtils.maskingPoly.coords.push({
          x: pypUtils.maskingPoly.startX,
          y: pypUtils.maskingPoly.startY
        });
        // poly to lines
        pypUtils.maskingPoly.coords.forEach((point, index) => {
          if (index === 0) return;
          pypCanvasDB.maskingLines.push({
            x1: pypUtils.maskingPoly.coords[index - 1].x,
            y1: pypUtils.maskingPoly.coords[index - 1].y,
            x2: point.x,
            y2: point.y
          })
        })
        // draw polygon to edge canvas
        var edgeCanvas = pypCanvasDB.bucketEdge.getContext('2d');
        edgeCanvas.fillStyle = '#000';

        edgeCanvas.beginPath();
        edgeCanvas.moveTo(pypUtils.maskingPoly.coords[0].x, pypUtils.maskingPoly.coords[0].y);
        for (var coord = 1; coord < pypUtils.maskingPoly.coords.length - 1; coord++) {
          edgeCanvas.lineTo(pypUtils.maskingPoly.coords[coord].x, pypUtils.maskingPoly.coords[coord].y);
        }
        edgeCanvas.closePath();
        edgeCanvas.fill();

        pypUtils.resetMaskingTool();

        pypUtils.drawLines(pypCanvasDB.maskingLines, pypCanvasDB.maskingTop);
      },
      doPaintBrush(paintLeft, paintTop) {
        var paintX = paintLeft + pypTools.brushRadius;
        var paintY = paintTop + pypTools.brushRadius
        pypTools.doPaintBrush.lastX = paintX;
        pypTools.doPaintBrush.lastY = paintY;
        var paintRight = paintLeft + pypTools.brushRadius * 2;
        var paintBottom = paintTop + pypTools.brushRadius * 2;

        // Crop at boundaries
        if (paintTop < 0) {
          paintTop = 0;
        }
        if (paintLeft < 0) {
          paintLeft = 0;
        }
        if (paintRight > pypUtils.W) {
          paintTop = pypUtils.W;
        }
        if (paintBottom > pypUtils.H) {
          paintBottom = pypUtils.H;
        }

        // Get all pixels in paint brush circle
        var brushRadiusSquared = pypTools.brushRadius * pypTools.brushRadius;
        var paintBrushCircleIndices = [];
        var paintBrushWidth = paintRight - paintLeft;
        var paintBrushHeight = paintBottom - paintTop;

        for (var x = 0; x < paintBrushWidth; x++) {
          for (var y = 0; y < paintBrushHeight; y++) {
            var dx = x - pypTools.brushRadius;
            var dy = y - pypTools.brushRadius;
            var distanceSquared = dx * dx + dy * dy;

            if (distanceSquared <= brushRadiusSquared) {
              paintBrushCircleIndices.push((y * (paintBrushWidth * 4)) + (x * 4));
            }
          }
        }

        // @todo are these used?
        var merged = pypCanvasDB.drawingContext.createImageData(paintBrushWidth, paintBrushHeight);
        var mergedColor = pypCanvasDB.drawingContext.createImageData(paintBrushWidth, paintBrushHeight);
        var ogImage = pypCanvasDB.predrawingContext.getImageData(0, 0, pypUtils.W, pypUtils.H).data;
        var newImage = pypCanvasDB.drawingContext.getImageData(paintLeft, paintTop, paintBrushWidth, paintBrushHeight).data;
        var colorCanvasImage = pypCanvasDB.bucketColorContext.getImageData(paintLeft, paintTop, paintBrushWidth, paintBrushHeight).data;

        var color_to = pypUtils.hexToRgba(paletteService.palette.selectedColor.rgb);

        var toColorLCH = ColorUtilities.convertRGBToLAB(color_to.r, color_to.g, color_to.b);

        var segData = pypCanvasDB.segment.getContext("2d").getImageData(0, 0, pypUtils.W, pypUtils.H).data;
        var baseOffset = (paintTop * (pypUtils.W * 4)) + (paintLeft * 4);
        var lastFoundColor = 0;
        var prevLumin = 0;
        var compLumins = 0;
        var uLumins;
        var cachedLumins = 0;
        var leftLumin;

        for (var z = 0; z < paintBrushCircleIndices.length; z++) {
          var i = paintBrushCircleIndices[z];

          var iyy = Math.floor(i / (paintBrushWidth * 4));
          var ixx = (i - (iyy * (paintBrushHeight * 4))) / 4;

          var ii = ((paintTop + iyy) * (pypUtils.W * 4)) + ((paintLeft + ixx) * 4);
          //debugger;
          if (colorCanvasImage[ii] == color_to.r) continue;

          if (pypCanvasDB.lumin.superMap[i + 3] > 0) {
            uLumins = pypCanvasDB.lumin.superMap[i];
          } else {

            uLumins = pypCanvasDB.computedLumins;

            if (pypCanvasDB.lumin.imageData[ii + 3] > 0 && pypCanvasDB.lumin.imageData[ii + 3] < 255) {
              uLumins = pypCanvasDB.lumin.imageData[ii + 3];

            }


            var foundIt = false;

            var lowestDeltaFC = 0;
            var lowestDelta = 31;
            var lowestLuminosity = 0;

            if (pypCanvasDB.foundColors.length !== 0) {

              if (segData[ii] > 0) {
                for (var fc = 0; fc < pypCanvasDB.foundColors.length; fc++) {
                  if (pypCanvasDB.foundColors[fc].r == segData[ii]) {
                    //debugger;
                    cachedLumins = pypCanvasDB.foundLumins[fc];
                    foundIt = true;
                    lastFoundColor = pypCanvasDB.foundColors[fc];
                    break;
                  }
                }
              }
              if (!foundIt) {

                var toLab = ColorUtilities.convertRGBToLAB(ogImage[ii], ogImage[ii + 1], ogImage[ii + 2]);

                for (var fc = 0; fc < pypCanvasDB.foundColors.length; fc++) {
                  var foundLab = ColorUtilities.convertRGBToLAB(pypCanvasDB.foundColors[fc].r, pypCanvasDB.foundColors[fc].g, pypCanvasDB.foundColors[fc].b);
                  var deltaE = ColorUtilities.colorCompareDE1994(foundLab[0], foundLab[1], foundLab[2], toLab[0], toLab[1], toLab[2]);
                  //if (foundColors[fc] == lastFoundColor) deltaE = deltaE - 10;
                  if (lowestDelta == -1) {
                    lowestDeltaFC = fc;
                    lowestDelta = deltaE;
                    lowestLuminosity = foundLab[0];
                  } else if (deltaE < lowestDelta) {
                    lowestDelta = deltaE;
                    lowestDeltaFC = fc;
                    lowestLuminosity = foundLab[0];
                  }
                }

                if (lowestDelta < 10) {
                  cachedLumins = lowestLuminosity;

                } else {
                  if (compLumins != 0) {
                    cachedLumins = compLumins
                  } else {
                    cachedLumins = toLab[0];
                  }
                }
              }
            }



            if (cachedLumins > 0) uLumins = cachedLumins;

            if (uLumins < 15) uLumins = 15;
          }



          var modifier = uLumins - toColorLCH[0];
          if (modifier < 0) {
            modifier = (100 + modifier) / 100;
          } else if (modifier > 0) {
            modifier = (100 / (100 - modifier));
          } else {
            modifier = 1;
          }

          var newLumin = ((pypCanvasDB.lumin.map.data[ii] / uLumins) * toColorLCH[0]);

          newLumin = (newLumin * (modifier)) - ((uLumins - toColorLCH[0]) / 1.5);

          if (newLumin > 100) newLumin = 100;
          //if (cachedLumins < 5) newLumin = newLumin * .9;
          if (ixx != 0) {
            var leftLuminI = ((iyy * (pypUtils.W * 4)) + ((ixx - 1) * 4));
            leftLumin = ColorUtilities.convertRGBToLAB(newImage[leftLuminI], newImage[leftLuminI + 1], newImage[leftLuminI + 2])[0];
          }
          if (prevLumin > 0 && (cachedLumins < 10 || Math.abs(prevLumin - newLumin) > 5 || Math.abs(leftLumin - newLumin)) > 5) {
            if (leftLumin > 0 && ixx != 0) {
              newLumin = ((prevLumin * 2) + (leftLumin * 2) + newLumin) / 5;
            } else {
              newLumin = ((prevLumin * 4) + newLumin) / 5;
            }
            // debugger;
          }

          //if (prevLumin != 0 && Math.abs(prevLumin - newLumin) > 15) continue;


          prevLumin = newLumin;
          var newColor = ColorUtilities.convertLABToRGB(newLumin, toColorLCH[1], toColorLCH[2]);

          //debugger
          newImage[i] = newColor[0];
          newImage[i + 1] = newColor[1];
          newImage[i + 2] = newColor[2];
          newImage[i + 3] = 255;

          colorCanvasImage[i] = color_to.r;
          colorCanvasImage[i + 1] = color_to.g;
          colorCanvasImage[i + 2] = color_to.b;
          colorCanvasImage[i + 3] = 255;
        }

        if (merged.data.set) {
          merged.data.set(newImage);
          mergedColor.data.set(colorCanvasImage);
        } else {
          for (var i = 0; i < merged.data.length; ++i) {
            merged.data[i] = newImage[i];
            mergedColor.data[i] = colorCanvasImage[i];
          }
        }
        pypCanvasDB.drawingContext.putImageData(merged, paintLeft, paintTop);
        pypCanvasDB.bucketColorContext.putImageData(mergedColor, paintLeft, paintTop);
      },
      doMaskingLineEnd(mouseX, mouseY) {
        pypUtils.maskingLine.drawing = false;
        pypUtils.maskingLine.endX = mouseX;
        pypUtils.maskingLine.endY = mouseY;
        // Draw on edge canvas
        var canvasMaskContext = pypCanvasDB.bucketEdge.getContext('2d');
        canvasMaskContext.strokeStyle = '#0000ff'; // draw blue
        canvasMaskContext.fillStyle = '#0000ff';
        canvasMaskContext.lineWidth = 1.5;
        canvasMaskContext.beginPath();
        canvasMaskContext.moveTo(pypUtils.maskingLine.startX, pypUtils.maskingLine.startY);
        canvasMaskContext.lineTo(pypUtils.maskingLine.endX, pypUtils.maskingLine.endY);
        canvasMaskContext.stroke();
        // add masking line to array
        pypCanvasDB.maskingLines.push({
          x1: pypUtils.maskingLine.startX,
          y1: pypUtils.maskingLine.startY,
          x2: pypUtils.maskingLine.endX,
          y2: pypUtils.maskingLine.endY
        });
        pypUtils.resetMaskingTool();
      },
      doPaintBrushEnd() { // do not call directly since this is debounced by doPaintBrush
        mergeImageDataOntoCanvas();
        //----Do "repaint"------//
        if (repaintIsTurnedOn) {
          pypTools.busy = true;
          $timeout(function() {
            $timeout(function() {
              pypTools.tool_magic_wand(pypCanvasDB.drawingContext, pypUtils.W, pypUtils.H, pypTools.doPaintBrush.lastX, pypTools.doPaintBrush.lastY, 5, pypCanvasDB.bucketEdgeContext, true);
            })
          })
        }
        //----------------------//
        pypCanvasDB.saveSessionState();
      },
      doEraser(x, y) {
        var eraserX = x + pypTools.eraserRadius;
        var eraserY = y + pypTools.eraserRadius;
        var eraserContext = pypCanvasDB.drawingContext;
        // Crop at boundaries
        if (eraserY < 0) {
          eraserY = 0;
        }
        if (eraserX < 0) {
          eraserX = 0;
        }
        if (eraserX > pypUtils.W) {
          eraserX = pypUtils.W;
        }
        if (eraserY > pypUtils.H) {
          eraserY = pypUtils.H;
        }
        eraserContext.save();
        eraserContext.beginPath();
        eraserContext.arc(eraserX, eraserY, pypTools.eraserRadius, 0, Math.PI * 2, true);
        eraserContext.closePath();
        eraserContext.clip();
        eraserContext.drawImage(pypCanvasDB.predrawing, x, y, pypTools.eraserRadius * 2, pypTools.eraserRadius * 2, x, y, pypTools.eraserRadius * 2, pypTools.eraserRadius * 2);
        eraserContext.restore();

        var colorContext = pypCanvasDB.bucketColorContext;
        colorContext.save();
        colorContext.beginPath();
        colorContext.arc(eraserX, eraserY, pypTools.eraserRadius, 0, Math.PI * 2, true);
        colorContext.closePath();
        colorContext.clip();
        colorContext.clearRect(x, y, pypTools.eraserRadius * 2, pypTools.eraserRadius * 2);
        colorContext.restore();
      },
      bucketTolerance: 10,
      bucketToleranceStarted: false,
      bucketToleranceShowing: false,
      bucketToleranceDone() {
        pypTools.bucketToleranceStarted = false;
        pypTools.bucketToleranceShowing = false;
        pypTools.getFullMerge(pypTools.bucketTolerance, undefined, undefined, pypCanvasDB.computedLumins, selectionDataBoundingRectMinX, selectionDataBoundingRectMaxX, selectionDataBoundingRectMinY, selectionDataBoundingRectMaxY);
        return mergeImageDataOntoCanvas();
      },
      bucketTolerancePreview() {
        pypTools.bucketToleranceShowing = false;
        pypTools.getFullMerge(pypTools.bucketTolerance, undefined, undefined, pypCanvasDB.computedLumins, selectionDataBoundingRectMinX, selectionDataBoundingRectMaxX, selectionDataBoundingRectMinY, selectionDataBoundingRectMaxY);
      },
      bucketToleranceChange(tol) {
        if (!pypTools.bucketToleranceStarted) return;
        var colorMapTemp = pypCanvasDB.drawingContext.createImageData(pypUtils.W, pypUtils.H);

        var i = 0;
        var topRow = selectionDataBoundingRectMinY * pypUtils.W * 4;
        var rowLength = pypUtils.W * 4;

        var color_to = pypUtils.hexToRgba(paletteService.palette.selectedColor.rgb);

        for (var ix = selectionDataBoundingRectMinX; ix < selectionDataBoundingRectMaxX; ix++) {

          i = topRow + (ix * 4);

          for (var iy = selectionDataBoundingRectMinY; iy < selectionDataBoundingRectMaxY; iy++) {
            //var i = ((iy * (W * 4)) + (ix * 4));


            for (var cx = tol; cx > -1; cx--) {
              if (pypCanvasDB.selectionData[cx].data[i] > 10) {
                colorMapTemp.data[i] = color_to.r;
                colorMapTemp.data[i + 1] = color_to.g;
                colorMapTemp.data[i + 2] = color_to.b;
                colorMapTemp.data[i + 3] = 255;
              }
            }

            i += rowLength;
          }
        }
        pypTools.bucketToleranceShowing = true;
        pypCanvasDB.newImageOverlay.getContext("2d").putImageData(colorMapTemp, 0, 0);
      },
      tool_magic_wand(context, W, H, x, y, sensitivity, maskContext, isBrushRepaint, color) {
        var imgData = context.getImageData(0, 0, W, H).data;

        var ogSmoothData = pypCanvasDB.smooth.getContext("2d").getImageData(0, 0, W, H).data;

        var W4 = W * 4;

        selectionDataBoundingRectMinX = pypUtils.W+1;
        selectionDataBoundingRectMaxX = 0;
        selectionDataBoundingRectMinY = pypUtils.H+1;
        selectionDataBoundingRectMaxY = 0;
        var tempBoundingRectangleY = 0;
        var tempBoundingRectangleX = 0;

        var paintedData = pypCanvasDB.bucketColor.getContext("2d").getImageData(0, 0, W, H).data;
        var maskLineData = pypCanvasDB.maskingTop.getContext("2d").getImageData(0, 0, W, H).data;
        var cannyData = pypCanvasDB.canny.getContext("2d").getImageData(0, 0, W, H).data;
        var cx;
        for (cx = 0; cx < pypCanvasDB.maxTolerance; cx++) {
          pypCanvasDB.selectionData[cx] = context.createImageData(W, H);
        }

        var merged = context.createImageData(W, H);
        var maskData = maskContext.getImageData(0, 0, W, H).data;


        var offset = ((y * (W4)) + (x * 4));
        var dx = [0, -1, +1, 0];
        var dy = [-1, 0, 0, +1];
        var color_to = pypUtils.hexToRgba(paletteService.palette.selectedColor.rgb);

        var color_from = {
          r: maskData[offset + 0],
          g: maskData[offset + 1],
          b: maskData[offset + 2],
          a: maskData[offset + 3],
        }


        var isPainted = false;
        var paintedRGB = Array();
        if (paintedData[offset + 3] > 0) {
          isPainted = true;
          paintedRGB[0] = paintedData[offset + 0]
          paintedRGB[1] = paintedData[offset + 1]
          paintedRGB[2] = paintedData[offset + 2]
        }


        var drawcontext = pypCanvasDB.drawing.getContext("2d");
        var drawimg = drawcontext.getImageData(0, 0, W, H);
        var drawimgData = drawimg.data;

        var orginalLAB = ColorUtilities.convertRGBToLAB(drawimgData[offset + 0], drawimgData[offset + 1], drawimgData[offset + 2]);

        if (color_from.r == color_to.r &&
          color_from.g == color_to.g &&
          color_from.b == color_to.b &&
          color_from.a == color_to.a)
          return false;
        //if (ALPHA < 255 && color_from.a == ALPHA) return false;

        var marked = [];
        //var newImage = new Uint8ClampedArray(context.getImageData(0, 0, W, H).data);
        var newImage = context.getImageData(0, 0, W, H).data;
        var iLumins = 0;
        var iCount = 0;

        for (var tol = 1; tol < pypCanvasDB.maxTolerance; tol += 2) {
          var stack = [];
          stack.push(x);
          stack.push(y);


          var usedStack = [];
          //var usedImage = new Uint8ClampedArray(context.getImageData(0, 0, W, H).data);
          var usedImage = context.getImageData(0, 0, W, H).data;
          while (stack.length > 0) {
            var curPointY = stack.pop();
            var curPointX = stack.pop();


            for (var i = 0; i < 4; i++) {
              var nextPointX = curPointX + dx[i];
              var nextPointY = curPointY + dy[i];
              if (nextPointX < 0 || nextPointY < 0 || nextPointX >= W || nextPointY >= H)
                continue;
              offset = (nextPointY * W + nextPointX) * 4;


              if (usedImage[offset] != 1) {
                usedImage[offset] = 1;
                //check
                if (newImage[offset] == 255) {
                  stack.push(nextPointX);
                  stack.push(nextPointY);

                  continue;
                }


                var currentLAB = ColorUtilities.convertRGBToLAB(imgData[offset + 0], imgData[offset + 1], imgData[offset + 2]);
                //debugger;



                if (isPainted === false && paintedData[offset] != 0) continue;
                //if (cannyData[i] > 100) continue;

                if ((((isPainted === false && Math.abs(maskData[offset + 0] - color_from.r) < tol) || (isPainted === true && paintedRGB[0] == paintedData[offset] && paintedRGB[1] == paintedData[offset + 1])) && maskLineData[offset + 0] === 0)) {
                  //fill pixel
                  var tolerance = Math.abs(maskData[offset + 0] - color_from.r);
                  if (ALPHA == 255) {

                    if (tol < 30) {
                      iLumins += pypCanvasDB.lumin.map.data[offset];
                      //debugger;
                      iCount++;
                    }

                    pypCanvasDB.selectionData[tol].data[offset + 0] = 255; //red
                    pypCanvasDB.selectionData[tol].data[offset + 3] = 255; //alpha
                    newImage[offset] = 255;

                    tempBoundingRectangleY = Math.floor(offset / (W4));
                    tempBoundingRectangleX = (offset - (tempBoundingRectangleY * (W4))) / 4;

                    if (tempBoundingRectangleY < selectionDataBoundingRectMinY) {
                      selectionDataBoundingRectMinY = tempBoundingRectangleY;
                    } else if (tempBoundingRectangleY > selectionDataBoundingRectMaxY) {
                      selectionDataBoundingRectMaxY = tempBoundingRectangleY;
                    }
                    if (tempBoundingRectangleX < selectionDataBoundingRectMinX) {
                      selectionDataBoundingRectMinX = tempBoundingRectangleX;
                    } else if (tempBoundingRectangleX > selectionDataBoundingRectMaxX) {
                      selectionDataBoundingRectMaxX = tempBoundingRectangleX;
                    }

                  } else
                    imgData[offset + 3] = ALPHA; //a



                  stack.push(nextPointX);
                  stack.push(nextPointY);
                } else {
                  var nearby = pypUtils.isNearbyPixel(paintedData, color_to.r, color_to.g, color_to.b, 6, nextPointX, nextPointY, cannyData);
                  if (isPainted == false && (Math.abs(maskData[offset + 0] - color_from.r) < (tol + 155) || nearby > 0)) {
                    //debugger;
                    var tolerance = Math.abs(maskData[offset + 0] - color_from.r);
                    if (ALPHA == 255) {

                      if (tol < 30) {
                        iLumins += pypCanvasDB.lumin.map.data[offset];
                        iCount++;
                      }

                      pypCanvasDB.selectionData[tol].data[offset + 0] = 255; //r
                      pypCanvasDB.selectionData[tol].data[offset + 3] = 255; //r
                      if (nearby == 2) {
                        newImage[offset] = 255;
                      }

                      tempBoundingRectangleY = Math.floor(offset / (W4));
                      tempBoundingRectangleX = (offset - (tempBoundingRectangleY * (W4))) / 4;

                      if (tempBoundingRectangleY < selectionDataBoundingRectMinY) {
                        selectionDataBoundingRectMinY = tempBoundingRectangleY;
                      } else if (tempBoundingRectangleY > selectionDataBoundingRectMaxY) {
                        selectionDataBoundingRectMaxY = tempBoundingRectangleY;
                      }
                      if (tempBoundingRectangleX < selectionDataBoundingRectMinX) {
                        selectionDataBoundingRectMinX = tempBoundingRectangleX;
                      } else if (tempBoundingRectangleX > selectionDataBoundingRectMaxX) {
                        selectionDataBoundingRectMaxX = tempBoundingRectangleX;
                      }
                    } else
                      imgData[offset + 3] = ALPHA; //a
                  }
                }
              }
            }
          }


        }

        pypCanvasDB.computedLumins = iLumins / iCount;
        if (!color) {
          pypTools.bucketTolerance = 20;
          pypTools.getFullMerge(20, false, isPainted, pypCanvasDB.computedLumins, selectionDataBoundingRectMinX, selectionDataBoundingRectMaxX, selectionDataBoundingRectMinY, selectionDataBoundingRectMaxY);
        } else {
          pypTools.bucketTolerance = 10;
          pypTools.getFullMerge(10, color, isPainted, pypCanvasDB.computedLumins, selectionDataBoundingRectMinX, selectionDataBoundingRectMaxX, selectionDataBoundingRectMinY, selectionDataBoundingRectMaxY);
        }
        if (isBrushRepaint || isPainted) {
          mergeImageDataOntoCanvas();
        }
      },
      getFullMerge(tol, color, skipDilation, compLumins, selectionDataBoundingRectMinX, selectionDataBoundingRectMaxX, selectionDataBoundingRectMinY, selectionDataBoundingRectMaxY) {
        var W4 = pypUtils.W * 4;
        var color_to;
        var merged = pypCanvasDB.drawingContext.createImageData(pypUtils.W, pypUtils.H);
        //mergedColor = context2.createImageData(W, H);

        var ogMain = pypCanvasDB.predrawing;
        var ogContext = ogMain.getContext("2d");
        var ogData = ogContext.getImageData(0, 0, pypUtils.W, pypUtils.H);

        var newImageData = pypCanvasDB.newImage.getContext("2d").createImageData(pypUtils.W, pypUtils.H);

        //var ogImage = new Uint8ClampedArray(ogContext.getImageData(0, 0, W, H).data);
        var segData = pypCanvasDB.segmentContext.getImageData(0, 0, pypUtils.W, pypUtils.H).data;
        pypCanvasDB.newColorImage = pypCanvasDB.newColorContext.createImageData(pypUtils.W, pypUtils.H);
        var emptyColors = [];
        if (!color) {
          color_to = pypUtils.hexToRgba(paletteService.palette.selectedColor.rgb);
        } else {
          color_to = color;
        }

        if (color_to.r < 2) {
          color_to.r = 2;
        }

        var toColorLCH = ColorUtilities.convertRGBToLAB(color_to.r, color_to.g, color_to.b);
        //toColorLCH = ColorUtilities.toLCH(toColorLCH[0], toColorLCH[1], toColorLCH[2]);

        var colorMap = pypCanvasDB.drawingContext.createImageData(pypUtils.W, pypUtils.H);

        var i = 0;
        var topRow = selectionDataBoundingRectMinY * W4;
        var rowLength = W4;



        for (var ix = selectionDataBoundingRectMinX; ix < selectionDataBoundingRectMaxX; ix++) {

          i = topRow + (ix * 4);

          for (var iy = selectionDataBoundingRectMinY; iy < selectionDataBoundingRectMaxY; iy++) {
            //var i = ((iy * (W * 4)) + (ix * 4));


            for (var cx = tol; cx > -1; cx--) {
              if (colorMap.data[i] == 255 || color_to.r == colorMap.data[i]) {
                continue;
              }
              if (pypCanvasDB.selectionData[cx].data[i] > 10) {
                colorMap.data[i] = 255;
                colorMap.data[i + 1] = 255;
                colorMap.data[i + 2] = 255;
                colorMap.data[i + 3] = 255;
              } else {
                colorMap.data[i] = 1;
                colorMap.data[i + 1] = 1;
                colorMap.data[i + 2] = 1;
                colorMap.data[i + 3] = 255;
              }
            }

            i += rowLength;
          }
        }

        if (!skipDilation) colorMap = pypUtils.dilatation(pypCanvasDB.drawingContext, pypUtils.erosion(pypCanvasDB.drawingContext, pypUtils.dilatation(pypCanvasDB.drawingContext, colorMap)));

        i = 0;
        topRow = selectionDataBoundingRectMinY * W4;
        rowLength = W4;
        var prevLumin = 0;
        var lastFoundColor = 0;
        for (var ix = selectionDataBoundingRectMinX; ix < selectionDataBoundingRectMaxX; ix++) {

          i = topRow + (ix * 4);

          for (var iy = selectionDataBoundingRectMinY; iy < selectionDataBoundingRectMaxY; iy++) {
            //var i = ((iy * (W * 4)) + (ix * 4));

            if (colorMap.data[i] > 10) {
              //HSLColor newColor = new HSLColor(targetColor.Hue, targetColor.Saturation, (currentColor.Luminosity / lumins) * targetColor.Luminosity);

              // var newLab = ColorUtilities.toLAB((fromColorLCH.l / lumins) * toColorLCH.l, toColorLCH.c, toColorLCH.h);
              var uLumins = pypCanvasDB.computedLumins;

              if (pypCanvasDB.lumin.superMap[i + 3] == 255) {
                uLumins = pypCanvasDB.lumin.superMap[i];
              } else {
                if (pypCanvasDB.lumin.imageData[i + 3] > 0 && pypCanvasDB.lumin.imageData[i + 3] < 255) {
                  uLumins = pypCanvasDB.lumin.imageData[i + 3];
                }

                var cachedLumins = 0;
                var foundIt = false;

                var lowestDeltaFC = 0;
                var lowestDelta = 31;
                var lowestLuminosity = 0;
                var firstFound = null;
                var lastFoundLab = null;
                if (pypCanvasDB.foundColors.length != 0) {

                  if (segData[i] > 0) {
                    for (var fc = 0; fc < pypCanvasDB.foundColors.length; fc++) {
                      if (pypCanvasDB.foundColors[fc].r == segData[i] && pypCanvasDB.foundColors[fc].g == segData[i + 1] && pypCanvasDB.foundColors[fc].b == segData[i + 2]) {
                        //debugger;
                        cachedLumins = pypCanvasDB.foundLumins[fc];
                        foundIt = true;


                        //ColorUtilities.colorCompareDE1994(foundLab[0], foundLab[1], foundLab[2], toLab[0], toLab[1], toLab[2]);
                        if (lastFoundColor != 0 && lastFoundColor.r != pypCanvasDB.foundColors[fc].r) {
                          var foundLab = ColorUtilities.convertRGBToLAB(pypCanvasDB.foundColors[fc].r, pypCanvasDB.foundColors[fc].g, pypCanvasDB.foundColors[fc].b);
                          var lastFoundLab = ColorUtilities.convertRGBToLAB(lastFoundColor.r, lastFoundColor.g, lastFoundColor.b);
                          var deltaEE = ColorUtilities.colorCompareDE1994(foundLab[0], foundLab[1], foundLab[2], lastFoundLab[0], lastFoundLab[1], lastFoundLab[2]);
                          if (deltaEE < 35) cachedLumins = lastFoundLab[0];

                        } else {
                          lastFoundColor = pypCanvasDB.foundColors[fc];
                        }




                        if (!firstFound) firstFound = pypCanvasDB.foundColors[fc];
                        break;
                      }
                    }
                  }
                  if (!foundIt) {

                    var toLab = ColorUtilities.convertRGBToLAB(ogData.data[i], ogData.data[i + 1], ogData.data[i + 2]);

                    for (var fc = 0; fc < pypCanvasDB.foundColors.length; fc++) {
                      var foundLab = ColorUtilities.convertRGBToLAB(pypCanvasDB.foundColors[fc].r, pypCanvasDB.foundColors[fc].g, pypCanvasDB.foundColors[fc].b);
                      var deltaE = ColorUtilities.colorCompareDE1994(foundLab[0], foundLab[1], foundLab[2], toLab[0], toLab[1], toLab[2]);
                      var comboFoundRgb = ColorUtilities.combineRGB(pypCanvasDB.foundColors[fc].r, pypCanvasDB.foundColors[fc].g, pypCanvasDB.foundColors[fc].b);

                      if (pypCanvasDB.foundColors[fc] == lastFoundColor) {
                        //deltaE = deltaE - 30;

                      }

                      if (lowestDelta == -1) {
                        lowestDeltaFC = fc;
                        lowestDelta = deltaE - pypCanvasDB.colorWeights[comboFoundRgb];
                        lowestLuminosity = foundLab[0];
                      } else if (deltaE < lowestDelta) {
                        lowestDelta = deltaE;
                        lowestDeltaFC = fc;
                        lowestLuminosity = foundLab[0];
                      }
                    }

                    if (lowestDelta < 10) {
                      cachedLumins = lowestLuminosity;

                    } else {
                      if (compLumins != 0) {
                        cachedLumins = compLumins;
                      } else {
                        cachedLumins = toLab[0];
                      }
                    }
                  }
                }

                if (cachedLumins > 0) uLumins = cachedLumins;

                if (uLumins < 15) {
                  uLumins = 15;
                }

                // cache lumin 4
                if (pypCanvasDB.lumin.superMap[i + 3] == 0) {
                  pypCanvasDB.lumin.superMap[i] = uLumins;
                  pypCanvasDB.lumin.superMap[i + 3] = 255;
                }
              }

              var modifier = uLumins - toColorLCH[0];
              if (modifier < 0) {
                modifier = (100 + modifier) / 100;
              } else if (modifier > 0) {
                modifier = (100 / (100 - modifier));
              } else {
                modifier = 1;
              }

              var newLumin = ((pypCanvasDB.lumin.map.data[i] / uLumins) * toColorLCH[0]);

              newLumin = (newLumin * (modifier)) - ((uLumins - toColorLCH[0]) / 1.5);

              if (newLumin > 100) newLumin = 100;
              //if (cachedLumins < 5) newLumin = newLumin * .9;
              if (ix != 0) {
                var leftLuminI = ((iy * (pypUtils.W * 4)) + ((ix - 1) * 4));
                var leftLumin = ColorUtilities.convertRGBToLAB(newImageData.data[leftLuminI], newImageData.data[leftLuminI + 1], newImageData.data[leftLuminI + 2])[0];
              }
              if (prevLumin > 0 && iy != selectionDataBoundingRectMinY && ix != selectionDataBoundingRectMinX && (cachedLumins < 10 || Math.abs(prevLumin - newLumin) > 5 || Math.abs(leftLumin - newLumin)) > 5) {
                if (leftLumin > 0 && ix != 0) {
                  newLumin = ((prevLumin * 2) + (leftLumin * 2) + newLumin) / 5;
                } else {
                  newLumin = ((prevLumin * 4) + newLumin) / 5;
                }
                // debugger;
              }

              //if (prevLumin != 0 && Math.abs(prevLumin - newLumin) > 15) continue;


              prevLumin = newLumin;
              var newColor = ColorUtilities.convertLABToRGB(newLumin, toColorLCH[1], toColorLCH[2]);

              //debugger;
              newImageData.data[i] = newColor[0];
              newImageData.data[i + 1] = newColor[1];
              newImageData.data[i + 2] = newColor[2];
              newImageData.data[i + 3] = 255;


              pypCanvasDB.newColorImage.data[i] = color_to.r;
              pypCanvasDB.newColorImage.data[i + 1] = color_to.g;
              pypCanvasDB.newColorImage.data[i + 2] = color_to.b;
              pypCanvasDB.newColorImage.data[i + 3] = 255;

              if (pypCanvasDB.lumin.imageData[i + 3] === 0) pypCanvasDB.lumin.imageData[i + 3] = pypCanvasDB.computedLumins;

            }

            i += rowLength;
          }
        }

        merged.data.set(newImageData.data);

        pypCanvasDB.newImage.getContext("2d").putImageData(merged, 0, 0);
        pypCanvasDB.newImageSrc = pypCanvasDB.newImage.toDataURL();

        pypCanvasDB.newColor.getContext("2d").putImageData(pypCanvasDB.newColorImage, 0, 0);
        pypCanvasDB.newColorSrc = pypCanvasDB.newImage.toDataURL();
        pypTools.busy = false;
      }
    };
    Object.defineProperty(pypTools, 'selectedTool', {
      get: function() {
        return pypTools._selectedTool;
      },
      set: function(val) {
        if (pypTools._selectedTool == "bucket" && val != "bucket" && pypTools.bucketToleranceStarted) {
          pypTools.bucketToleranceDone();
        }
        pypUtils.resetMaskingTool();
        pypUtils.drawLines(pypCanvasDB.maskingLines, pypCanvasDB.maskingTop);
        pypTools._selectedTool = val;
      }
    })
    return pypTools
  });
}());
