(function() {
  "use strict";
  var app = angular.module('behrCore');

  function safeParse(string) {
    try {
      return JSON.parse(string);
    } catch (e) {
      console.log(e);
    }
    return false;
  }

  function PaletteFullError(message) {
    this.name = 'PaletteFullError';
    this.message = message || 'Palette is full';
    this.stack = (new Error()).stack;
  }
  PaletteFullError.prototype = Object.create(Error.prototype);
  PaletteFullError.prototype.constructor = PaletteFullError;

  function Palette(reset) {
    this.maximum = 8;
    this.selected = -1;
    if (reset) {
      this.coordinated = false;
      this.coordinationStateParams = {};
      this.unsetCoordination();
      this.colors = [];
    } else {
      this.coordinated = safeParse(window.localStorage.savedCoordinated) || false;
      this.coordinationStateParams = safeParse(window.localStorage.savedCoordinationStateParams) || {};
      if (!this.coordinated) this.unsetCoordination();
      this.colors = safeParse(window.localStorage.savedColors) || [];
    }
    Object.defineProperty(this, 'selectedColor', {
      get: function() {
        if (this.selected === -1) {
          if (this.colors.length === 0) return null;
          return this.colors[0];
        }
        return this.colors[this.selected];
      }
    });
  }
  Palette.prototype.isFull = function() {
    return this.colors.length >= this.maximum;
  };
  Palette.prototype.save = function() {
    window.localStorage.savedColors = JSON.stringify(this.colors);
    window.localStorage.savedCoordinationStateParams = JSON.stringify(this.coordinationStateParams);
    window.localStorage.savedCoordinated = JSON.stringify(this.coordinated);
  };
  Palette.prototype.unsetCoordination = function() {
    this.coordinated = false;
    this.coordinationStateParams = {};
  };
  Palette.prototype.setColors = function(colors, coordinated, coordinationStateParams) {
    if (colors.length >= this.maximum) throw new Error("Too many colors");
    this.colors.length = 0;
    this.colors = colors.slice(0); // copy the input array
    this.coordinated = coordinated;
    this.coordinationStateParams = coordinationStateParams;
    if (this.selected > this.colors.length) {
      this.selected = this.colors.length - 1;
    }
    this.save();
    return true;
  };
  Palette.prototype.add = function(color) {
    if (this.colors.length >= this.maximum) throw new PaletteFullError();
    if (this.contains(color)) throw new Error("Palette contains this color already.");
    if (!color) throw new Error("Color is false-y.");
    this.colors.push(color);
    this.unsetCoordination();
    this.save();
    return true;
  };
  Palette.prototype.remove = function(color) {
    var colorIndex = this.indexOf(color);
    if (colorIndex < 0) throw new Error("Palette does not contain this color");
    this.colors.splice(colorIndex, 1);
    if (this.selected >= this.colors.length) this.selected = this.colors.length - 1;
    this.unsetCoordination();
    this.save();
    return true;
  };
  Palette.prototype.replace = function(color, index) {
    if (this.contains(color)) throw new Error("Palette contains this color already.");
    this.colors[index] = color;
    this.unsetCoordination();
    this.save();
    return true;
  };
  Palette.prototype.indexOf = function(searchColor) {
    return this.colors.findIndex((color) => searchColor.id == color.id);
  };
  Palette.prototype.contains = function(searchColor) {
    return this.indexOf(searchColor) > -1;
  };
  Palette.prototype.getLegacyColors = function() {
    var colors = [];
    colors = this.colors.map((color) => color.id)
    for(var i = colors.length; i < 8; i++) {
      colors[i] = null;
    }
    return colors;
  };
  app.factory('paletteService', function($rootScope, $window) {
    var paletteService = {}
    paletteService.palette = new Palette();
    paletteService.reset = function() {
      paletteService.palette = new Palette(true);
    }
    paletteService.reload = function() {
      paletteService.palette = new Palette();
    }
    paletteService.oneClickMode = false;
    return paletteService;
  });
})();
