(function () {
  "use strict";
  var app = angular.module('behrCore');
  app.factory('mobileSwapService', function ($q) {
    var mobileSwapService= {
      swapMode: false,
      swapInColor: '',
      deferred: null,
      start(color) {
        mobileSwapService.swapMode = true;
        mobileSwapService.swapInColor = color;
        mobileSwapService.deferred = $q.defer();
        return mobileSwapService.deferred.promise;
      },
      resolve() {
        mobileSwapService.swapMode = false;
        mobileSwapService.deferred.resolve();
        mobileSwapService.deferred = null;
      },
      reject() {
        mobileSwapService.swapMode = false;
        mobileSwapService.deferred.reject();
        mobileSwapService.deferred = null;
      }
    }
    return mobileSwapService;
  });
} ());
