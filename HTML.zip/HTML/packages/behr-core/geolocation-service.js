(function () {
  'use strict';

  const app = angular.module('behrCore');

  app.factory('GeolocationService', GeolocationService);

  function GeolocationService($http, $q) {
    const _ = this;

    const ipServiceEndpoint = '/mainService/services/getIpAddress';
    const ipServiceFallbackEndpoint = 'https://api.ipify.org?format=json';
    const geolocationServiceEndpoint = '/geolocationService/json/getGeolocationCityDB';

    return {
      getGeolocationData: getGeolocationData
    };


    // @function getIpAddress
    // @returns
      // {ip: [String]}
    function getIpAddress() {
      return $http.get(ipServiceEndpoint).then(function (response) {
        let ipAddress = '';

        try {
          if (response.data.indexOf(',') !== -1) {
            ipAddress = response.data.split(',')[0];
          } else {
            ipAddress = response.data;
          }
        } catch (err) {
          // do nothing
        }

        return ipAddress;
      }).then(function (ipAddress) {
        if (!ipAddress || ipAddress == 1) {
          return $http.get(ipServiceFallbackEndpoint).then(function (response) {
            return response.data;
          });
        } else {
          return {ip: ipAddress};
        }
      }).catch(function (err) {
        // do nothing
      });
    }

    // @function getGeolcationData
    // @returns
    /*
      {
        city: [String]
        country: [String]
        countryIsoCode: [String]
        latitude: [Lat]
        longitude: [Long]
        postalCode: [String]
        state: [String]
        stateIsoCode: [String]
      }
    */
    function getGeolocationData() {
      let deferred = $q.defer();

      if (navigator && navigator.geolocation) {
        let geolocationOpts = {
          maximumAge: 5 * 60 * 1000, // 5 mins
          timeout: 10 * 1000 // 10 secs
        };

        navigator.geolocation.getCurrentPosition(function (position) {
          try {
            if (typeof google === 'undefined' || google.unauthorized) throw 'Google API unavailable';

            let point = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
            if (!point) throw 'cannot create point';
            let geocoder = new google.maps.Geocoder();
            if (!geocoder) throw 'cannot create geocoder';

            geocoder.geocode({
              latLng: point
            }, function (res, status) {
              switch (status) {
                case google.maps.GeocoderStatus.OK:
                  let result = formatGoogleResponse(res);
                  if (!result) throw 'Bad response';
                  result.latitude = position.coords.latitude;
                  result.longitude = position.coords.longitude;
                  deferred.resolve(result);
                break;

                default:
                  throw status;
              }
            });
          } catch (err) {
            fallback();
          }
        }, function (err) {
          fallback();
        }, geolocationOpts);
      } else {
        fallback();
      }

      function fallback() {
        getIpAddress().then(function (ipAddress) {
          let data = JSON.stringify({ipAddress: ipAddress.ip});

          $http.post(geolocationServiceEndpoint, data).then(function (response) {
            try {
              deferred.resolve(response.data.geolocationModel);
            } catch (err) {
              deferred.reject(err);
            }
          }).catch(function (err) {
            deferred.reject(err);
          });
        }).catch(function (err) {
          deferred.reject(err);
        });
      }

      return deferred.promise;
    }

    function formatGoogleResponse(response) {
      if (response.length < 1) return false;
      
      let result = {
        city: null,
        country: null,
        countryIsoCode: null,
        latitude: null,
        longitude: null,
        postalCode: null,
        state: null,
        stateIsoCode: null,
      };

      const addressObj = response[0];
      
      addressObj.address_components.forEach(comp => {
        switch (comp.types[0]) {
          case "postal_code":
            result.postalCode = comp.long_name;
          break;
          
          case "locality":
            result.city = comp.long_name;
          break;
          
          case "administrative_area_level_1":
            result.state = comp.long_name;
            result.stateIsoCode = comp.short_name;
          break;
          
          case "country":
            result.country = comp.long_name;
            result.countryIsoCode = comp.short_name;
          break;
          
          default:
        }
      });
      
      return result;
    }
  }
})();
