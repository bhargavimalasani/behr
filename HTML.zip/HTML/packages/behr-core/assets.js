(function() {
  "use strict";
  var app = angular.module('behrCore');
  var host = location.host;
  app.factory('$assets', function() {
    // new asset locations
    // /binaries/content/assets/behrdotcomrefresh/consumer/colorsmart/
    //    ../images
    //    ../css
    //    ../js
    let hippoRootLocation = '/binaries/content/assets/behrdotcomrefresh';
    let hippoAssetLocation = '/consumer/colorsmart/';

    if (host.indexOf('local') > -1 || host.indexOf('192.168') > -1) return '/assets/';
    if (host.indexOf('behr.cl') > -1) return hippoRootLocation + '/behrchile' + hippoAssetLocation;
    if (host.indexOf('behrpaint.com.mx') > -1) return hippoRootLocation + '/behrmexico' + hippoAssetLocation;
    return hippoRootLocation + hippoAssetLocation;
  });
}());
