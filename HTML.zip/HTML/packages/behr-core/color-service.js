(function () {
  "use strict";
  var app = angular.module('behrCore');
  /*
  {
    name: 'Red'
    groups: [
      [ // chipset
        "comma,separated,string,row",
        "comma,separated,string,row",
        ...
      ],
      ...
    ]
  }
  */
  function splitFamilyChipsets(family) {
    if (family && family.hasOwnProperty('groups')) {
      family.groups = family.groups.map((chipset) => {
        return chipset.map((row) => row.split(','));
      })
    }
    return family;
  }
  /*
  {
    name: 'Decorator 2017',
    group: "comma,separated,string,chipset"
  }
  */
  function splitChipsetGroup(chipset) {
    if (chipset.hasOwnProperty('group') && typeof chipset.group == "string") {
      chipset.group = chipset.group.split(',');
    }
    return chipset;
  }
  function splitObjectChipsets(collection){
    Object.keys(collection).forEach(function(group) {
        if (Array.isArray(collection[group])) {
          collection[group]=collection[group].map(splitChipsetGroup);
        }
        else {
          collection[group] = splitChipsetGroup(collection[group]);
        }
    });
    return collection;
  }
  function createCollectionsJson(transformers, families, marquee, decorators, popular){
    var collectionsJson = {};
    if(families){
      collectionsJson.families = transformers.familyCollection(families.map(splitFamilyChipsets));
    }
    if(marquee){
      collectionsJson.marquee = {};
      if(marquee.marqueecollection){
        collectionsJson.marquee.marqueeCollection = transformers.marqueeCollection(marquee.marqueecollection.map(splitChipsetGroup));
      }
      if(marquee.oneCoatFamilies){
        collectionsJson.marquee.marqueeOneCoat = transformers.familyCollection(marquee.oneCoatFamilies.map(splitFamilyChipsets));
      }
      if (marquee.oneCoatFamiliesExt) {
        collectionsJson.marquee.marqueeOneCoatExt = transformers.familyCollection(marquee.oneCoatFamiliesExt.map(splitFamilyChipsets));
      }
    }
    if (decorators) {
      collectionsJson.decorators = transformers.transformDecorators(splitObjectChipsets(decorators));
    }
    if(popular){
      collectionsJson.popular = transformers.popular(splitObjectChipsets(transformers.fixTimeless(popular)));
    }
    return collectionsJson;
  }

  app.factory('colorService', function ($window, $http, $serviceURL, $q, $assets, $interpolate, $sce, $state, loginService, localeService, $uibModal, behrTranslate) {
    var transformers = {
      flattenOneCoatColors(oneCoatFamilies) {
        var allOneCoatColors = {};
        oneCoatFamilies.forEach((family) => {
          family.groups.forEach((chipset) => {
            chipset.forEach((row) => {
              row.forEach((colorId) => {
                allOneCoatColors[colorId] = true;
              });
            })
          })
        })
        return allOneCoatColors;
      },
      familyCollectionColorLabels(collection) {
		// En || Es || Fr
        var dataset = collection.map((family, index) => {
          if (family.name == 'White' || family.name == 'Blanco' || family.name == 'Blanc') family.color = "#F5F4E9";
          if (family.name == 'Gray' || family.name == 'Gris') family.color = "#BBB9B5";
          if (family.name == 'Brown' || family.name == 'Café' || family.name == 'Brun') family.color = "#C2A89F";
          if (family.name == 'Red' || family.name == 'Rojo' || family.name == 'Rouge') family.color = "#BC3940";
          if (family.name == 'Orange' || family.name == 'Naranja') family.color = "#F68221";
          if (family.name == 'Yellow' || family.name == 'Amarillo' || family.name == 'Jaune') family.color = "#FDD63C";
          if (family.name == 'Green' || family.name == 'Verde' || family.name == 'Vert') family.color = "#58A93E";
          if (family.name == 'Blue' || family.name == 'Azul' || family.name == 'Bleu') family.color = "#3497CD";
          if (family.name == 'Purple' || family.name == 'Púrpura' || family.name == 'Mauve') family.color = "#8977AB";

          //correct the color names to Spanish if necessary

          if (localeService.getLocale() == ('mx') || localeService.getLocale() == ('cl')) {
            if (family.name == 'White') family.name = 'Blanco';
            if (family.name == 'Gray') family.name = 'Gris';
            if (family.name == 'Brown') family.name = 'Café';
            if (family.name == 'Red') family.name = 'Rojo';
            if (family.name == 'Orange') family.name = 'Naranja';
            if (family.name == 'Yellow') family.name = 'Amarillo';
            if (family.name == 'Green') family.name = 'Verde';
            if (family.name == 'Blue') family.name = 'Azul';
            if (family.name == 'Purple') family.name = 'Púrpura';
          }

          return family;
        })
        return dataset;
      },
      familyCollection(collection) {
        var dataset = transformers.familyCollectionColorLabels(collection);
        var neutrals = dataset.slice(-3);
        var colors = dataset.slice(0, -3);
        return neutrals.reverse().concat(colors);
      },
      fixTimeless(superCollection) {
        if(superCollection.hasOwnProperty('timeless')){
          superCollection.timeless = [superCollection.timeless];
        }
        return superCollection;
      },
      transformDecorators(collection) {
        if (collection.hasOwnProperty('springsummer')) {
          collection.hdccolorbook = collection.springsummer;  //change springsummer to hdccolorbook
          delete collection.springsummer;
          collection.hdccolorbook[0].name = 'HDC Color Book';  //change Spring name to HDC Color Book
          collection.hdccolorbook.splice(1,2);  //remove Summer (no data in group [])
        }
        return collection;
      },
      popular(superCollection) {
        if(superCollection.hasOwnProperty('trends2017')) {
          superCollection.trends2017 = transformers.colorTrends2017(superCollection.trends2017);
        }
        if(superCollection.hasOwnProperty('trends2018')) {
          superCollection.trends2018 = transformers.colorTrends2018(superCollection.trends2018);
        }
        if(superCollection.hasOwnProperty('hue')) {
          superCollection.hue.map((family) => {
            var rowlength = Math.ceil(family.group.length / 3);
            // turns 1-d array into 2-d array
            family.groups = [[]];
            family.groups[0][0] = family.group.slice(0, rowlength);
            family.groups[0][1] = family.group.slice(rowlength, rowlength * 2);
            family.groups[0][2] = family.group.slice(rowlength * 2, family.group.length);
            delete family.group;
          })
          superCollection.hue = transformers.familyCollectionColorLabels(superCollection.hue);
        }
        if(superCollection.hasOwnProperty('interior')) {
          var dataset = superCollection.interior.map((interior, index) => {
            if (interior.name == "Oficina") interior.name = "Estudio";
          });
        }
        return superCollection;
      },
      colorTrends2017(collection) {
        collection.splice(3, 1); // remove "Back Ground"
        return collection;
      },
      colorTrends2018(collection) {
        if (Array.isArray(collection)) collection = collection[0];
        return collection;
      },
      marqueeCollection(collection) {
        collection = collection.map((chipset) => {
          chipset.mobileTitle = true;
          return chipset;
        })
        return collection;
      }
    }
    var colorService = {
      savedBrowserState: {},
      _colorDictionary: $window.loadColorData(),
      collections: createCollectionsJson(transformers, $window._families, $window._marquee, $window._decorators, $window._popular),
      navigationLocale: { //choose which nav elements to show. Locales: us, cl, mx, cn, ca */
        cl: {
          popular: {
            colors: true,
            trends2017: false,
            trends2018: false,
            '2019-color-trends': true,
            timeless: false,
            interior: true,
            exterior: false
          },
          'all-colors': true,
          marquee: false,
          decorators: false
        },
        mx: {
          popular: {
            colors: true,
            trends2017: false,
            trends2018: false,
            '2019-color-trends': true,
            timeless: false,
            interior: true,
            exterior: false
          },
          'all-colors': true,
          marquee: false,
          decorators: false
        },
        us: {
          popular: {
            colors: true,
            trends2017: false,
            trends2018: false,
            '2019-color-trends': true,
            timeless: true,
            interior: true,
            exterior: true
          },
          'all-colors': true,
          marquee: {
            collection: true,
            colors: true
          },
          decorators: {
            'spring-summer': true,
            'color-book': true,
            home: true
          }
        },
        cn: {
          popular: {
            colors: true,
            trends2017: false,
            trends2018: false,
            '2019-color-trends': true,
            timeless: false,
            interior: true,
            exterior: false
          },
          'all-colors': true,
          marquee: false,
          decorators: {
            home: true
          }
        },
        ca: {
          popular: {
            colors: true,
            trends2017: false,
            trends2018: false,
            '2019-color-trends': true,
            timeless: true,
            interior: true,
            exterior: false
          },
          'all-colors': true,
          marquee: {
            collection: true,
            colors: true
          },
          decorators: {
            'spring-summer': true,
            'color-book': true,
            home: true
          }
        }
      },
      isOneCoatColor(id) {
        if(colorService.allOneCoatColors && localeService.getLocale() !== ('mx') && localeService.getLocale() !== ('cl') && localeService.getLocale() !== ('cn')){
          return colorService.allOneCoatColors.hasOwnProperty(colorService.normalizeId(id));
        } else {
          return false;
        }
      },
      isOneCoatColorExt(id) {
        if (colorService.allOneCoatColorsExt && localeService.getLocale() !== ('mx') && localeService.getLocale() !== ('cl') && localeService.getLocale() !== ('cn')) {
          return colorService.allOneCoatColorsExt.hasOwnProperty(colorService.normalizeId(id));
        } else {
          return false;
        }
      },
      normalizeId(id) {
        if (!id) return null;
        id = id.trim().replace("_", "-");
        return id;
      },
      getColor(id) {
        if (!id) return null;
        id = colorService.normalizeId(id);
        if (colorService._colorDictionary.hasOwnProperty("HDC-" + id)) return colorService._colorDictionary["HDC-" + id];
        if (colorService._colorDictionary.hasOwnProperty(id)) return colorService._colorDictionary[id];
        return null;
      },
      getCoordinatedColors(color1, color2) {
        var url = '/mainService/services/colornx/fourcolor/' + color1.id;
        if (color2) {
          url += '/' + color2.id;
        }
        return $http({
            method: 'GET',
            url: url
          })
          .then(function (response) {
            var idArray = response.data.fourcolor.split(',');
            var colorArray = idArray.map(colorId => colorService.getColor(colorId));
            var coordinatedColors = [];
            while (colorArray.length > 1) {
              coordinatedColors.push(colorArray.splice(0, 4));
            }
            return coordinatedColors;
          })
      },
      getSimilar(color) {
        return $http({
            method: 'GET',
            url: '/mainService/services/colornx/similar/' + color.id
          })
          .then(function (response) {
            var idArray = response.data.similar.split(',');
            var colorArray = idArray.map(colorId => colorService.getColor(colorId));
            return colorArray.filter((color) => {
              if (color) return true;
              return false;
            })
          })
      },
      saveBrowserState() {
        if ($state.params.collection) {
          if ($state.params.superCollection) colorService.savedBrowserState.superCollection = $state.params.superCollection;
          else delete colorService.savedBrowserState.superCollection;
          colorService.savedBrowserState.collection = $state.params.collection;
          colorService.savedBrowserState.family = $state.params.family;
          colorService.savedBrowserState.chipset = $state.params.chipset;
        }
      },
      returnToBrowserState() {
        if (typeof colorService.savedBrowserState.superCollection !== "undefined") {
          if (typeof colorService.savedBrowserState.family !== "undefined") {
            $state.go('index.super-collection-family', colorService.savedBrowserState);
          } else if (typeof colorService.savedBrowserState.chipset !== "undefined") {
            $state.go('index.super-collection.chipset', colorService.savedBrowserState);
          } else if (typeof colorService.savedBrowserState.collection !== "undefined") {
            $state.go('index.super-collection', colorService.savedBrowserState);
          } else {
            $state.go('index');
          }
        } else {
          if (typeof colorService.savedBrowserState.family !== "undefined") {
            $state.go('index.collection-family', colorService.savedBrowserState);
          } else if (typeof colorService.savedBrowserState.chipset !== "undefined") {
            $state.go('index.collection.chipset', colorService.savedBrowserState);
          } else if (typeof colorService.savedBrowserState.collection !== "undefined") {
            $state.go('index.collection', colorService.savedBrowserState);
          } else {
            $state.go('index');
          }
        }
      },
      saveColor(colorId) {
        var deferred = $q.defer();

        function _saveColor(colorId) {
          var modalInstance = $uibModal.open({
            controller: 'DefaultModalCtrl',
            controllerAs: '$ctrl',
            templateUrl: '/app/components/modals/loading-modal.html',
            backdropClass: 'backdrop-white',
            backdrop: 'static',
            appendTo: angular.element(document.getElementById("cs-mobile-app"))
          });
          $http.post($serviceURL + '/usercolor/nextgen/addusercolor', JSON.stringify({
              "colors": [colorId],
              "userId": loginService.getUser().userId
            }))
            .then((response) => {
              modalInstance.close();
              deferred.resolve();
              modalInstance = $uibModal.open({
                controller: 'DataModalCtrl',
                controllerAs: '$ctrl',
                templateUrl: '/app/components/modals/success-modal.html',
                backdropClass: 'backdrop-white',
                appendTo: angular.element(document.getElementById("cs-mobile-app")),
                resolve: {
                  data: () => {
                    return {
                      message: behrTranslate("Your color was saved.")
                    }
                  }
                }
              });
            })
            .catch((error) => {
              modalInstance.close();
              modalInstance = $uibModal.open({
                controller: 'DataModalCtrl',
                controllerAs: '$ctrl',
                templateUrl: '/app/components/modals/error-modal.html',
                backdropClass: 'backdrop-white',
                appendTo: angular.element(document.getElementById("cs-mobile-app")),
                resolve: {
                  data: () => {
                    return {
                      error: behrTranslate("Sorry, there was a problem saving your colors.")
                    }
                  }
                }
              });
              deferred.reject(behrTranslate("There was a problem saving your colors."));
            });
        }

        if (!loginService.loggedIn) {
          var modalInstance = $uibModal.open({
            controller: 'DataModalCtrl',
            controllerAs: '$ctrl',
            templateUrl: '/app/components/modals/login-modal.html',
            backdropClass: 'backdrop-white',
            backdrop: true,
            appendTo: angular.element('#cs-mobile-app'),
            resolve: {
              data: {
                action: 'saveColor'
              }
            }
          });
          modalInstance.result.then(() => {
            _saveColor(colorId);
          }).catch(() => {
            deferred.reject();
          })
        } else {
          _saveColor(colorId);
        }
        return deferred.promise;
      },
      getSavedColors() {
        var modalInstance = $uibModal.open({
          controller: 'DefaultModalCtrl',
          controllerAs: '$ctrl',
          templateUrl: '/app/components/modals/pyp-images-loading-modal.html',
          backdropClass: 'backdrop-white',
          backdrop: 'static',
          appendTo: angular.element(document.getElementById("cs-mobile-app"))
        });
        if (!loginService.loggedIn) {
          var deferred = $q.defer();
          deferred.reject(behrTranslate("You must log in"));
          return deferred.promise;
        }
        return $http.get($serviceURL + '/usercolor/nextgen/getusercolors?userid=' + loginService.getUser().userId + '&isoldcolorontop=true')
          .then((response) => {
            modalInstance.close();
            var deferred = $q.defer();
            deferred.resolve(response.data.userColorList.map((color) => color.colorId));
            return deferred.promise;
          })
          .catch((error) => {
            modalInstance.close();
            modalInstance = $uibModal.open({
              controller: 'DataModalCtrl',
              controllerAs: '$ctrl',
              templateUrl: '/app/components/modals/error-modal.html',
              backdropClass: 'backdrop-white',
              appendTo: angular.element(document.getElementById("cs-mobile-app")),
              resolve: {
                data: () => {
                  return {
                    error: behrTranslate("Sorry, there was a problem retrieving your colors.")
                  }
                }
              }
            });
          })
      }
    };
    if(colorService.collections.hasOwnProperty('marquee') && colorService.collections.marquee.hasOwnProperty('marqueeOneCoat')){
      colorService.allOneCoatColors = transformers.flattenOneCoatColors(colorService.collections.marquee.marqueeOneCoat);
    }
    if (colorService.collections.hasOwnProperty('marquee') && colorService.collections.marquee.hasOwnProperty('marqueeOneCoatExt')) {
      colorService.allOneCoatColorsExt = transformers.flattenOneCoatColors(colorService.collections.marquee.marqueeOneCoatExt);
    }
    colorService.nullColor = colorService.getColor("750C-3") || colorService.getColor("52");
    return colorService;
  })
}());
