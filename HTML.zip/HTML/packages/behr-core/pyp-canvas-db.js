(function() {
  "use strict";
  var app = angular.module('behrCore');

  app.factory('pypCanvasDB', function(pypUtils, $q, $timeout, $serviceURL, $http, behrTranslate) {

    function createCanvas(id, width, height) {
      var canvas = document.createElement('canvas');
      canvas.width = width || pypUtils.W;
      canvas.height = height || pypUtils.H;
      if (id) canvas.id = id;
      return canvas;
    }
    var maxTolerance = 50;
    var pypCanvasDB = {
      imageLoaded: false,
      createCanvas: createCanvas,
      maxTolerance: maxTolerance,
      // The magic wand tool uses this array to create increasingly larger tolerances, it changes whenever the bucket is used
      // it supports the tolerance slider by being a pre-cached bitmap of the selected area at each tolerance level
      selectionData: new Array(maxTolerance),
      foundColors: [],
      foundLumins: [],
      computedLumins: 0, // @todo what the heck is this??? is it the average luminosity of the image when superMap isn't avail?
      colorWeights: [],
      maskingLines: [],
      // `predrawing` is the original image
      predrawing: createCanvas('predrawing'),
      // `thumbnail` is self explanatory
      thumbnail: createCanvas('thumbnail', pypUtils.W / 2, pypUtils.H / 2),
      // `segment` stores data about the overall colors and magic-wandable areas of the image
      segment: createCanvas('segment'), // #segmentCanvas, var segmentCanvas
      // `drawing` is the mutable canvas used to display permanent changes in color
      drawing: createCanvas('drawing'), // #drawing, var canMain / var context
      // `newImage` is the mutable canvas used to display the lumin-adjusted color about to be painted to the image by the bucket
      newImage: createCanvas('newImage'), // #newImage, var newImageCanvas / newImageCanvasContext
      // `newColor` is the mutable canvas used in the background to temporarily store the new colored area without luminosity, similar to `bucketColor`
      newColor: createCanvas('newColor'), // #colorImage, var newColorCanvas / newColorCanvasContext
      // `newImageOverlay` is a mutable overlay canvas shown instead of newImage when adjusting the slider for the paint bucket
      newImageOverlay: createCanvas('newImageOverlay'), // #overlaySpread
      // `newColorImage` is `ImageData` from `newColor` used in weird edge cases
      // @todo its possible we don't need this anymore, so figure out if we can refactor it out in favor of something else
      newColorImage: null, // colorCanvasImage
      // `bucketColor` is a mutable canvas that stores the state of colored areas on the image
      bucketColor: createCanvas('bucketColor'), // #canColor, var colorCanvasContext
      // `bucketEdge` is the primary canvas/mask used to determine where the bucket can paint.
      // Masking lines create blue lines on this canvas
      // Masking polygons paint areas black.
      // The intensity of the lightness determines the intensity of the edge.
      // A more intense edge requires more tolerance from the bucket tool
      bucketEdge: createCanvas('bucketEdge'), // #canEdge, var canEdge/canMask/context2
      // `originalEdge` is the originally processed `bucketEdge` canvas without masking tool modifications
      // used for `removeAllMasking()` functionality
      originalEdge: createCanvas('originalEdge'),
      // `maskingTop` is a mutable overlay canvas displayed in `<pyp>` it shows all drawn masking lines
      maskingTop: createCanvas('maskingTop'),
      // `smooth`, `grayscale`, `sobel`, `canny`, `dilatation`, and `erosion` are background/debug canvases for edge processing
      // they are created with createEdgeAndCanny()
      smooth: createCanvas(),
      grayscale: createCanvas(),
      sobel: createCanvas(),
      canny: createCanvas('canny'),
      dilatation: createCanvas(),
      erosion: createCanvas(),
      // `undo` stores information about the undo state
      // only 1 undo state is currently allowed due to the rudimentary storage of imagedata
      undo: {
        // `undo.drawing` is the last state of `drawing`
        drawing: createCanvas('drawing'),
        // `undo.bucketColor` is the last state of `bucketColor`
        bucketColor: createCanvas('bucketColor'),
        // `undo.maskingTop` is the last state of `maskingTop`
        maskingTop: createCanvas('maskingTop'),
        // `undo.bucketEdge` is the last state of `bucketEdge`
        bucketEdge: createCanvas('bucketEdge'),
        // `undo.maskingLines` is the last state of `maskingLines`
        maskingLines: [],
        // `undo.enabled` tells `<pyp>` whether an undo state is available
        enabled: false,
        // `undo.lastAttempt` is the javascript timestamp when the last `undo.save()` attempt was made
        // tracking this allows us to avoid trashing when touchmove/mousemove events fire `undo.save()`
        lastAttempt: 0,
        save() {
          var cachedLastAttempt = pypCanvasDB.undo.lastAttempt;
          pypCanvasDB.undo.lastAttempt = Date.now();
          if (Date.now() - cachedLastAttempt < 500) {
            return;
          }
          // Save current states of main canvases to undo canvases
          pypCanvasDB.undo.drawing.getContext("2d").drawImage(pypCanvasDB.drawing, 0, 0);
          pypCanvasDB.undo.bucketColor.getContext("2d").putImageData(pypCanvasDB.bucketColor.getContext("2d").getImageData(0, 0, pypUtils.W, pypUtils.H), 0, 0);
          pypCanvasDB.undo.maskingTop.getContext("2d").putImageData(pypCanvasDB.maskingTop.getContext("2d").getImageData(0, 0, pypUtils.W, pypUtils.H), 0, 0);
          pypCanvasDB.undo.bucketEdge.getContext("2d").putImageData(pypCanvasDB.bucketEdge.getContext("2d").getImageData(0, 0, pypUtils.W, pypUtils.H), 0, 0);

          pypCanvasDB.undo.maskingLines = pypCanvasDB.maskingLines.slice();
          pypCanvasDB.undo.enabled = true;
        },
        // `undo.undo()` restores the last state of the canvas
        undo() {
          if (!pypCanvasDB.undo.enabled) return;
          // Send undo states to main canvases
          pypCanvasDB.drawing.getContext("2d").drawImage(pypCanvasDB.undo.drawing, 0, 0);
          pypCanvasDB.bucketColor.getContext("2d").putImageData(pypCanvasDB.undo.bucketColor.getContext("2d").getImageData(0, 0, pypUtils.W, pypUtils.H), 0, 0);
          pypCanvasDB.maskingTop.getContext("2d").putImageData(pypCanvasDB.undo.maskingTop.getContext("2d").getImageData(0, 0, pypUtils.W, pypUtils.H), 0, 0);
          pypCanvasDB.bucketEdge.getContext("2d").putImageData(pypCanvasDB.undo.bucketEdge.getContext("2d").getImageData(0, 0, pypUtils.W, pypUtils.H), 0, 0);

          pypCanvasDB.maskingLines = pypCanvasDB.undo.maskingLines.slice();
          // Clear paint paint slider canvas and menu
          pypCanvasDB.newImage.getContext("2d").clearRect(0, 0, pypUtils.W, pypUtils.H);
          pypCanvasDB.newColor.getContext("2d").clearRect(0, 0, pypUtils.W, pypUtils.H);

          // Clear undo canvases
          pypCanvasDB.undo.drawing.getContext("2d").clearRect(0, 0, pypUtils.W, pypUtils.H);
          pypCanvasDB.undo.bucketColor.getContext("2d").clearRect(0, 0, pypUtils.W, pypUtils.H);
          pypCanvasDB.undo.maskingTop.getContext("2d").clearRect(0, 0, pypUtils.W, pypUtils.H);
          pypCanvasDB.undo.bucketEdge.getContext("2d").clearRect(0, 0, pypUtils.W, pypUtils.H);

          pypCanvasDB.undo.enabled = false;
          pypCanvasDB.saveSessionState();
        }
      },
      // @todo can we explain the difference between lumin.map and lumin.superMap?
      // can we explain what the .imageData and .canvas properties are for?
      lumin: {
        superMap: null, //superLuminMap
        map: null, //luminMap
        canvas: createCanvas(), // cLuminDataCanvas
        imageData: null,
        build() {
          pypCanvasDB.lumin.map = pypCanvasDB.predrawingContext.createImageData(pypUtils.W, pypUtils.H);
          var contextData = pypCanvasDB.predrawingContext.getImageData(0, 0, pypUtils.W, pypUtils.H);

          for (var ix = 0; ix < pypUtils.W; ix++) {
            for (var iy = 0; iy < pypUtils.H; iy++) {
              var i = ((iy * (pypUtils.W * 4)) + (ix * 4));
              var fromColorLCH = ColorUtilities.convertRGBToLAB(contextData.data[i], contextData.data[i + 1], contextData.data[i + 2]);
              pypCanvasDB.lumin.map.data[i] = fromColorLCH[0];
            }
          }
          pypCanvasDB.lumin.canvas.width = pypUtils.W;
          pypCanvasDB.lumin.canvas.height = pypUtils.H;
          pypCanvasDB.lumin.imageData = pypCanvasDB.lumin.canvas.getContext('2d').createImageData(pypUtils.W, pypUtils.H).data;
        },
        buildSuper() {
          pypCanvasDB.lumin.superMap = pypCanvasDB.drawingContext.createImageData(pypUtils.W, pypUtils.H);
          var imageData = pypCanvasDB.segment.getContext("2d").getImageData(0, 0, pypUtils.W, pypUtils.H).data;
          var widthRGBA = pypUtils.W * 4;

          for (var ix = 0; ix < pypUtils.W; ix++) {
            for (var iy = 0; iy < pypUtils.H; iy++) {
              var i = ((iy * (widthRGBA)) + (ix * 4));
              var fromSegLCH = ColorUtilities.convertRGBToLAB(imageData[i], imageData[i + 1], imageData[i + 2]);
              pypCanvasDB.lumin.superMap[i] = fromSegLCH[0];
            }
          }
          return pypCanvasDB.lumin.superMap;
        }
      },
      clearAllCanvases() {
        var canvases = [
          "predrawing",
          "thumbnail",
          "segment",
          "drawing",
          "newImage",
          "newColor",
          "bucketColor",
          "bucketEdge",
          "maskingTop",
          "smooth",
          "grayscale",
          "sobel",
          "canny",
          "dilatation",
          "erosion"
        ];
        canvases.forEach((canvasKey) => {
          pypCanvasDB[canvasKey].getContext("2d").clearRect(0, 0, pypCanvasDB[canvasKey].width, pypCanvasDB[canvasKey].height);
        })
      },
      getLegacyThumbnail() {
        var legacyThumbnail = pypCanvasDB.createCanvas();
        legacyThumbnail.width = 175;
        legacyThumbnail.height = 125;
        legacyThumbnail.getContext("2d").drawImage(pypCanvasDB.thumbnail, 0, 0, 175, 125);
        return legacyThumbnail;
      },
      loadProjectData(project) {
        pypCanvasDB.clearAllCanvases();
        pypUtils.resetMasking(pypCanvasDB);
        pypUtils.resetMaskingTool();

        var getUserSavedImageCanvasURL = $serviceURL + '/project/nextgen/getprojectbinary?projectid=' + project.projectId + '&keys=all';
        var pypData = {};
        pypData.foundColors = JSON.parse(project.jsonData.NextGenProjectVO.foundColors);
        pypData.foundLumins = JSON.parse(project.jsonData.NextGenProjectVO.foundLumins);
        pypData.maskingLines = JSON.parse(project.jsonData.NextGenProjectVO.maskingLines);

        return $http.get(getUserSavedImageCanvasURL, {
            headers: {
              'Content-Type': 'application/json'
            }
          })
          .then((response) => {
            response = response.data;
            if (response.hasOwnProperty('status') && response.status === "ERROR") {
              var deferredError = $q.defer();
              deferredError.reject(behrTranslate("There was a problem loading the project images"));
              return deferredError.promise;
            }
            pypData.mainImage = response.mainImage;
            pypData.segmentCanvas = response.segmentCanvas;
            pypData.colorCanvas = response.colorCanvas;
            pypData.drawingCanvas = response.drawingCanvas;
            pypData.thumbnail = response.thumbnail;
            return rebuildProject(pypData);
          });
      },
      loadSavedImage(index) {
        pypCanvasDB.clearAllCanvases();
        pypUtils.resetMasking(pypCanvasDB);
        pypUtils.resetMaskingTool();

        var pypData = {};
        var sessionImageObject = JSON.parse(localStorage.getItem("userSessionImage" + index));
        pypData.thumbnail = sessionImageObject.thumbnail;
        pypData.foundColors = sessionImageObject.foundColors;
        pypData.foundLumins = sessionImageObject.foundLumins;
        pypData.maskingLines = [];
        pypData.mainImage = sessionImageObject.mainImage;
        pypData.drawingCanvas = sessionImageObject.mainImage;
        pypData.segmentCanvas = sessionImageObject.segmentCanvas;

        pypCanvasDB.imageLoaded = true;

        return rebuildProject(pypData);
      },
      loadSessionState() {
        // masking lines
        pypUtils.resetMasking(pypCanvasDB);
        var sessionMaskingLinesLength = sessionStorage.maskingLines.length;
        if (sessionMaskingLinesLength <= 2) {
          pypCanvasDB.maskingLines = [];
        } else {
          pypCanvasDB.maskingLines = JSON.parse(sessionStorage.maskingLines);
        }
        pypUtils.drawLines(pypCanvasDB.maskingLines, pypCanvasDB.maskingTop);

        // segementation stuff
        pypCanvasDB.foundColors = JSON.parse(sessionStorage.foundColors);
        pypCanvasDB.foundLumins = JSON.parse(sessionStorage.foundLumins);
        try {
          pypCanvasDB.computedLumins = parseFloat(sessionStorage.computedLumins);
        } catch (e) {}

        function retrieveImageFromStorage(storageKey, canvasKey) {
          var deferred = $q.defer();
          var img = new Image();
          img.onload = function() {
            pypCanvasDB[canvasKey].getContext("2d").clearRect(0, 0, pypCanvasDB[canvasKey].width, pypCanvasDB[canvasKey].height);
            pypCanvasDB[canvasKey].getContext("2d").drawImage(img, 0, 0);
            deferred.resolve();
          }
          img.src = sessionStorage[storageKey];
          return deferred.promise;
        }
        var imageLoadPromises = [
          pypUtils.drawImageToCanvas(sessionStorage.predrawing, pypCanvasDB.predrawing),
          pypUtils.drawImageToCanvas(sessionStorage.drawing, pypCanvasDB.drawing),
          pypUtils.drawImageToCanvas(sessionStorage.bucketEdge, pypCanvasDB.bucketEdge),
          pypUtils.drawImageToCanvas(sessionStorage.originalEdge, pypCanvasDB.originalEdge),
          pypUtils.drawImageToCanvas(sessionStorage.bucketColor, pypCanvasDB.bucketColor),
          pypUtils.drawImageToCanvas(sessionStorage.canny, pypCanvasDB.canny),
          pypUtils.drawImageToCanvas(sessionStorage.segment, pypCanvasDB.segment),
          pypUtils.drawImageToCanvas(sessionStorage.thumbnail, pypCanvasDB.thumbnail)
        ];
        return $q.all(imageLoadPromises)
          .then(function() {
            pypCanvasDB.lumin.build();
            pypCanvasDB.lumin.buildSuper();
            pypCanvasDB.saveSessionState();
          })
      },
      saveSessionState() {
        if (typeof(Storage) === "undefined") return;
        sessionStorage.drawing = pypCanvasDB.drawing.toDataURL();
        sessionStorage.predrawing = pypCanvasDB.predrawing.toDataURL();
        sessionStorage.originalEdge = pypCanvasDB.originalEdge.toDataURL();
        sessionStorage.bucketEdge = pypCanvasDB.bucketEdge.toDataURL();
        sessionStorage.bucketColor = pypCanvasDB.bucketColor.toDataURL();
        sessionStorage.canny = pypCanvasDB.canny.toDataURL();
        sessionStorage.segment = pypCanvasDB.segment.toDataURL();
        sessionStorage.thumbnail = pypCanvasDB.thumbnail.toDataURL();
        sessionStorage.computedLumins = pypCanvasDB.computedLumins;
        sessionStorage.foundColors = JSON.stringify(pypCanvasDB.foundColors);
        sessionStorage.foundLumins = JSON.stringify(pypCanvasDB.foundLumins);
        sessionStorage.maskingLines = JSON.stringify(pypCanvasDB.maskingLines);
      },
      maxUserImages: 3, // used for saving and culling extra images
      legacyMaxUserImages: 7, // used for loading
      userImages: [],
      loadImagesFromStorage() {
        var nextObject;
        for (var x = 0; x < pypCanvasDB.legacyMaxUserImages; x++) {
          if (localStorage.hasOwnProperty('userSessionImage' + x)) {
            nextObject = JSON.parse(localStorage.getItem('userSessionImage' + x));
            pypCanvasDB.userImages.push(nextObject);
            //userHasSavedImages = true;
          } else {
            x = 7;
          }
        }
        return pypCanvasDB.userImages;
      },
      removeUserImage(index) {
        pypCanvasDB.userImages.splice(index, 1);

        // "shift" user image objects in session storage
        var x;
        for (x = 0; x < pypCanvasDB.userImages.length; x++) {
          localStorage.setItem('userSessionImage' + x, JSON.stringify(pypCanvasDB.userImages[x]));
        }
        for (x = pypCanvasDB.userImages.length; x < pypCanvasDB.legacyMaxUserImages; x++) {
          try {
            localStorage.removeItem('userSessionImage' + x);
          } catch (e) {}
        }
      },
      saveImageToStorage() {
        function cullOneImage() {
          // Remove oldest image from array and add new image
          pypCanvasDB.userImages.shift();

          // "shift" user image objects in session storage
          var x;
          for (x = pypCanvasDB.userImages.length; x < pypCanvasDB.legacyMaxUserImages; x++) {
            try {
              localStorage.removeItem('userSessionImage' + x);
            } catch (e) {}
          }
          try {
            for (x = 0; x < pypCanvasDB.userImages.length; x++) {
              localStorage.setItem('userSessionImage' + x, JSON.stringify(pypCanvasDB.userImages[x]));
            }
          }
          catch(e) {
            cullOneImage();
          }
        }

        // Make sure we can use storage
        if (typeof(Storage) === "undefined") return false;

        // Create thumbnail of image on canvas
        pypCanvasDB.thumbnail.getContext("2d").drawImage(pypCanvasDB.predrawing, 0, 0, pypUtils.W / 2, pypUtils.H / 2);

        // Create new object for uploaded image information
        var savedImageObject = {};
        // JSON.parse(JSON.stringify()) allows us to copy objects in a relatively consistent way
        savedImageObject.foundColors = JSON.parse(JSON.stringify(pypCanvasDB.foundColors));
        savedImageObject.foundLumins = JSON.parse(JSON.stringify(pypCanvasDB.foundLumins));
        savedImageObject.mainImage = pypCanvasDB.predrawing.toDataURL();
        savedImageObject.drawingCanvas = savedImageObject.mainImage;
        savedImageObject.segmentCanvas = pypCanvasDB.segment.toDataURL();
        savedImageObject.thumbnail = pypCanvasDB.thumbnail.toDataURL();


        // If amount of session images reaches more then 4, get rid of older ones
        if (pypCanvasDB.userImages.length > pypCanvasDB.maxUserImages) {
          cullOneImage();
        }
        pypCanvasDB.userImages.push(savedImageObject);
        var userImagesNextIndex = pypCanvasDB.userImages.length - 1;

        // Add new object to sessionStorage
        try {
          localStorage.setItem('userSessionImage' + userImagesNextIndex, JSON.stringify(savedImageObject));
        } catch (e) {
          console.log(e);
          cullOneImage();
          //try again
          userImagesNextIndex = pypCanvasDB.userImages.length - 1;
          localStorage.setItem('userSessionImage' + userImagesNextIndex, JSON.stringify(savedImageObject));
        }
      }
    };

    function rebuildProject(project) {
      pypCanvasDB.foundColors = project.foundColors;
      pypCanvasDB.foundLumins = project.foundLumins;
      pypCanvasDB.maskingLines = project.maskingLines;
      var imagesToDraw = [
        pypUtils.drawImageToCanvas(project.mainImage, pypCanvasDB.predrawing),
        pypUtils.drawImageToCanvas(project.drawingCanvas, pypCanvasDB.drawing),
        pypUtils.drawImageToCanvas(project.thumbnail, pypCanvasDB.thumbnail),
        pypUtils.drawImageToCanvas(project.segmentCanvas, pypCanvasDB.segment)
      ];
      if (project.hasOwnProperty('colorCanvas')) {
        imagesToDraw.push(pypUtils.drawImageToCanvas(project.colorCanvas, pypCanvasDB.bucketColor));
      }
      return $q.all(imagesToDraw)
        .then(() => {
          // Make edge and canny canvases, and main edge image
          pypUtils.createEdgeAndCanny(pypCanvasDB, undefined, true);
          pypCanvasDB.lumin.build();
          pypCanvasDB.lumin.buildSuper();

          //drawingCanvasToThumbnail(); // @todo i thought we already did this above?
          // switchFromVisualizerToPYP(); // @todo move this outside of pyp-canvas-db
          pypCanvasDB.saveSessionState();
        })
    }
    pypCanvasDB.maskingTopContext = pypCanvasDB.maskingTop.getContext("2d");
    pypCanvasDB.predrawingContext = pypCanvasDB.predrawing.getContext("2d");
    pypCanvasDB.segmentContext = pypCanvasDB.segment.getContext("2d");
    pypCanvasDB.drawingContext = pypCanvasDB.drawing.getContext("2d");
    pypCanvasDB.newImageContext = pypCanvasDB.newImage.getContext("2d");
    pypCanvasDB.newColorContext = pypCanvasDB.newColor.getContext("2d");
    pypCanvasDB.bucketColorContext = pypCanvasDB.bucketColor.getContext("2d");
    pypCanvasDB.bucketEdgeContext = pypCanvasDB.bucketEdge.getContext("2d");
    /*
    $(document.body).append(pypCanvasDB.segment);
    $(document.body).append(pypCanvasDB.predrawing);
    $(document.body).append(pypCanvasDB.drawing);
    $(document.body).append(pypCanvasDB.bucketEdge);
    $(document.body).append(pypCanvasDB.canny);
    $(document.body).append(pypCanvasDB.bucketColor);
    */
    pypCanvasDB.loadImagesFromStorage();
    return pypCanvasDB;
  });
}());
