(function() {
  "use strict";
  var app = angular.module('behrCore');

  app.factory('loginService', function($window, $http, $serviceURL, $q, behrTranslate) {
    var user;
    function safe_parse(str) {
      try {
        return JSON.parse(str);
      }
      catch(e) {
        return false;
      }
    }
    user = safe_parse(localStorage.getItem('loginService.user')) || safe_parse(sessionStorage.getItem('loginService.user')) || {};
    var loginService = {
      _setUserCookie(user, rememberLogin) {
        if (rememberLogin) {
          var date = new Date();
          date.setTime(date.getTime() + (7 * 24 * 60 * 60 * 1000)); // days
          var expires = "; expires=" + date.toGMTString();
          document.cookie = "mybehr_user=" + user.userName + expires + "; path=/";
          document.cookie = "mybehr_rem=yes; path=/";
          localStorage.setItem('loginService.user', JSON.stringify(user));
          sessionStorage.removeItem('loginService.user');
        } else {
          document.cookie = "mybehr_user=" + user.userName + "; path=/";
          document.cookie = "mybehr_rem=no; path=/";
          sessionStorage.setItem('loginService.user', JSON.stringify(user));
          localStorage.removeItem('loginService.user');
        }
        document.cookie = "mybehr_firstname=" + user.firstName + "; path=/";
        document.cookie = "mybehr_id=" + user.userId + "; path=/";
        document.cookie = "mybehr_lastname=" + user.lastName + "; path=/";
        document.cookie = "mybehr_location=" + user.country + "; path=/";
        document.cookie = "mybehr_zip=" + user.zipCode + "; path=/";
        document.cookie = "mybehr_language=" + user.language + "; path=/";
        document.cookie = "mybehr_fbonly=no; path=/";
        document.cookie = "mybehr_optin=" + user.optInStatus + "; path=/";
        document.cookie = "mybehr_interests=" + user.interests + "; path=/";
      },
      login(formData) {
        var userData = "<Request><user><email>" + formData.emailAddress + "</email>" + "<password>" + formData.password + "</password></user></Request>";
        var rememberLogin = formData.rememberLogin;
        return $http({
          method: 'POST',
          data: userData,
          headers: {
            'Content-Type': 'text/xml'
          },
          url: $serviceURL + "/user/rest/user/authenticate"
        }).then(function successCallback(response) {
            if (response.data != 'undefined') {
              response = response.data;
            }
            var x2js = new X2JS()
            response = x2js.xml_str2json(response).Response;

            var errorCode = parseInt(response.error);
            if (errorCode === 0) {
              user = response.user;
              loginService._setUserCookie(user, rememberLogin);
            } else {
              var deferred = $q.defer();
              deferred.reject(response.messages);
              return deferred.promise;
            }
            return response;
          },
          function errorCallback(response) {
            var deferred = $q.defer();
            deferred.reject(behrTranslate("Sorry. We could not complete your sign up."));
            return deferred.promise;
          });
      },
      logout() {
        var cookieNames = document.cookie.split(/=[^;]*(?:;\s*|$)/);

        for (var i = 0; i < cookieNames.length; i++) {
          if (/^mybehr_/.test(cookieNames[i])) {
            document.cookie = cookieNames[i] + '=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/';
          }
        }
        user = {};
        sessionStorage.removeItem('loginService.user');
        localStorage.removeItem('loginService.user');
      },
      _signupRequest(url, data, myInterests) {
        return $http({
          method: 'POST',
          data: data,
          headers: {
            'Accept': '*/*',
            'Content-Type': 'text/xml'
          },
          url: url
        }).then(function successCallback(response) {
            if (response.data != 'undefined') {
              response = response.data;
            }
            var deferred = $q.defer();
            var x2js = new X2JS()
            response = x2js.xml_str2json(response).Response;

            var errorCode = parseInt(response.error);

            if (errorCode === 0) {
              user = response.user;
              loginService._setUserCookie(response.user, true);
            } else if (errorCode == 2) {
              deferred.reject(behrTranslate("Sorry. We could not complete your sign up."));
              return deferred.promise;
            } else {
              deferred.reject(behrTranslate("Sorry. We could not complete your sign up."));
              return deferred.promise;
            }
          },
          function errorCallback(response) {
            var deferred = $q.defer();
            deferred.reject(behrTranslate("Sorry. We could not complete your sign up."));
            return deferred.promise;
          });
      },
      signup(formData) {
        /*
        // floodlight Tag for registration
        var axel1 = Math.random() + "";
        var a1 = axel1 * 10000000000000;
        var iframe = document.createElement("iframe");
        iframe.setAttribute("src", "http://1168945.fls.doubleclick.net/activityi;src=1168945;type=behr2611;cat=mybeh293;ord=1;num=' + a1 + '?");
        iframe.setAttribute("width", "1");
        iframe.setAttribute("height", "1");
        iframe.setAttribute("frameborder", "0");
        iframe.setAttribute("style", "display:none");
        document.body.appendChild(iframe);
        // Floodlight Tag Ends
        */

        var myInterests = "e_mail_language=EN,e_mail_status=0";
        var behrNews = "N";
        if (formData.optInStatus) {
          myInterests = "email," + myInterests;
          behrNews = "Y"
        }

        var userData = "<Request><clientDomain>www.behr.com</clientDomain><user><email>" + formData.emailAddress + "</email><firstName>" + formData.firstName + "</firstName><lastName>" + formData.lastName + "</lastName><password>" + formData.password + "</password><userName>" + formData.emailAddress + "</userName><country>" + formData.country + "</country><zipCode>" + formData.zipCode + "</zipCode><optInStatus>" + behrNews + "</optInStatus></user></Request>";

        return loginService._signupRequest($serviceURL + "/user/rest/user/create", userData, myInterests);
      },
      getUser() {
        return user;
      },
      FB: {
        login() {
          return loginService.FB._openFBLogin()
            .then(loginService.FB.getFBData)
            .then((response) => {
              return loginService.FB._attemptLogin(response.email, response.id);
            })
        },
        signup(formData) {
          /*
          // floodlight Tag for registration
          var axel1 = Math.random() + "";
          var a1 = axel1 * 10000000000000;
          var iframe = document.createElement("iframe");
          iframe.setAttribute("src", "http://1168945.fls.doubleclick.net/activityi;src=1168945;type=behr2611;cat=mybeh293;ord=1;num=' + a1 + '?");
          iframe.setAttribute("width", "1");
          iframe.setAttribute("height", "1");
          iframe.setAttribute("frameborder", "0");
          iframe.setAttribute("style", "display:none");
          document.body.appendChild(iframe);
          // Floodlight Tag Ends
          */

          var myInterests = "e_mail_language=EN,e_mail_status=0";
          var behrNews = "N";
          if (formData.optInStatus) {
            myInterests = "email," + myInterests;
            behrNews = "Y"
          }

          var userData = "<Request><clientDomain>www.behr.com</clientDomain><user><email>" +
            formData.emailAddress + "</email><firstName>" +
            formData.firstName + "</firstName><lastName>" +
            formData.lastName + "</lastName><password>" +
            formData.password + "</password><userName>" +
            formData.emailAddress + "</userName><country>" +
            formData.country + "</country><zipCode>" +
            formData.zipCode + "</zipCode><optInStatus>" +
            behrNews + "</optInStatus></user><oauthUser><oauthProvider>facebook</oauthProvider><oauthUID>" +
            formData.facebookId + "</oauthUID></oauthUser></Request>";

          return loginService._signupRequest($serviceURL + "/user/rest/user/registerfbuser", userData, myInterests);
        },
        _attemptLogin(email, uid) {
          var deferred = $q.defer();
          if (!email || !uid) {
            deferred.reject(behrTranslate('Sorry. We could not log you in.'));
            return deferred.promise;
          }
          var url = $serviceURL + '/user/rest/user/finduserbyfbuidoremail';
          var userData = "<Request><clientDomain>behr.com</clientDomain><user><email>" + email +
            "</email></user><oauthUser><oauthProvider>facebook</oauthProvider><oauthUID>" + uid +
            "</oauthUID></oauthUser></Request>";
          return $http.post(url, userData, {
            headers: {
              'Content-Type': 'text/xml'
            }
          }).then((response) => {
            if (response.data != 'undefined') {
              response = response.data;
            }
            var x2js = new X2JS()
            response = x2js.xml_str2json(response).Response;
            var code = parseInt(response.error);
            if (code == 100) {
              user = response.user;
              loginService._setUserCookie(response.user, true);
              return user;
            } else if (code == 101) {
              // Some user is already registered using this email but not through FB
              deferred.reject(behrTranslate('Please sign up or log in without Facebook.'));
              return deferred.promise;
            } else if (code == 1) {
              deferred.reject('SIGNUP');
              return deferred.promise;
            } else {
              deferred.reject(behrTranslate('Sorry. We could not log you in.'));
              return deferred.promise;
            }
          }, (error) => {
            var deferred = $q.defer();
            deferred.reject(behrTranslate('Sorry. We could not log you in.'));
            return deferred.promise;
          });
        },
        getFBData() {
          var deferred = $q.defer();
          FB.api('/me?fields=email,name', function(response) {
            deferred.resolve(response);
          });
          return deferred.promise;
        },
        _openFBLogin() {
          var deferred = $q.defer();
          FB.login(function(response) {
            if (response.authResponse) {
              deferred.resolve(response);
            } else {
              deferred.reject(behrTranslate('Sorry. We could not log you in.'));
            }
          }, {
            scope: 'email'
          });
          return deferred.promise;
        }
      }
    }
    Object.defineProperty(loginService, 'loggedIn', {
      get: () => {
        return (Object.keys(user).length !== 0)
      }
    });
    return loginService;
  });

}());
