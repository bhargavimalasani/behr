(function() {
    "use strict";
  
    var app = angular.module('colorsmart', [
      'ui.router',
      'ui.bootstrap',
      'pascalprecht.translate',
      'ngAnimate',
      'ngTouch',
      'slickCarousel',
      'behrCore',
      'rzModule'
    ]);
  
    // Bootstrap the Angular application
    angular.element(document).ready(function() {
      angular.bootstrap('#cs-mobile-app', ['colorsmart']);
    });
  
    app.run(function($rootScope, $assets, $location, colorService, $state, $timeout, localeService, projectService, paletteService, $uibModal, behrTranslate) {
      $rootScope.$assets = $assets;
      $rootScope.$localeService = localeService;
  
      var bodyTag = angular.element(document.querySelector('body'));
      var locale = localeService.getLocale();
  
      bodyTag.addClass('locale-' + locale);
  
      if (isUnsupportedBrowser()) {
        let modalInstance = $uibModal.open({
          controller: 'DataModalCtrl',
          controllerAs: '$ctrl',
          templateUrl: '/app/components/modals/warning-modal.html',
          backdropClass: 'modal-background',
          appendTo: angular.element('#cs-mobile-app'),
          resolve: {
            data: () => {
              return {
                message: behrTranslate('ColorSmart by BEHR® no longer supports Internet Explorer. While you can still access the tool, for the best experience and access to all the latest features, please use a different browser such as Chrome, Safari or Firefox.')
              };
            }
          }
        });
      }
  
      //if user is on Safari, correct UsableNet's drawing of the iFrame (mobile only)
      // function redrawAppIFrame() {
      //   var frameHeight = $('#cs-mobile-app').height();
      //   $('#cs-mobile-app').removeAttr('height');
      //   $('#cs-mobile-app').height(frameHeight);
      // }
      // $timeout(redrawAppIFrame, 1000);
      // $timeout(redrawAppIFrame, 3000);
      // $timeout(redrawAppIFrame, 5000);
  
      function colorFamilyIndex(color) {
        if (!color) return null;
        if(color.toLowerCase().indexOf('white') === 0) return 0;
        if(color.toLowerCase().indexOf('gray') === 0) return 1;
        if(color.toLowerCase().indexOf('brown') === 0) return 2;
        if(color.toLowerCase().indexOf('red') === 0) return 3;
        if(color.toLowerCase().indexOf('orange') === 0) return 4;
        if(color.toLowerCase().indexOf('yellow') === 0) return 5;
        if(color.toLowerCase().indexOf('green') === 0) return 6;
        if(color.toLowerCase().indexOf('blue') === 0) return 7;
        if(color.toLowerCase().indexOf('purple') === 0) return 8;
        return null;
      }
  
      function sectionDefault(section) {
        if (!section) return null;
  
        switch(section.toLowerCase()) {
          case "colorfamily": return 'families';
          case "marquee": return 'marquee.marqueeCollection';
          case "decorator": return 'decorators.home';
          case "popular": return 'popular.trends2017';
        }
  
        return null;
      }
  
      var standardSearch = {};
  
      window.location.search.substring(1).split('&').forEach((pair) => {
        var parts = pair.split('=');
        standardSearch[parts[0]] = parts[1];
      });
  
      var queryParams = angular.extend($location.search() || {}, standardSearch);
      var stateParams;
  
      function savePaletteFromParam(param) {
        var colorIdArray = queryParams[param].split(',');
        
        if (colorIdArray.length > 8) {
          // drop items that exceed the max
          colorIdArray.length = 8;
        }
        
        var colorArray = colorIdArray.map(colorId => colorService.getColor(colorId));
  
        colorArray = colorArray.filter(color => color !== null)
  
        if (param === 'qpalette') {
          var quadObj = {
            colorId1: colorIdArray[0],
            colorId2: colorIdArray[1],
            colorId3: colorIdArray[2],
            colorId4: colorIdArray[3],
            primaryColorId: colorIdArray[0]
          }
  
          localStorage.savedCoordinated = true;
          localStorage.savedCoordinationStateParams = JSON.stringify(quadObj);
        } else {
          localStorage.savedCoordinated = false;
          localStorage.savedCoordinationStateParams = "{}";
        }
  
        localStorage.savedColors = JSON.stringify(colorArray);
        paletteService.reload();
  
        if (param !== 'buy' && param !== 'buySamples') {
          if (queryParams.hasOwnProperty('view')) {
            switch (queryParams.view) {
              case 'find-in-store':
                $state.go('storeLocator', {});
              break;
  
              case 'colors':
                $state.go('index', {});
              break;
  
              default:
                paletteService.palette.selected = 0;
                $state.go('roomPicker', {});
            }
          } else {
            paletteService.palette.selected = 0;
            $state.go('roomPicker', {});
          }
        }
      }
  
      if (queryParams.hasOwnProperty('palette')) {
        savePaletteFromParam('palette');
      }
  
      if (queryParams.hasOwnProperty('color')) {
        savePaletteFromParam('color');
      }
  
      if (queryParams.hasOwnProperty('qpalette')) {
        savePaletteFromParam('qpalette');
      }
  
      if (queryParams.hasOwnProperty('buy')) {
        savePaletteFromParam('buy');
        projectService.sendToShoppingCart(paletteService.palette.colors, "paint");
      }
  
      if (queryParams.hasOwnProperty('buySamples')) {
        savePaletteFromParam('buySamples');
        projectService.sendToShoppingCart(paletteService.palette.colors, "sample");
      }
  
      if (queryParams.hasOwnProperty('pyp') && queryParams.pyp == 'start') {
        $state.go('pypUpload')
      }
  
      if (queryParams.hasOwnProperty('family')) {
        stateParams = {
          collection: 'families',
          family: null,
          chipset: null
        };
  
        stateParams.family = queryParams.family;
  
        if (stateParams.family !== null) $state.go('index.collection-family', stateParams);
      }
  
      if (queryParams.hasOwnProperty('section')) {
        stateParams = {
          collection: null,
        };
  
        stateParams.collection = sectionDefault(queryParams.section)
  
        if (stateParams.collection !== null) $state.go('index.collection', stateParams);
      }
  
      if (queryParams.hasOwnProperty('project')) {
        var id = queryParams.project;
        projectService.loadProjectById(id);
      }
  
      if (queryParams.hasOwnProperty('colorset')) {
        var parts = queryParams.colorset.split('_');
        var _section = parts[0] ? parts[0].toLowerCase() : null;
        var _option = parts[1] ? parts[1].toLowerCase() : null;
        var _chipset = parts[2] ? parts[2].toLowerCase() : null;
  
        stateParams = {};
  
        switch (_section) {
          case "colorfamily":
            stateParams.collection = 'all-colors';
            stateParams.family = _option;
            stateParams.chipset = null;
          break;
  
          case "marquee":
            stateParams.superCollection = 'marquee';
  
            if (_option == "interioronecoat") {
              stateParams.collection = 'colors';
  
              if (_chipset == 'whites') _chipset = 'white';
              else if (_chipset == 'browns') _chipset = 'brown';
              else if (_chipset == 'grays') _chipset = 'gray';
              else if (_chipset == 'reds') _chipset = 'red';
              else if (_chipset == 'oranges') _chipset = 'orange';
              else if (_chipset == 'yellows') _chipset = 'yellow';
              else if (_chipset == 'greens') _chipset = 'green';
              else if (_chipset == 'blues') _chipset = 'blue';
              else if (_chipset == 'purples') _chipset = 'purple';
  
              stateParams.family = _chipset;
              stateParams.chipset = null;
            } else {
              stateParams.collection = 'collection';
  
              if (_chipset == 'dynasty') stateParams.chipset = 0;
              else if (_chipset == 'fundamentals') stateParams.chipset = 1;
              else if (_chipset == 'lights') stateParams.chipset = 2;
              else if (_chipset == 'odyssey') stateParams.chipset = 3;
              else if (_chipset == 'opulence') stateParams.chipset = 4;
              else if (_chipset == 'rejuvenation') stateParams.chipset = 5;
            }
          break;
  
          case "decorator":
            stateParams.superCollection = 'decorators';
            stateParams.collection = 'color-book';
  
            if (_option == "hdc") { // Decorator_HDC_Neutral
              stateParams.collection = 'home';
  
              if (_chipset == 'neutral') stateParams.chipset = (0);
              else if (_chipset == 'modern') stateParams.chipset = (1);
              else if (_chipset == 'cottage') stateParams.chipset = (2);
              else if (_chipset == 'artscrafts') stateParams.chipset = (3);
              else if (_chipset == 'classic') stateParams.chipset = (4);
            }
          break;
  
          case "popular":
            stateParams.superCollection = 'popular';
  
            if (_option == "trends") { // 2019 color trends
              stateParams.collection = '2019-color-trends';
            } else if (_option == "interior") { // Popular_Interior_Bedroom
              stateParams.collection = 'interior';
  
              if (_chipset == 'bedroom') stateParams.chipset = 0;
              else if (_chipset == 'bathroom') stateParams.chipset = 1;
              else if (_chipset == 'kidsroom') stateParams.chipset = 2;
              else if (_chipset == 'livingroom') stateParams.chipset = 3;
              else if (_chipset == 'kitchen') stateParams.chipset = 4;
              else if (_chipset == 'dining') stateParams.chipset = 5;
              else if (_chipset == 'office') stateParams.chipset = 6;
              else if (_chipset == 'recroom') stateParams.chipset = 7;
            } else if (_option == "exterior") {	// Popular_Exterior_Pacific
              stateParams.collection = 'exterior';
  
              if (_chipset == 'northeast') stateParams.chipset = 0;
              else if (_chipset == 'southwest') stateParams.chipset = 1;
              else if (_chipset == 'northwest') stateParams.chipset = 2;
              else if (_chipset == 'midwest') stateParams.chipset = 3;
              else if (_chipset == 'southeast') stateParams.chipset = 4;
            } else if (_option == "family") { // Popular_Family_Red
              stateParams.collection = 'colors';
              stateParams.family = _chipset.toLowerCase(); //colorFamilyIndex(_chipset);
              stateParams.chipset = 0;
            } else if (_option == "timeless") { // Popular_Timeless_Red
              stateParams.collection = 'timeless';
              stateParams.chipset = 0;
            }
          break;
        }
  
        colorService.savedBrowserState = stateParams;
  
        colorService.returnToBrowserState();
      }
  
      function isUnsupportedBrowser() {
        // Get IE or Edge browser version
        var ieVersion = detectIE();
  
        if (ieVersion && ieVersion > 0 && ieVersion < 12) {
          return true;
        }
        return false;
      }
  
      /**
       * detect IE
       * returns version of IE or false, if browser is not Internet Explorer
       */
      function detectIE() {
        var ua = window.navigator.userAgent;
  
        // Test values; Uncomment to check result …
  
        // IE 10
        // ua = 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)';
  
        // IE 11
        // ua = 'Mozilla/5.0 (Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko';
  
        // Edge 12 (Spartan)
        // ua = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 Edge/12.0';
  
        // Edge 13
        // ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2486.0 Safari/537.36 Edge/13.10586';
  
        var msie = ua.indexOf('MSIE ');
        if (msie > 0) {
          // IE 10 or older => return version number
          return parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)), 10);
        }
  
        var trident = ua.indexOf('Trident/');
        if (trident > 0) {
          // IE 11 => return version number
          var rv = ua.indexOf('rv:');
          return parseInt(ua.substring(rv + 3, ua.indexOf('.', rv)), 10);
        }
  
        var edge = ua.indexOf('Edge/');
        if (edge > 0) {
          // Edge (IE 12+) => return version number
          return parseInt(ua.substring(edge + 5, ua.indexOf('.', edge)), 10);
        }
  
        // other browser
        return false;
      }
    });
  } ());
  