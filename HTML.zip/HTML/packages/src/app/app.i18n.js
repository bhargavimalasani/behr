(function() {
    "use strict";
    var app = angular.module('colorsmart');
    app.config(['$translateProvider', '$windowProvider', 'localeServiceProvider', function($translateProvider, $windowProvider, localeServiceProvider) {
  
      var $window = $windowProvider.$get();
      var locStr = localeServiceProvider.getFullLocale();
      var preferredLanguage = locStr.substr(0, locStr.indexOf("_"));
  
      $translateProvider.translations('en', {
        "Bathroom": "Bathrooms",
        "Bedroom": "Bedrooms",
        "DiningRoom": "Dining Rooms",
        "Exterior": "Exteriors",
        "Kitchen": "Kitchens",
        "LivingRoom": "Living Rooms",
        "Other": "Other"
      });
  
      if(locStr != "en_US"){
        var initInjector = angular.injector(["ng"]);
        var $http = initInjector.get("$http");
        var url = "/restapi/resourceBundle/colorsmartrs";
        if($.inArray(locStr,['fr_CA', 'en_CA']) >= 0) {
            url = "/restapi_" + locStr + "/resourceBundle/colorsmartrs";
        }
  
        $http.get(url, {
          headers: {
            'Content-Type': 'application/json'
          }
        }).then((response) => {
          response = response.data;
          $translateProvider.translations(preferredLanguage, response);
        }).catch((error) => {
          console.log('Language JSON not found in CMS', error);
        });
      }
  
      $translateProvider.useSanitizeValueStrategy('escape');
      $translateProvider.preferredLanguage(preferredLanguage);
    }]);
  } ());
  