(function () {
    "use strict";
  
    var app = angular.module('colorsmart');
  
    app.run(function ($http, $rootScope, $rootElement, $state, $stateHistory, $timeout, $transitions, CartService) {
      let noIndexTag = angular.element('<meta name="robots" content="noindex" />');
      let noIndex = false;
      let titleTag = angular.element('meta[property="og:title"]');
      let descriptionTag = angular.element('meta[name="description"]').add(angular.element('meta[property="og:description"]'));
      let canonicalTag = angular.element('link[rel="canonical"]');
      let urlTag = angular.element('meta[property="og:url"]');
      let imgTag = angular.element('meta[property="og:image"]');
  
      $transitions.onStart({}, function (transition) {
        let to = transition.to().name;
        let from = transition.from().name;
  
        if (to === 'cartReview') {
          if (CartService.getConfiguredItems().length < 1) {
            return transition.router.stateService.target('cart');
          }
        }
  
        if (from === 'cart' || from === 'cartReview' || from === 'storeLocator') {
          if (to !== 'cart' && to !== 'cartReview' && to !== 'storeLocator') {
            CartService.abandon();
          }
        }
      });
  
      $transitions.onSuccess({}, (transition) => {
        let to = transition.$to();
        let from = transition.$from();
  
        // remove the loading class
        // note: this only happens on the first view render
        $rootElement.removeClass('cs-is-loading');
  
        if (!(from.includes['index'] && to.includes['index'])) {
          // if not changing chipsets
          window.scrollTo(0, 0); // scroll to top
        }
  
        if ($state.is('colorDetails')) {
          if (!noIndex) {
            angular.element('head').append(noIndexTag);
            noIndex = true;
          }
        } else {
          noIndexTag.remove();
          noIndex = false;
        }
  
        window.optimizely = window.optimizely || [];
  
        window.optimizely.push({
          type: "page",
          pageName: transition.$to().name
        });
  
        window.optimizely.push({
          type: "activate"
        });
  
        $timeout(() => {
          // we need to wait until the app has actually completed the
          // state change and any redirects it needs to do so that we
          // can get the correct pathname for the metadata request
          let seoDataEndpoint = '/consumer/getSEOJson' + window.location.pathname;
  
          $http.get(seoDataEndpoint).then(function (res) {
            if (!res.data || res.data === {}) return;
  
            let title = res.data.ogTitle || document.title;
            let description = res.data.ogDescription || '';
            let link = res.data.link || window.location.pathname;
            let img = res.data.ogImageURLs[0] || '';
            
            document.title = title;
            titleTag.attr('content', title);
            descriptionTag.attr('content', description);
            canonicalTag.attr('href', window.location.origin + link);
            urlTag.attr('content', link);
            imgTag.attr('content', img);
          }).catch(function (err) {
            // fail gracefully
          });
        });
  
        $stateHistory.push(transition.$from().name, transition.params('from'));
      });
    });
  
    app.config(function ($locationProvider) {
      let baseUrl = '/';
      let baseTag = angular.element('<base>');
      let environment = getEnvironment();
  
      switch (environment) {
        case 'local':
          baseUrl = '/base/';
          useHtml5Mode();
        break;
  
        case 'behr':
          baseUrl = '/consumer/colors/paint/';
          useHtml5Mode();
        break;
  
        default:
          // use the hash since we don't know where the app is
          $locationProvider.html5Mode(false);
      }
  
      function useHtml5Mode() {
        $locationProvider.html5Mode({
          enabled: true,
          requireBase: true
        });
  
        baseTag.attr('href', baseUrl);
        angular.element('head').append(baseTag);
      }
  
      function getEnvironment() {
        let hostName = window.location.hostname;
        let port = window.location.port;
  
        if (hostName.indexOf('behr') > -1) return 'behr';
  
        if (hostName.indexOf('local') > -1 || hostName.indexOf('192.168') > -1 || hostName.indexOf('127.0') > -1) {
          if (port == '80' || port == '8080' || !port) return 'behr';
  
          return 'local';
        }
  
        return 'unknown';
      }
    });
  
    app.config(function ($stateProvider, $urlRouterProvider) {
      $urlRouterProvider.when('/', function($state) {
        $state.go('index');
      });
  
      var states = [
        {
          name: 'index',
          url: '/explore',
          component: 'colorBrowser'
        },
        {
          name: 'ui-lib',
          url: '/ui-lib',
          component: 'uiLib'
        },
        {
          name: 'index.super-collection',
          url: '/{superCollection:popular|decorators|marquee}/:collection'
        },
        {
          name: 'index.super-collection-family-nochipset',
          url: '/{superCollection:popular|decorators|marquee}/:collection/{family:white|brown|gray|red|orange|yellow|green|blue|purple}'
        },
        {
          name: 'index.super-collection-family',
          url: '/{superCollection:popular|decorators|marquee}/:collection/{family:white|brown|gray|red|orange|yellow|green|blue|purple}/:chipset'
        },
        {
          name: 'index.super-collection.chipset',
          url: '/:chipset'
        },
        {
          name: 'index.collection',
          url: '/:collection'
        },
        {
          name: 'index.collection-family-nochipset',
          url: '/:collection/{family:white|brown|gray|red|orange|yellow|green|blue|purple}'
        },
        {
          name: 'index.collection-family',
          url: '/:collection/{family:white|brown|gray|red|orange|yellow|green|blue|purple}/:chipset'
        },
        {
          name: 'index.collection.chipset',
          url: '/:chipset'
        },
        {
          name: 'search',
          url: '/search?q',
          component: 'colorSearch'
        },
        {
          name: 'cart',
          url: '/cart',
          component: 'configurator',
          params: {
            reviewing: false,
            colors: {dynamic: true},
            productType: {dynamic: true},
            layout: 'full'
          }
        },
        {
          name: 'cartReview',
          url: '/cart/review',
          component: 'configurator',
          params: {
            reviewing: true,
            layout: 'full'
          }
        },
        {
          name: 'paint',
          url: '/visualizer',
          component: 'mobileVisualizerPage'
        },
        {
          name: 'compareColors',
          url: '/visualizer/compare',
          component: 'compareColors'
        },
        {
          name: 'roomPicker',
          url: '/visualizer/rooms',
          component: 'roomPicker'
        },
        {
          name: 'pypUpload',
          url: '/visualizer/upload',
          component: 'pypUpload'
        },
        {
          name: 'pypUpload2',
          url: '/visualizer/upload/:colorId1/:colorId2/:colorId3/:colorId4',
          component: 'pypUpload',
          params: {
            colorId1: { dynamic: true },
            colorId2: { dynamic: true },
            colorId3: { dynamic: true },
            colorId4: { dynamic: true }
          },
          resolve: {
            colors: function (colorService, $transition$) {
              return [
                colorService.getColor($transition$.params().colorId1),
                colorService.getColor($transition$.params().colorId2),
                colorService.getColor($transition$.params().colorId3),
                colorService.getColor($transition$.params().colorId4)
              ];
            }
          }
        },
        {
          name: 'paletteDetails',
          url: '/palette/:colorId1/:colorId2/:colorId3/:colorId4?primaryColorId&secondaryColorId&paletteIndex&collection&chipset&family&refColor',
          component: 'paletteDetails',
          params: {
            refColor: { dynamic: true },
            paletteIndex: { dynamic: true },
            colorId1: { dynamic: true },
            colorId2: { dynamic: true },
            colorId3: { dynamic: true },
            colorId4: { dynamic: true }
          },
          resolve: {
            colors: function (colorService, $transition$) {
              return [
                colorService.getColor($transition$.params().colorId1),
                colorService.getColor($transition$.params().colorId2),
                colorService.getColor($transition$.params().colorId3),
                colorService.getColor($transition$.params().colorId4)
              ];
            }
          }
        },
        {
          name: 'paletteList',
          url: '/palettes/:primaryColorId/:secondaryColorId/:paletteIndex?collection&chipset&family',
          component: 'paletteList',
          resolve: {
            color: function (colorService, $transition$) {
              return colorService.getColor($transition$.params().primaryColorId);
            },
            color2: function (colorService, $transition$) {
              return colorService.getColor($transition$.params().secondaryColorId);
            }
          }
        },
        {
          name: 'colorDetails',
          url: '/color/:colorId',
          component: 'colorDetails',
          resolve: {
            color: function (colorService, $transition$) {
              return colorService.getColor($transition$.params().colorId);
            }
          }
        },
        {
          name: 'storeLocator',
          url: '/find-in-store',
          component: 'storeLocator',
          params: {
            colors: {dynamic: true},
            layout: 'full'
          }
        }
      ];
      states.forEach((stateDef) => $stateProvider.state(stateDef));
    });
  })();
  